<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('user_model');
        $this->load->library('form_validation');
        $this->load->helper('form');
    }

    public function index() {
        // Jika sudah login, redirect ke dashboard
        if ($this->session->userdata('logged_in')) {
            redirect('dashboard');
        }

        if ($this->input->post()) {
            $action = $this->input->post('action');

            if ($action === 'login') {
                $this->form_validation->set_rules('identity', 'User Identity', 'required|trim');
                $this->form_validation->set_rules('password', 'Password', 'required|trim');

                if ($this->form_validation->run() === TRUE) {
                    $user = $this->user_model->login_by_identity(
                        $this->input->post('identity'),
                        $this->input->post('password')
                    );

                    if ($user) {
                        $this->session->set_userdata([
                            'user_id'   => $user->id,
                            'username'  => $user->username,
                            'logged_in' => TRUE
                        ]);
                        redirect('dashboard');
                    } else {
                        $this->session->set_flashdata('error', 'User Identity atau Password salah!');
                    }
                }
            } 
            elseif ($action === 'register') {
                $this->form_validation->set_rules('username', 'Username', 'required|min_length[3]|is_unique[users.username]');
                $this->form_validation->set_rules('email', 'Email', 'required|valid_email|is_unique[users.email]');
                $this->form_validation->set_rules('password', 'Password', 'required|min_length[6]');
                $this->form_validation->set_rules('password_confirm', 'Confirm Password', 'required|matches[password]');

                if ($this->form_validation->run() === TRUE) {
                    $data = [
                        'username' => $this->input->post('username'),
                        'email'    => $this->input->post('email'),
                        'password' => password_hash($this->input->post('password'), PASSWORD_DEFAULT)
                    ];

                    if ($this->user_model->register($data)) {
                        $this->session->set_flashdata('success', 'Registrasi berhasil! Silakan login.');
                    } else {
                        $this->session->set_flashdata('error', 'Gagal registrasi.');
                    }
                }
            }
            redirect('auth'); // agar flashdata muncul
        }

        $this->load->view('auth/auth');
    }

    public function logout() {
        $this->session->sess_destroy();
        redirect('dashboard'); // Redirect ke dashboard setelah logout, bukan ke auth
    }
}