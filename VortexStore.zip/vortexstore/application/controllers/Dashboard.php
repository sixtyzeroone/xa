<?php
class Dashboard extends CI_Controller {
    public function __construct() {
        parent::__construct();
        // Hapus redirect login dari sini
    }

    public function index() {
        // Cek login hanya untuk menampilkan username (opsional)
        if ($this->session->userdata('logged_in')) {
            $data['username'] = $this->session->userdata('username');
        } else {
            $data['username'] = 'Guest';
        }
        $this->load->view('dashboard', $data);
    }
}