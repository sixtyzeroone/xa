<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | VORTEX STORE</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700&family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    
    <style>
        :root { --primary: #00f2fe; --secondary: #4facfe; --dark-bg: #06080c; --glass: rgba(255,255,255,0.03); --glass-border: rgba(255,255,255,0.1); }
        * { margin:0; padding:0; box-sizing:border-box; font-family:'Poppins',sans-serif; }
        body { background-color:var(--dark-bg); background-image:radial-gradient(circle at 20% 30%,rgba(0,242,254,0.05)0%,transparent 40%),radial-gradient(circle at 80% 70%,rgba(79,172,254,0.05)0%,transparent 40%); height:100vh; display:flex; align-items:center; justify-content:center; color:white; overflow:hidden; }
        .login-card { background:rgba(15,18,26,0.8); backdrop-filter:blur(15px); border:1px solid var(--glass-border); padding:50px 40px; width:100%; max-width:420px; border-radius:24px; text-align:center; box-shadow:0 20px 50px rgba(0,0,0,0.5); position:relative; }
        .login-card::before { content:""; position:absolute; top:-2px; left:-2px; right:-2px; bottom:-2px; background:linear-gradient(45deg,var(--primary),transparent,var(--secondary)); border-radius:26px; z-index:-1; opacity:0.2; }
        .logo-box { margin-bottom:30px; }
        .logo-img { width:280px; height:190px; margin-bottom:10px; filter:drop-shadow(0 0 15px var(--primary)); animation:blinker 0.6s linear 3; }
        @keyframes blinker { 50% { opacity:0; transform:scale(0.9); } 100% { opacity:1; transform:scale(1); } }
        .btn-social { width:100%; padding:14px; margin-bottom:12px; border-radius:12px; border:1px solid var(--glass-border); background:var(--glass); color:white; font-weight:500; display:flex; align-items:center; justify-content:center; gap:10px; transition:0.3s; font-size:0.95rem; }
        .btn-social img { width:24px; height:24px; object-fit:contain; border-radius:50%; background:white; padding:4px; box-sizing:content-box; }
        .btn-social:hover { background:rgba(255,255,255,0.05); }
        .btn-google:hover { background:rgba(234,67,53,0.2); border-color:#ea4335; }
        .btn-whatsapp:hover { background:rgba(37,211,102,0.2); border-color:#25D366; }
        .divider { margin:25px 0; color:#444; font-size:0.75rem; font-weight:bold; position:relative; }
        .divider::before, .divider::after { content:""; position:absolute; top:50%; width:35%; height:1px; background:#222; }
        .divider::before { left:0; } .divider::after { right:0; }
        .input-box { text-align:left; margin-bottom:20px; }
        .input-box label { font-size:0.75rem; color:var(--primary); text-transform:uppercase; letter-spacing:1px; margin-bottom:8px; display:block; }
        .input-box input { width:100%; padding:14px; background:rgba(0,0,0,0.4); border:1px solid #222; border-radius:10px; color:white; outline:none; transition:0.3s; }
        .input-box input:focus { border-color:var(--primary); box-shadow:0 0 10px rgba(0,242,254,0.1); }
        .btn-primary { width:100%; padding:16px; background:linear-gradient(45deg,var(--primary),var(--secondary)); border:none; border-radius:12px; color:#000; font-weight:700; font-family:'Orbitron',sans-serif; cursor:pointer; transition:0.3s; margin-top:10px; }
        .btn-primary:hover { transform:translateY(-3px); box-shadow:0 10px 20px rgba(0,242,254,0.3); }
        .footer-text { margin-top:25px; font-size:0.8rem; color:#666; }
        .footer-text a { color:var(--primary); text-decoration:none; }
        .error-msg { background:rgba(255,0,0,0.2); color:#ffcccc; padding:12px; border-radius:10px; margin-bottom:20px; }
        .success-msg { background:rgba(0,255,0,0.2); color:#ccffcc; padding:12px; border-radius:10px; margin-bottom:20px; }
        #register-container { display:none; }
    </style>
</head>
<body>

<div class="login-card">
    <div class="logo-box">
        <img src="<?= base_url('assets/img/vortex-wall2.png') ?>" alt="Vortex Logo" class="logo-img">
    </div>

    <?php if($this->session->flashdata('error')): ?>
        <div class="error-msg"><?= $this->session->flashdata('error') ?></div>
    <?php endif; ?>

    <?php if($this->session->flashdata('success')): ?>
        <div class="success-msg"><?= $this->session->flashdata('success') ?></div>
    <?php endif; ?>

    <!-- LOGIN FORM -->
    <div id="login-container">
        <?= form_open('auth'); ?>
        <input type="hidden" name="action" value="login">
        <div class="input-box">
            <label>User Identity</label>
            <input type="text" name="identity" placeholder="Email or Phone Number" value="<?= set_value('identity') ?>" required>
        </div>
        <div class="input-box">
            <label>Password</label>
            <input type="password" name="password" placeholder="Your Password" required>
        </div>
        <button type="submit" class="btn-primary">INITIATE LOGIN</button>
        <?= form_close(); ?>
    </div>

    <!-- REGISTER FORM -->
    <div id="register-container">
        <?= form_open('auth'); ?>
        <input type="hidden" name="action" value="register">
        <div class="input-box">
            <label>Username</label>
            <input type="text" name="username" placeholder="Choose Username" value="<?= set_value('username') ?>" required>
        </div>
        <div class="input-box">
            <label>Email</label>
            <input type="email" name="email" placeholder="Your Email" value="<?= set_value('email') ?>" required>
        </div>
        <div class="input-box">
            <label>Password</label>
            <input type="password" name="password" placeholder="Create Password" required>
        </div>
        <div class="input-box">
            <label>Confirm Password</label>
            <input type="password" name="password_confirm" placeholder="Confirm Password" required>
        </div>
        <button type="submit" class="btn-primary">CREATE ACCOUNT</button>
        <?= form_close(); ?>
    </div>

    <button class="btn-social btn-google">
        <img src="https://www.google.com/images/branding/googlelogo/1x/googlelogo_color_272x92dp.png" alt="Google">
        Continue with Google
    </button>
    <button class="btn-social btn-whatsapp">
        <img src="https://upload.wikimedia.org/wikipedia/commons/6/6b/WhatsApp.svg" alt="WhatsApp">
        Continue with WhatsApp
    </button>

    <div class="divider">OR USE EMAIL</div>

    <p class="footer-text" id="switch-text">
        New traveler? <a href="#" id="switch-link">Create an account</a>
    </p>
</div>

<script>
    let isLogin = true;
    document.getElementById('switch-link').addEventListener('click', function(e) {
        e.preventDefault();
        if (isLogin) {
            document.getElementById('login-container').style.display = 'none';
            document.getElementById('register-container').style.display = 'block';
            this.parentElement.innerHTML = 'Already a traveler? <a href="#" id="switch-link">Login here</a>';
        } else {
            document.getElementById('login-container').style.display = 'block';
            document.getElementById('register-container').style.display = 'none';
            this.parentElement.innerHTML = 'New traveler? <a href="#" id="switch-link">Create an account</a>';
        }
        isLogin = !isLogin;
    });
</script>
</body>
</html>