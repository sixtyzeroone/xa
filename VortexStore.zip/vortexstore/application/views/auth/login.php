<!DOCTYPE html>
<html lang="id" data-bs-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login - VortexStore</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            transition: background 0.5s ease;
        }
        body[data-bs-theme="dark"] {
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
        }
        .glass-card {
            background: rgba(255, 255, 255, 0.15);
            backdrop-filter: blur(12px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 20px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.37);
            overflow: hidden;
        }
        .form-control {
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.3);
            color: white;
            border-radius: 10px;
            transition: all 0.3s;
        }
        .form-control:focus {
            background: rgba(255, 255, 255, 0.2);
            border-color: #fff;
            box-shadow: 0 0 0 0.25rem rgba(255,255,255,0.25);
            color: white;
        }
        .form-control::placeholder { color: rgba(255,255,255,0.7); }
        .input-group-text { background: transparent; border: none; color: white; cursor: pointer; }
        .btn-primary {
            background: linear-gradient(90deg, #667eea, #764ba2);
            border: none;
            border-radius: 50px;
            padding: 12px;
            font-weight: bold;
            transition: transform 0.3s;
        }
        .btn-primary:hover { transform: translateY(-3px); }
        .theme-toggle { position: absolute; top: 20px; right: 30px; font-size: 1.5rem; cursor: pointer; color: white; }
        .alert { border-radius: 10px; }
    </style>
</head>
<body>

<i class="fas fa-moon theme-toggle" id="themeToggle" title="Toggle Dark Mode"></i>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-4 col-lg-4">
            <div class="glass-card p-5 mt-5">
                <h3 class="text-center text-white mb-4 fw-bold">Login VortexStore</h3>

                <?php if($this->session->flashdata('error')): ?>
                    <div class="alert alert-danger"><?= $this->session->flashdata('error') ?></div>
                <?php endif; ?>

                <?= form_open('auth/login', ['class' => 'needs-validation']); ?>

                <div class="mb-4 position-relative">
                    <input type="text" name="username" class="form-control" placeholder="Username" value="<?= set_value('username') ?>" required autofocus>
                    <?= form_error('username', '<small class="text-danger">', '</small>') ?>
                </div>

                <div class="mb-4 input-group">
                    <input type="password" name="password" id="password" class="form-control" placeholder="Password" required>
                    <span class="input-group-text" id="togglePassword"><i class="fas fa-eye-slash"></i></span>
                    <?= form_error('password', '<small class="text-danger d-block">', '</small>') ?>
                </div>

                <button type="submit" class="btn btn-primary w-100">Masuk</button>

                <?= form_close(); ?>

                <div class="text-center mt-4">
                    <a href="<?= site_url('auth/register') ?>" class="text-white text-decoration-none">Belum punya akun? <strong>Daftar</strong></a>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Password toggle
    const togglePassword = document.querySelector('#togglePassword');
    const password = document.querySelector('#password');
    togglePassword.addEventListener('click', function () {
        const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
        password.setAttribute('type', type);
        this.querySelector('i').classList.toggle('fa-eye');
        this.querySelector('i').classList.toggle('fa-eye-slash');
    });

    // Dark mode toggle
    const themeToggle = document.getElementById('themeToggle');
    themeToggle.addEventListener('click', () => {
        const html = document.documentElement;
        if (html.getAttribute('data-bs-theme') === 'dark') {
            html.setAttribute('data-bs-theme', 'light');
            themeToggle.classList.replace('fa-moon', 'fa-sun');
        } else {
            html.setAttribute('data-bs-theme', 'dark');
            themeToggle.classList.replace('fa-sun', 'fa-moon');
        }
    });
</script>
</body>
</html>