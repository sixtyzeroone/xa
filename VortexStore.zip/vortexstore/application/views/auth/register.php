<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Register - CodeIgniter 3</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #f8f9fa; }
        .card { margin-top: 80px; }
    </style>
</head>
<body>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-5">
            <div class="card shadow">
                <div class="card-header text-center bg-success text-white">
                    <h4>Register Akun</h4>
                </div>
                <div class="card-body">

                    <?php if($this->session->flashdata('success')): ?>
                        <div class="alert alert-success"><?= $this->session->flashdata('success') ?></div>
                    <?php endif; ?>

                    <?php echo form_open('auth/register'); ?>
                    
                    <div class="mb-3">
                        <label>Username</label>
                        <input type="text" name="username" class="form-control" value="<?= set_value('username') ?>" required>
                        <?= form_error('username', '<small class="text-danger">', '</small>') ?>
                    </div>

                    <div class="mb-3">
                        <label>Email</label>
                        <input type="email" name="email" class="form-control" value="<?= set_value('email') ?>" required>
                        <?= form_error('email', '<small class="text-danger">', '</small>') ?>
                    </div>

                    <div class="mb-3">
                        <label>Password</label>
                        <input type="password" name="password" class="form-control" required>
                        <?= form_error('password', '<small class="text-danger">', '</small>') ?>
                    </div>

                    <div class="mb-3">
                        <label>Konfirmasi Password</label>
                        <input type="password" name="password_confirm" class="form-control" required>
                        <?= form_error('password_confirm', '<small class="text-danger">', '</small>') ?>
                    </div>

                    <button type="submit" class="btn btn-success w-100">Daftar</button>
                    <?php echo form_close(); ?>

                    <div class="text-center mt-3">
                        <a href="<?= site_url('auth/login') ?>">Sudah punya akun? Login</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>