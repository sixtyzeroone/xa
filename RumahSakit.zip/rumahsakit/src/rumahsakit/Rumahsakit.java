package rumahsakit;

import tampilan.form_login;

public class Rumahsakit {
    public static void main(String[] args) {
        form_login.main(args);
    }
}