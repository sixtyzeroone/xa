/*
 * Form Data Ruangan
 */
package tampilan;

import javax.swing.*;
import javax.swing.table.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.ArrayList;

public class form_ruangan extends JPanel {
    private Connection conn;
    private DefaultTableModel tableModel;
    
    private static final Color SIDEBAR_BG = new Color(0x1B4332);
    private static final Color SIDEBAR_ACTIVE = new Color(0x2D6A4F);
    private static final Color BUTTON_GREEN = new Color(0x52B788);
    private static final Color CONTENT_BG = new Color(0xF4F6F4);
    private static final Color TABLE_HEADER = new Color(0x1B4332);
    
    private JTextField txtFilterKode, txtFilterKelas;
    private JButton btnFilter, btnTambah, btnCetak, btnRefresh;
    private JTable tableRuangan;
    private JLabel lblTotalRuangan;
    
    private JDialog inputDialog;
    private JTextField txtKdRuangan, txtNamaRuangan, txtKelas, txtKapasitas, txtHarga;
    private JComboBox<String> cmbStatus;
    
    public form_ruangan() {
        koneksi.koneksi k = new koneksi.koneksi();
        conn = k.Connect();
        
        if (conn == null) {
            JOptionPane.showMessageDialog(this, "Gagal koneksi ke database!");
            return;
        }
        
        initComponents();
        loadData();
        createInputDialog();
    }
    
    private void initComponents() {
        setLayout(new BorderLayout());
        setBackground(CONTENT_BG);
        setBorder(new EmptyBorder(15, 20, 15, 20));

        JLabel headerTitle = new JLabel("Data Ruangan");
        headerTitle.setFont(new Font("Segoe UI", Font.BOLD, 24));
        headerTitle.setForeground(SIDEBAR_BG);
        headerTitle.setBorder(new EmptyBorder(0, 0, 15, 0));

        JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 8));
        filterPanel.setBackground(CONTENT_BG);
        filterPanel.setBorder(new EmptyBorder(0, 0, 15, 0));

        int fieldHeight = 36;

        JPanel kodePanel = createFilterField("Kode Ruangan", txtFilterKode = new JTextField(18));
        filterPanel.add(kodePanel);

        JPanel kelasPanel = createFilterField("Kelas", txtFilterKelas = new JTextField(18));
        filterPanel.add(kelasPanel);

        JPanel btnFilterWrapper = new JPanel(new BorderLayout());
        btnFilterWrapper.setBackground(CONTENT_BG);
        btnFilterWrapper.setBorder(new EmptyBorder(22, 0, 0, 0));

        btnFilter = new JButton("Terapkan Filter");
        btnFilter.setBackground(SIDEBAR_BG);
        btnFilter.setForeground(Color.WHITE);
        btnFilter.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnFilter.setFocusPainted(false);
        btnFilter.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnFilter.setPreferredSize(new Dimension(140, fieldHeight));
        btnFilter.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { btnFilter.setBackground(SIDEBAR_ACTIVE); }
            public void mouseExited(MouseEvent e) { btnFilter.setBackground(SIDEBAR_BG); }
        });
        btnFilterWrapper.add(btnFilter, BorderLayout.NORTH);
        filterPanel.add(btnFilterWrapper);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 8));
        buttonPanel.setBackground(CONTENT_BG);
        buttonPanel.setBorder(new EmptyBorder(0, 0, 15, 0));

        btnTambah = new JButton("+ Tambah Data Ruangan Baru");
        btnTambah.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnTambah.setBackground(SIDEBAR_BG);
        btnTambah.setForeground(Color.WHITE);
        btnTambah.setFocusPainted(false);
        btnTambah.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnTambah.setBorder(new EmptyBorder(10, 18, 10, 18));

        btnCetak = new JButton("🖨️ Cetak");
        btnCetak.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnCetak.setBackground(new Color(0x6C757D));
        btnCetak.setForeground(Color.WHITE);
        btnCetak.setFocusPainted(false);
        btnCetak.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnCetak.setBorder(new EmptyBorder(10, 25, 10, 25));

        btnRefresh = new JButton("⟳ Refresh");
        btnRefresh.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnRefresh.setBackground(SIDEBAR_ACTIVE);
        btnRefresh.setForeground(Color.WHITE);
        btnRefresh.setFocusPainted(false);
        btnRefresh.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnRefresh.setBorder(new EmptyBorder(10, 25, 10, 25));

        buttonPanel.add(btnTambah);
        buttonPanel.add(btnCetak);
        buttonPanel.add(btnRefresh);

        String[] columns = {"Kode Ruangan", "Nama Ruangan", "Kelas", "Kapasitas", "Harga/hari", "Status"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override public boolean isCellEditable(int row, int column) { return false; }
        };

        tableRuangan = new JTable(tableModel);
        tableRuangan.setRowHeight(50);
        tableRuangan.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        tableRuangan.setSelectionBackground(new Color(0xD8F3DC));
        tableRuangan.setSelectionForeground(SIDEBAR_BG);
        tableRuangan.setGridColor(new Color(0xE0E0E0));
        tableRuangan.setShowVerticalLines(true);
        tableRuangan.setShowHorizontalLines(true);
        tableRuangan.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);

        tableRuangan.getColumnModel().getColumn(0).setPreferredWidth(100);
        tableRuangan.getColumnModel().getColumn(1).setPreferredWidth(150);
        tableRuangan.getColumnModel().getColumn(2).setPreferredWidth(100);
        tableRuangan.getColumnModel().getColumn(3).setPreferredWidth(80);
        tableRuangan.getColumnModel().getColumn(4).setPreferredWidth(120);
        tableRuangan.getColumnModel().getColumn(5).setPreferredWidth(100);

        JTableHeader header = tableRuangan.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 13));
        header.setBackground(TABLE_HEADER);
        header.setForeground(Color.BLACK);
        header.setPreferredSize(new Dimension(0, 35));

        JScrollPane scrollPane = new JScrollPane(tableRuangan);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(0xE0E0E0)));
        scrollPane.getViewport().setBackground(Color.WHITE);

        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        bottomPanel.setBackground(CONTENT_BG);
        bottomPanel.setBorder(new EmptyBorder(15, 0, 0, 0));
        lblTotalRuangan = new JLabel("Total Ruangan: 0");
        lblTotalRuangan.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblTotalRuangan.setForeground(SIDEBAR_BG);
        bottomPanel.add(lblTotalRuangan);

        JPanel northPanel = new JPanel(new BorderLayout(0, 8));
        northPanel.setBackground(CONTENT_BG);
        northPanel.add(headerTitle, BorderLayout.NORTH);
        northPanel.add(filterPanel, BorderLayout.CENTER);
        northPanel.add(buttonPanel, BorderLayout.SOUTH);

        add(northPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);

        btnTambah.addActionListener(e -> showInputDialog(false, null));
        btnFilter.addActionListener(e -> applyFilter());
        btnRefresh.addActionListener(e -> { resetFilter(); loadData(); });
        btnCetak.addActionListener(e -> cetakData());

        tableRuangan.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    int row = tableRuangan.getSelectedRow();
                    if (row >= 0) showInputDialog(true, row);
                }
            }
        });
    }

    private JPanel createFilterField(String labelText, JTextField field) {
        JPanel panel = new JPanel(new BorderLayout(5, 3));
        panel.setBackground(CONTENT_BG);
        JLabel lbl = new JLabel(labelText);
        lbl.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lbl.setForeground(SIDEBAR_BG);
        field.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        field.setPreferredSize(new Dimension(180, 36));
        field.addActionListener(e -> applyFilter());
        panel.add(lbl, BorderLayout.NORTH);
        panel.add(field, BorderLayout.CENTER);
        return panel;
    }

    private void createInputDialog() {
        inputDialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(this), "Input Data Ruangan", true);
        inputDialog.setSize(550, 480);
        inputDialog.setLocationRelativeTo(this);
        inputDialog.setResizable(true);

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(new EmptyBorder(25, 30, 25, 30));
        formPanel.setBackground(Color.WHITE);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 15, 10, 15);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Kode Ruangan
        gbc.gridy = 0;
        gbc.gridx = 0; gbc.weightx = 0;
        JLabel lblKd = new JLabel("Kode Ruangan");
        lblKd.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblKd.setForeground(SIDEBAR_BG);
        formPanel.add(lblKd, gbc);
        gbc.gridx = 1; gbc.weightx = 1.0;
        txtKdRuangan = new JTextField(20);
        txtKdRuangan.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        formPanel.add(txtKdRuangan, gbc);

        // Nama Ruangan
        gbc.gridy = 1;
        gbc.gridx = 0; gbc.weightx = 0;
        JLabel lblNama = new JLabel("Nama Ruangan");
        lblNama.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblNama.setForeground(SIDEBAR_BG);
        formPanel.add(lblNama, gbc);
        gbc.gridx = 1; gbc.weightx = 1.0;
        txtNamaRuangan = new JTextField(20);
        txtNamaRuangan.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        formPanel.add(txtNamaRuangan, gbc);

        // Kelas
        gbc.gridy = 2;
        gbc.gridx = 0; gbc.weightx = 0;
        JLabel lblKelas = new JLabel("Kelas");
        lblKelas.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblKelas.setForeground(SIDEBAR_BG);
        formPanel.add(lblKelas, gbc);
        gbc.gridx = 1; gbc.weightx = 1.0;
        txtKelas = new JTextField(20);
        txtKelas.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        txtKelas.setToolTipText("Contoh: VIP, Kelas 1, Kelas 2, Kelas 3");
        formPanel.add(txtKelas, gbc);

        // Kapasitas
        gbc.gridy = 3;
        gbc.gridx = 0; gbc.weightx = 0;
        JLabel lblKapasitas = new JLabel("Kapasitas (Tempat Tidur)");
        lblKapasitas.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblKapasitas.setForeground(SIDEBAR_BG);
        formPanel.add(lblKapasitas, gbc);
        gbc.gridx = 1; gbc.weightx = 1.0;
        txtKapasitas = new JTextField(20);
        txtKapasitas.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        formPanel.add(txtKapasitas, gbc);

        // Harga
        gbc.gridy = 4;
        gbc.gridx = 0; gbc.weightx = 0;
        JLabel lblHarga = new JLabel("Harga per Hari (Rp)");
        lblHarga.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblHarga.setForeground(SIDEBAR_BG);
        formPanel.add(lblHarga, gbc);
        gbc.gridx = 1; gbc.weightx = 1.0;
        txtHarga = new JTextField(20);
        txtHarga.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        formPanel.add(txtHarga, gbc);

        // Status
        gbc.gridy = 5;
        gbc.gridx = 0; gbc.weightx = 0;
        JLabel lblStatus = new JLabel("Status");
        lblStatus.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblStatus.setForeground(SIDEBAR_BG);
        formPanel.add(lblStatus, gbc);
        gbc.gridx = 1; gbc.weightx = 1.0;
        cmbStatus = new JComboBox<>(new String[]{"Tersedia", "Terisi", "Perawatan"});
        cmbStatus.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        formPanel.add(cmbStatus, gbc);

        // Buttons
        gbc.gridy = 6; gbc.gridx = 0; gbc.gridwidth = 2; gbc.anchor = GridBagConstraints.CENTER;
        gbc.fill = GridBagConstraints.NONE;

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        JButton btnSimpan = new JButton("Simpan");
        JButton btnUbah = new JButton("Ubah");
        JButton btnHapus = new JButton("Hapus");
        JButton btnBatal = new JButton("Batal");

        btnSimpan.setBackground(BUTTON_GREEN);
        btnUbah.setBackground(new Color(0xFFC107));
        btnHapus.setBackground(new Color(0xDC3545));
        btnBatal.setBackground(new Color(0x6C757D));
        btnSimpan.setForeground(Color.WHITE);
        btnUbah.setForeground(Color.WHITE);
        btnHapus.setForeground(Color.WHITE);
        btnBatal.setForeground(Color.WHITE);
        btnSimpan.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnUbah.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnHapus.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnBatal.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnSimpan.setFocusPainted(false);
        btnUbah.setFocusPainted(false);
        btnHapus.setFocusPainted(false);
        btnBatal.setFocusPainted(false);
        btnSimpan.setPreferredSize(new Dimension(100, 38));
        btnUbah.setPreferredSize(new Dimension(100, 38));
        btnHapus.setPreferredSize(new Dimension(100, 38));
        btnBatal.setPreferredSize(new Dimension(100, 38));

        btnPanel.add(btnSimpan);
        btnPanel.add(btnUbah);
        btnPanel.add(btnHapus);
        btnPanel.add(btnBatal);
        formPanel.add(btnPanel, gbc);
        inputDialog.add(formPanel, BorderLayout.CENTER);

        btnSimpan.addActionListener(e -> { simpan(); inputDialog.dispose(); });
        btnUbah.addActionListener(e -> { ubah(); inputDialog.dispose(); });
        btnHapus.addActionListener(e -> {
            if (JOptionPane.showConfirmDialog(inputDialog, "Yakin hapus data ini?", "Konfirmasi", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
                hapus(); inputDialog.dispose();
            }
        });
        btnBatal.addActionListener(e -> inputDialog.dispose());
    }

    private void showInputDialog(boolean isEdit, Integer row) {
        clearDialogForm();
        if (isEdit && row != null) {
            txtKdRuangan.setText(tableModel.getValueAt(row, 0).toString());
            txtNamaRuangan.setText(tableModel.getValueAt(row, 1).toString());
            txtKelas.setText(tableModel.getValueAt(row, 2).toString());
            txtKapasitas.setText(tableModel.getValueAt(row, 3).toString());
            txtHarga.setText(tableModel.getValueAt(row, 4).toString());
            cmbStatus.setSelectedItem(tableModel.getValueAt(row, 5).toString());
            inputDialog.setTitle("Edit Data Ruangan");
        } else {
            generateKdRuangan();
            inputDialog.setTitle("Tambah Data Ruangan");
        }
        inputDialog.setVisible(true);
    }

    private void loadData() { loadDataWithFilter("", ""); }

    private void applyFilter() {
        String kode = txtFilterKode.getText().trim();
        String kelas = txtFilterKelas.getText().trim();
        loadDataWithFilter(kode, kelas);
    }

    private void resetFilter() {
        txtFilterKode.setText("");
        txtFilterKelas.setText("");
        loadData();
    }

    private void loadDataWithFilter(String kode, String kelas) {
        tableModel.setRowCount(0);
        if (conn == null) return;

        StringBuilder sql = new StringBuilder("SELECT * FROM ruangan WHERE 1=1");
        ArrayList<Object> params = new ArrayList<>();

        if (!kode.isEmpty()) { sql.append(" AND kd_ruangan LIKE ?"); params.add("%" + kode + "%"); }
        if (!kelas.isEmpty()) { sql.append(" AND kelas LIKE ?"); params.add("%" + kelas + "%"); }
        sql.append(" ORDER BY kd_ruangan");

        try (PreparedStatement pst = conn.prepareStatement(sql.toString())) {
            for (int i = 0; i < params.size(); i++) pst.setObject(i + 1, params.get(i));
            ResultSet rs = pst.executeQuery();
            int count = 0;
            while (rs.next()) {
                tableModel.addRow(new Object[]{
                    rs.getString("kd_ruangan"),
                    rs.getString("nama_ruangan"),
                    rs.getString("kelas"),
                    rs.getString("kapasitas"),
                    rs.getString("harga"),
                    rs.getString("status")
                });
                count++;
            }
            lblTotalRuangan.setText("Total Ruangan: " + count);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error load data: " + e.getMessage());
        }
    }

    private void generateKdRuangan() {
        try {
            String sql = "SELECT kd_ruangan FROM ruangan ORDER BY kd_ruangan DESC LIMIT 1";
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            int newNumber = 1;
            if (rs.next()) {
                String last = rs.getString("kd_ruangan");
                if (last != null && last.length() > 2) {
                    newNumber = Integer.parseInt(last.substring(2)) + 1;
                }
            }
            txtKdRuangan.setText(String.format("RG%03d", newNumber));
        } catch (Exception e) {
            txtKdRuangan.setText("RG001");
        }
    }

    private void simpan() {
        String kd = txtKdRuangan.getText().trim();
        String nama = txtNamaRuangan.getText().trim();
        String kelas = txtKelas.getText().trim();
        String kapasitas = txtKapasitas.getText().trim();
        String harga = txtHarga.getText().trim();
        String status = cmbStatus.getSelectedItem().toString();

        if (kd.isEmpty() || nama.isEmpty() || kelas.isEmpty() || kapasitas.isEmpty() || harga.isEmpty()) {
            JOptionPane.showMessageDialog(inputDialog, "Semua field harus diisi!");
            return;
        }

        try {
            String cekSql = "SELECT COUNT(*) FROM ruangan WHERE kd_ruangan = ?";
            PreparedStatement cekPst = conn.prepareStatement(cekSql);
            cekPst.setString(1, kd);
            ResultSet rs = cekPst.executeQuery();
            rs.next();
            if (rs.getInt(1) > 0) {
                JOptionPane.showMessageDialog(inputDialog, "Kode Ruangan sudah ada!");
                rs.close(); cekPst.close(); return;
            }
            rs.close(); cekPst.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(inputDialog, "Error: " + e.getMessage()); return;
        }

        try {
            String sql = "INSERT INTO ruangan (kd_ruangan, nama_ruangan, kelas, kapasitas, harga, status) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, kd); pst.setString(2, nama); pst.setString(3, kelas);
            pst.setString(4, kapasitas); pst.setString(5, harga); pst.setString(6, status);
            pst.executeUpdate(); pst.close();
            JOptionPane.showMessageDialog(inputDialog, "Data berhasil disimpan!");
            loadData(); clearDialogForm();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(inputDialog, "Error: " + e.getMessage());
        }
    }

    private void ubah() {
        String kd = txtKdRuangan.getText().trim();
        if (kd.isEmpty()) return;
        try {
            String sql = "UPDATE ruangan SET nama_ruangan=?, kelas=?, kapasitas=?, harga=?, status=? WHERE kd_ruangan=?";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, txtNamaRuangan.getText().trim());
            pst.setString(2, txtKelas.getText().trim());
            pst.setString(3, txtKapasitas.getText().trim());
            pst.setString(4, txtHarga.getText().trim());
            pst.setString(5, cmbStatus.getSelectedItem().toString());
            pst.setString(6, kd);
            pst.executeUpdate(); pst.close();
            JOptionPane.showMessageDialog(inputDialog, "Data berhasil diubah!");
            loadData(); clearDialogForm();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(inputDialog, "Error: " + e.getMessage());
        }
    }

    private void hapus() {
        String kd = txtKdRuangan.getText().trim();
        if (kd.isEmpty()) return;
        try {
            String sql = "DELETE FROM ruangan WHERE kd_ruangan=?";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, kd);
            pst.executeUpdate(); pst.close();
            JOptionPane.showMessageDialog(inputDialog, "Data berhasil dihapus!");
            loadData(); clearDialogForm();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(inputDialog, "Error: " + e.getMessage());
        }
    }

    private void cetakData() {
        int rowCount = tableRuangan.getRowCount();
        if (rowCount == 0) {
            JOptionPane.showMessageDialog(this, "Tidak ada data untuk dicetak!");
            return;
        }
        
        StringBuilder sb = new StringBuilder();
        sb.append("=== DATA RUANGAN ===\n");
        sb.append("========================================\n\n");
        
        for (int i = 0; i < rowCount; i++) {
            sb.append((i+1) + ". ");
            sb.append("Kode: ").append(tableRuangan.getValueAt(i, 0)).append("\n");
            sb.append("   Nama Ruangan: ").append(tableRuangan.getValueAt(i, 1)).append("\n");
            sb.append("   Kelas: ").append(tableRuangan.getValueAt(i, 2)).append("\n");
            sb.append("   Kapasitas: ").append(tableRuangan.getValueAt(i, 3)).append(" tempat tidur\n");
            sb.append("   Harga: Rp ").append(tableRuangan.getValueAt(i, 4)).append(" /hari\n");
            sb.append("   Status: ").append(tableRuangan.getValueAt(i, 5)).append("\n");
            sb.append("----------------------------------------\n");
        }
        sb.append("\nTotal Ruangan: ").append(rowCount);
        
        JTextArea textArea = new JTextArea(sb.toString());
        textArea.setEditable(false);
        textArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(500, 400));
        JOptionPane.showMessageDialog(this, scrollPane, "Preview Cetak Data Ruangan", JOptionPane.INFORMATION_MESSAGE);
    }

    private void clearDialogForm() {
        txtKdRuangan.setText(""); txtNamaRuangan.setText("");
        txtKelas.setText(""); txtKapasitas.setText("");
        txtHarga.setText(""); cmbStatus.setSelectedIndex(0);
    }
}