/*
 * Form Pemeriksaan - Pemeriksaan pasien setelah pendaftaran
 * Sekarang bisa langsung pilih obat dan hitung total otomatis
 */
package tampilan;

import javax.swing.*;
import javax.swing.table.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.ArrayList;

public class form_periksa extends JPanel {
    private Connection conn;
    private DefaultTableModel tableModel, tableObatModel;
    
    private static final Color SIDEBAR_BG = new Color(0x1B4332);
    private static final Color SIDEBAR_ACTIVE = new Color(0x2D6A4F);
    private static final Color BUTTON_GREEN = new Color(0x52B788);
    private static final Color CONTENT_BG = new Color(0xF4F6F4);
    private static final Color TABLE_HEADER = new Color(0x1B4332);
    
    private JTextField txtFilterPasien, txtFilterDokter;
    private JButton btnFilter, btnTambah, btnCetak, btnRefresh, btnTambahObat, btnHapusObat;
    private JTable tablePeriksa, tableObatTemp;
    private JLabel lblTotalPeriksa, lblTotalBiaya;
    
    private JDialog inputDialog;
    private JTextField txtIdPeriksa, txtTglPeriksa, txtBiayaPeriksa;
    private JTextArea txtDiagnosa;
    private JComboBox<String> cmbIdDaftar, cmbIdObat;
    private JTextField txtJumlahObat;
    
    private String lastIdPeriksa;
    private ArrayList<ObatTemp> listObatTemp = new ArrayList<>();
    
    // Class untuk menyimpan obat sementara
    class ObatTemp {
        String idObat, namaObat;
        int jumlah;
        double harga, subtotal;
        
        ObatTemp(String idObat, String namaObat, int jumlah, double harga) {
            this.idObat = idObat;
            this.namaObat = namaObat;
            this.jumlah = jumlah;
            this.harga = harga;
            this.subtotal = jumlah * harga;
        }
    }
    
    public form_periksa() {
        koneksi.koneksi k = new koneksi.koneksi();
        conn = k.Connect();
        
        if (conn == null) {
            JOptionPane.showMessageDialog(this, "Gagal koneksi ke database!");
            return;
        }
        
        initComponents();
        loadData();
        loadComboData();
        createInputDialog();
    }
    
    private void initComponents() {
        setLayout(new BorderLayout());
        setBackground(CONTENT_BG);
        setBorder(new EmptyBorder(15, 20, 15, 20));

        JLabel headerTitle = new JLabel("Pemeriksaan");
        headerTitle.setFont(new Font("Segoe UI", Font.BOLD, 24));
        headerTitle.setForeground(SIDEBAR_BG);
        headerTitle.setBorder(new EmptyBorder(0, 0, 15, 0));

        // Filter Panel
        JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 8));
        filterPanel.setBackground(CONTENT_BG);
        filterPanel.setBorder(new EmptyBorder(0, 0, 15, 0));

        int fieldHeight = 36;

        JPanel pasienPanel = createFilterField("Nama Pasien", txtFilterPasien = new JTextField(18));
        filterPanel.add(pasienPanel);

        JPanel dokterPanel = createFilterField("Nama Dokter", txtFilterDokter = new JTextField(18));
        filterPanel.add(dokterPanel);

        JPanel btnFilterWrapper = new JPanel(new BorderLayout());
        btnFilterWrapper.setBackground(CONTENT_BG);
        btnFilterWrapper.setBorder(new EmptyBorder(22, 0, 0, 0));

        btnFilter = new JButton("Terapkan Filter");
        btnFilter.setBackground(SIDEBAR_BG);
        btnFilter.setForeground(Color.WHITE);
        btnFilter.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnFilter.setFocusPainted(false);
        btnFilter.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnFilter.setPreferredSize(new Dimension(140, fieldHeight));
        btnFilter.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { btnFilter.setBackground(SIDEBAR_ACTIVE); }
            public void mouseExited(MouseEvent e) { btnFilter.setBackground(SIDEBAR_BG); }
        });
        btnFilterWrapper.add(btnFilter, BorderLayout.NORTH);
        filterPanel.add(btnFilterWrapper);

        // Button Panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 8));
        buttonPanel.setBackground(CONTENT_BG);
        buttonPanel.setBorder(new EmptyBorder(0, 0, 15, 0));

        btnTambah = new JButton("+ Tambah Pemeriksaan Baru");
        btnTambah.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnTambah.setBackground(SIDEBAR_BG);
        btnTambah.setForeground(Color.WHITE);
        btnTambah.setFocusPainted(false);
        btnTambah.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnTambah.setBorder(new EmptyBorder(10, 18, 10, 18));

        btnCetak = new JButton("🖨️ Cetak");
        btnCetak.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnCetak.setBackground(new Color(0x6C757D));
        btnCetak.setForeground(Color.WHITE);
        btnCetak.setFocusPainted(false);
        btnCetak.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnCetak.setBorder(new EmptyBorder(10, 25, 10, 25));

        btnRefresh = new JButton("⟳ Refresh");
        btnRefresh.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnRefresh.setBackground(SIDEBAR_ACTIVE);
        btnRefresh.setForeground(Color.WHITE);
        btnRefresh.setFocusPainted(false);
        btnRefresh.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnRefresh.setBorder(new EmptyBorder(10, 25, 10, 25));

        buttonPanel.add(btnTambah);
        buttonPanel.add(btnCetak);
        buttonPanel.add(btnRefresh);

        // Table Pemeriksaan
        String[] columns = {"ID Periksa", "ID Daftar", "Pasien", "Dokter", "Diagnosa", "Tgl Periksa", "Biaya", "Total Obat", "Grand Total"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override public boolean isCellEditable(int row, int column) { return false; }
        };

        tablePeriksa = new JTable(tableModel);
        tablePeriksa.setRowHeight(60);
        tablePeriksa.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        tablePeriksa.setSelectionBackground(new Color(0xD8F3DC));
        tablePeriksa.setSelectionForeground(SIDEBAR_BG);
        tablePeriksa.setGridColor(new Color(0xE0E0E0));
        tablePeriksa.setShowVerticalLines(true);
        tablePeriksa.setShowHorizontalLines(true);
        tablePeriksa.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);

        JTableHeader header = tablePeriksa.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 13));
        header.setBackground(TABLE_HEADER);
        header.setForeground(Color.BLACK);
        header.setPreferredSize(new Dimension(0, 35));

        JScrollPane scrollPane = new JScrollPane(tablePeriksa);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(0xE0E0E0)));
        scrollPane.getViewport().setBackground(Color.WHITE);

        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        bottomPanel.setBackground(CONTENT_BG);
        bottomPanel.setBorder(new EmptyBorder(15, 0, 0, 0));
        lblTotalPeriksa = new JLabel("Total Pemeriksaan: 0");
        lblTotalPeriksa.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblTotalPeriksa.setForeground(SIDEBAR_BG);
        bottomPanel.add(lblTotalPeriksa);

        JPanel northPanel = new JPanel(new BorderLayout(0, 8));
        northPanel.setBackground(CONTENT_BG);
        northPanel.add(headerTitle, BorderLayout.NORTH);
        northPanel.add(filterPanel, BorderLayout.CENTER);
        northPanel.add(buttonPanel, BorderLayout.SOUTH);

        add(northPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);

        btnTambah.addActionListener(e -> showInputDialog(false, null));
        btnFilter.addActionListener(e -> applyFilter());
        btnRefresh.addActionListener(e -> { resetFilter(); loadData(); });
        btnCetak.addActionListener(e -> cetakData());

        tablePeriksa.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    int row = tablePeriksa.getSelectedRow();
                    if (row >= 0) showInputDialog(true, row);
                }
            }
        });
    }
    
    private JPanel createFilterField(String labelText, JTextField field) {
        JPanel panel = new JPanel(new BorderLayout(5, 3));
        panel.setBackground(CONTENT_BG);
        JLabel lbl = new JLabel(labelText);
        lbl.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lbl.setForeground(SIDEBAR_BG);
        field.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        field.setPreferredSize(new Dimension(180, 36));
        field.addActionListener(e -> applyFilter());
        panel.add(lbl, BorderLayout.NORTH);
        panel.add(field, BorderLayout.CENTER);
        return panel;
    }
    
    private void loadComboData() {
        try {
            cmbIdDaftar = new JComboBox<>();
            Statement st = conn.createStatement();
            
            ResultSet rs = st.executeQuery(
                "SELECT d.id_daftar, d.nama_pasien, dk.nama as nama_dokter " +
                "FROM daftar_berobat d " +
                "LEFT JOIN dokter dk ON d.kd_dokter = dk.kd_dokter " +
                "WHERE d.status = 'Menunggu' " +
                "ORDER BY d.tgl_daftar DESC"
            );
            
            if (!rs.isBeforeFirst()) {
                cmbIdDaftar.addItem("--- Tidak ada pendaftaran menunggu ---");
            } else {
                while (rs.next()) {
                    cmbIdDaftar.addItem(rs.getString("id_daftar") + " - " + rs.getString("nama_pasien") + " (Dokter: " + rs.getString("nama_dokter") + ")");
                }
            }
            rs.close();
            
            // Load obat untuk combo
            cmbIdObat = new JComboBox<>();
            rs = st.executeQuery("SELECT id_obat, nama_obat, harga FROM obat ORDER BY nama_obat");
            while (rs.next()) {
                cmbIdObat.addItem(rs.getString("id_obat") + " - " + rs.getString("nama_obat") + " (Rp " + String.format("%,.0f", rs.getDouble("harga")) + ")");
            }
            rs.close();
            st.close();
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading combo data: " + e.getMessage());
        }
    }
    
    private void createInputDialog() {
        inputDialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(this), "Input Pemeriksaan", true);
        inputDialog.setSize(750, 650);
        inputDialog.setLocationRelativeTo(this);
        inputDialog.setResizable(true);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(Color.WHITE);
        
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(new EmptyBorder(20, 25, 10, 25));
        formPanel.setBackground(Color.WHITE);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 12, 8, 12);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // ID Periksa
        gbc.gridy = 0;
        gbc.gridx = 0; gbc.weightx = 0;
        JLabel lblId = new JLabel("ID Periksa");
        lblId.setFont(new Font("Segoe UI", Font.BOLD, 13));
        formPanel.add(lblId, gbc);
        gbc.gridx = 1; gbc.weightx = 1.0;
        txtIdPeriksa = new JTextField(20);
        txtIdPeriksa.setEditable(false);
        txtIdPeriksa.setBackground(new Color(0xF5F5F5));
        formPanel.add(txtIdPeriksa, gbc);

        // ID Daftar
        gbc.gridy = 1;
        gbc.gridx = 0; gbc.weightx = 0;
        JLabel lblDaftar = new JLabel("Pilih Pendaftaran");
        lblDaftar.setFont(new Font("Segoe UI", Font.BOLD, 13));
        formPanel.add(lblDaftar, gbc);
        gbc.gridx = 1; gbc.weightx = 1.0;
        formPanel.add(cmbIdDaftar, gbc);

        // Diagnosa
        gbc.gridy = 2;
        gbc.gridx = 0; gbc.weightx = 0;
        JLabel lblDiagnosa = new JLabel("Diagnosa");
        lblDiagnosa.setFont(new Font("Segoe UI", Font.BOLD, 13));
        formPanel.add(lblDiagnosa, gbc);
        gbc.gridx = 1; gbc.weightx = 1.0;
        txtDiagnosa = new JTextArea(3, 20);
        txtDiagnosa.setLineWrap(true);
        JScrollPane scrollDiagnosa = new JScrollPane(txtDiagnosa);
        scrollDiagnosa.setPreferredSize(new Dimension(400, 70));
        formPanel.add(scrollDiagnosa, gbc);

        // Tanggal Periksa
        gbc.gridy = 3;
        gbc.gridx = 0; gbc.weightx = 0;
        JLabel lblTgl = new JLabel("Tanggal Periksa");
        lblTgl.setFont(new Font("Segoe UI", Font.BOLD, 13));
        formPanel.add(lblTgl, gbc);
        gbc.gridx = 1; gbc.weightx = 1.0;
        txtTglPeriksa = new JTextField(20);
        txtTglPeriksa.setText(java.time.LocalDate.now().toString());
        formPanel.add(txtTglPeriksa, gbc);

        // Biaya Pemeriksaan
        gbc.gridy = 4;
        gbc.gridx = 0; gbc.weightx = 0;
        JLabel lblBiaya = new JLabel("Biaya Pemeriksaan (Rp)");
        lblBiaya.setFont(new Font("Segoe UI", Font.BOLD, 13));
        formPanel.add(lblBiaya, gbc);
        gbc.gridx = 1; gbc.weightx = 1.0;
        txtBiayaPeriksa = new JTextField(20);
        formPanel.add(txtBiayaPeriksa, gbc);
        
        // Panel Obat (Pilih Obat)
        JPanel obatPanel = new JPanel(new GridBagLayout());
        obatPanel.setBorder(BorderFactory.createTitledBorder("Tambah Resep Obat"));
        obatPanel.setBackground(Color.WHITE);
        
        GridBagConstraints gbcObat = new GridBagConstraints();
        gbcObat.insets = new Insets(5, 10, 5, 10);
        gbcObat.anchor = GridBagConstraints.WEST;
        gbcObat.fill = GridBagConstraints.HORIZONTAL;
        
        gbcObat.gridy = 0;
        gbcObat.gridx = 0;
        obatPanel.add(new JLabel("Pilih Obat:"), gbcObat);
        gbcObat.gridx = 1;
        gbcObat.gridwidth = 2;
        obatPanel.add(cmbIdObat, gbcObat);
        
        gbcObat.gridy = 1;
        gbcObat.gridx = 0;
        gbcObat.gridwidth = 1;
        obatPanel.add(new JLabel("Jumlah:"), gbcObat);
        gbcObat.gridx = 1;
        txtJumlahObat = new JTextField(10);
        txtJumlahObat.setPreferredSize(new Dimension(80, 28));
        obatPanel.add(txtJumlahObat, gbcObat);
        gbcObat.gridx = 2;
        btnTambahObat = new JButton("+ Tambah Obat");
        btnTambahObat.setBackground(SIDEBAR_ACTIVE);
        btnTambahObat.setForeground(Color.WHITE);
        btnTambahObat.setFocusPainted(false);
        obatPanel.add(btnTambahObat, gbcObat);
        
        // Table Obat Temporary
        String[] kolomObat = {"ID Obat", "Nama Obat", "Jumlah", "Harga", "Subtotal"};
        tableObatModel = new DefaultTableModel(kolomObat, 0) {
            @Override public boolean isCellEditable(int row, int column) { return false; }
        };
        tableObatTemp = new JTable(tableObatModel);
        tableObatTemp.setRowHeight(35);
        JScrollPane scrollObat = new JScrollPane(tableObatTemp);
        scrollObat.setPreferredSize(new Dimension(550, 120));
        
        gbcObat.gridy = 2;
        gbcObat.gridx = 0;
        gbcObat.gridwidth = 3;
        obatPanel.add(scrollObat, gbcObat);
        
        gbcObat.gridy = 3;
        gbcObat.gridx = 2;
        gbcObat.gridwidth = 1;
        btnHapusObat = new JButton("🗑 Hapus Obat Terpilih");
        btnHapusObat.setBackground(new Color(0xDC3545));
        btnHapusObat.setForeground(Color.WHITE);
        btnHapusObat.setFocusPainted(false);
        obatPanel.add(btnHapusObat, gbcObat);
        
        // Total Biaya Panel
        JPanel totalPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        totalPanel.setBackground(Color.WHITE);
        totalPanel.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        lblTotalBiaya = new JLabel("Total Biaya: Rp 0");
        lblTotalBiaya.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblTotalBiaya.setForeground(new Color(0xDC3545));
        totalPanel.add(lblTotalBiaya);
        
        // Buttons
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        JButton btnSimpan = new JButton("💾 Simpan & Selesai");
        JButton btnUbah = new JButton("✏️ Ubah");
        JButton btnHapus = new JButton("🗑 Hapus");
        JButton btnBatal = new JButton("❌ Batal");
        
        btnSimpan.setBackground(BUTTON_GREEN);
        btnUbah.setBackground(new Color(0xFFC107));
        btnHapus.setBackground(new Color(0xDC3545));
        btnBatal.setBackground(new Color(0x6C757D));
        btnSimpan.setForeground(Color.WHITE);
        btnUbah.setForeground(Color.WHITE);
        btnHapus.setForeground(Color.WHITE);
        btnBatal.setForeground(Color.WHITE);
        btnSimpan.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnUbah.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnHapus.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnBatal.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnSimpan.setPreferredSize(new Dimension(130, 40));
        btnUbah.setPreferredSize(new Dimension(100, 38));
        btnHapus.setPreferredSize(new Dimension(100, 38));
        btnBatal.setPreferredSize(new Dimension(100, 38));
        
        btnPanel.add(btnSimpan);
        btnPanel.add(btnUbah);
        btnPanel.add(btnHapus);
        btnPanel.add(btnBatal);
        
        // Susun main panel
        mainPanel.add(formPanel, BorderLayout.NORTH);
        mainPanel.add(obatPanel, BorderLayout.CENTER);
        mainPanel.add(totalPanel, BorderLayout.SOUTH);
        mainPanel.add(btnPanel, BorderLayout.SOUTH);
        
        inputDialog.add(mainPanel, BorderLayout.CENTER);
        
        // Action Listeners
        btnTambahObat.addActionListener(e -> tambahObat());
        btnHapusObat.addActionListener(e -> hapusObatTerpilih());
        btnSimpan.addActionListener(e -> { simpan(); inputDialog.dispose(); });
        btnUbah.addActionListener(e -> { ubah(); inputDialog.dispose(); });
        btnHapus.addActionListener(e -> {
            if (JOptionPane.showConfirmDialog(inputDialog, "Yakin hapus data pemeriksaan ini?", "Konfirmasi", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
                hapus(); inputDialog.dispose();
            }
        });
        btnBatal.addActionListener(e -> inputDialog.dispose());
    }
    
    private void tambahObat() {
        if (cmbIdObat.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(inputDialog, "Pilih obat terlebih dahulu!");
            return;
        }
        
        String selected = cmbIdObat.getSelectedItem().toString();
        if (selected.startsWith("---")) {
            JOptionPane.showMessageDialog(inputDialog, "Pilih obat yang valid!");
            return;
        }
        
        String idObat = selected.split(" - ")[0];
        String namaObat = selected.split(" - ")[1].split(" \\(")[0];
        String hargaStr = selected.split("Rp ")[1].replace(")", "").replace(",", "");
        
        String jumlahStr = txtJumlahObat.getText().trim();
        if (jumlahStr.isEmpty()) {
            JOptionPane.showMessageDialog(inputDialog, "Masukkan jumlah!");
            return;
        }
        
        int jumlah;
        try {
            jumlah = Integer.parseInt(jumlahStr);
            if (jumlah <= 0) throw new NumberFormatException();
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(inputDialog, "Jumlah harus angka positif!");
            return;
        }
        
        double harga = Double.parseDouble(hargaStr);
        
        // Cek apakah obat sudah ada di list
        for (ObatTemp o : listObatTemp) {
            if (o.idObat.equals(idObat)) {
                // Update jumlah
                o.jumlah += jumlah;
                o.subtotal = o.jumlah * o.harga;
                updateTableObat();
                updateTotalBiaya();
                txtJumlahObat.setText("");
                JOptionPane.showMessageDialog(inputDialog, "Jumlah obat diperbarui!");
                return;
            }
        }
        
        // Tambah obat baru
        listObatTemp.add(new ObatTemp(idObat, namaObat, jumlah, harga));
        updateTableObat();
        updateTotalBiaya();
        txtJumlahObat.setText("");
        JOptionPane.showMessageDialog(inputDialog, "Obat berhasil ditambahkan!");
    }
    
    private void hapusObatTerpilih() {
        int selectedRow = tableObatTemp.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(inputDialog, "Pilih obat yang akan dihapus!");
            return;
        }
        listObatTemp.remove(selectedRow);
        updateTableObat();
        updateTotalBiaya();
    }
    
    private void updateTableObat() {
        tableObatModel.setRowCount(0);
        for (ObatTemp o : listObatTemp) {
            tableObatModel.addRow(new Object[]{
                o.idObat, o.namaObat, o.jumlah, 
                "Rp " + String.format("%,.0f", o.harga),
                "Rp " + String.format("%,.0f", o.subtotal)
            });
        }
    }
    
    private void updateTotalBiaya() {
        double biayaPeriksa = 0;
        try {
            biayaPeriksa = Double.parseDouble(txtBiayaPeriksa.getText().trim());
        } catch (NumberFormatException e) {}
        
        double totalObat = 0;
        for (ObatTemp o : listObatTemp) {
            totalObat += o.subtotal;
        }
        
        double grandTotal = biayaPeriksa + totalObat;
        lblTotalBiaya.setText(String.format("Total Biaya: Rp %,.0f (Periksa: Rp %,.0f + Obat: Rp %,.0f)", 
                              grandTotal, biayaPeriksa, totalObat));
    }
    
    private void simpanResepKeDatabase(String idPeriksa) {
        try {
            for (ObatTemp o : listObatTemp) {
                String sql = "INSERT INTO resep (id_resep, id_periksa, id_obat, jumlah) VALUES (?, ?, ?, ?)";
                PreparedStatement pst = conn.prepareStatement(sql);
                String idResep = generateIdResep();
                pst.setString(1, idResep);
                pst.setString(2, idPeriksa);
                pst.setString(3, o.idObat);
                pst.setInt(4, o.jumlah);
                pst.executeUpdate();
                pst.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    private String generateIdResep() {
        try {
            String sql = "SELECT id_resep FROM resep ORDER BY id_resep DESC LIMIT 1";
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            int newNumber = 1;
            if (rs.next()) {
                String last = rs.getString("id_resep");
                if (last != null && last.length() > 2) {
                    newNumber = Integer.parseInt(last.substring(2)) + 1;
                }
            }
            return String.format("RP%03d", newNumber);
        } catch (Exception e) {
            return "RP001";
        }
    }

    private void showInputDialog(boolean isEdit, Integer row) {
        clearDialogForm();
        loadComboData();
        listObatTemp.clear();
        updateTableObat();
        
        if (isEdit && row != null) {
            txtIdPeriksa.setText(tableModel.getValueAt(row, 0).toString());
            String idDaftar = tableModel.getValueAt(row, 1).toString();
            for (int i = 0; i < cmbIdDaftar.getItemCount(); i++) {
                if (cmbIdDaftar.getItemAt(i).startsWith(idDaftar)) {
                    cmbIdDaftar.setSelectedIndex(i);
                    break;
                }
            }
            txtDiagnosa.setText(tableModel.getValueAt(row, 4).toString());
            txtTglPeriksa.setText(tableModel.getValueAt(row, 5).toString());
            String biaya = tableModel.getValueAt(row, 6).toString().replace("Rp ", "").replace(",", "");
            txtBiayaPeriksa.setText(biaya);
            inputDialog.setTitle("Edit Pemeriksaan");
        } else {
            generateIdPeriksa();
            txtTglPeriksa.setText(java.time.LocalDate.now().toString());
            txtDiagnosa.setText("");
            txtBiayaPeriksa.setText("");
            inputDialog.setTitle("Tambah Pemeriksaan");
        }
        inputDialog.setVisible(true);
    }

    private void loadData() { loadDataWithFilter("", ""); }
    private void applyFilter() { loadDataWithFilter(txtFilterPasien.getText().trim(), txtFilterDokter.getText().trim()); }
    private void resetFilter() { txtFilterPasien.setText(""); txtFilterDokter.setText(""); loadData(); }

    private void loadDataWithFilter(String namaPasien, String namaDokter) {
        tableModel.setRowCount(0);
        if (conn == null) return;

        StringBuilder sql = new StringBuilder(
            "SELECT p.id_periksa, p.id_daftar, d.nama_pasien, " +
            "dk.nama as nama_dokter, p.diagnosa, p.tgl_periksa, p.biaya " +
            "FROM periksa p " +
            "JOIN daftar_berobat d ON p.id_daftar = d.id_daftar " +
            "LEFT JOIN dokter dk ON d.kd_dokter = dk.kd_dokter WHERE 1=1"
        );
        ArrayList<Object> params = new ArrayList<>();

        if (!namaPasien.isEmpty()) { sql.append(" AND d.nama_pasien LIKE ?"); params.add("%" + namaPasien + "%"); }
        if (!namaDokter.isEmpty()) { sql.append(" AND dk.nama LIKE ?"); params.add("%" + namaDokter + "%"); }
        sql.append(" ORDER BY p.tgl_periksa DESC");

        try (PreparedStatement pst = conn.prepareStatement(sql.toString())) {
            for (int i = 0; i < params.size(); i++) pst.setObject(i + 1, params.get(i));
            ResultSet rs = pst.executeQuery();
            int count = 0;
            while (rs.next()) {
                // Hitung total obat untuk pemeriksaan ini
                double totalObat = 0;
                String sqlObat = "SELECT SUM(subtotal) as total FROM resep WHERE id_periksa = ?";
                PreparedStatement pstObat = conn.prepareStatement(sqlObat);
                pstObat.setString(1, rs.getString("id_periksa"));
                ResultSet rsObat = pstObat.executeQuery();
                if (rsObat.next() && rsObat.getDouble("total") > 0) {
                    totalObat = rsObat.getDouble("total");
                }
                rsObat.close();
                pstObat.close();
                
                double biaya = rs.getDouble("biaya");
                double grandTotal = biaya + totalObat;
                
                tableModel.addRow(new Object[]{
                    rs.getString("id_periksa"),
                    rs.getString("id_daftar"),
                    rs.getString("nama_pasien"),
                    rs.getString("nama_dokter") != null ? rs.getString("nama_dokter") : "-",
                    rs.getString("diagnosa"),
                    rs.getString("tgl_periksa"),
                    "Rp " + String.format("%,.0f", biaya),
                    "Rp " + String.format("%,.0f", totalObat),
                    "Rp " + String.format("%,.0f", grandTotal)
                });
                count++;
            }
            lblTotalPeriksa.setText("Total Pemeriksaan: " + count);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error load data: " + e.getMessage());
        }
    }

    private void generateIdPeriksa() {
        try {
            String sql = "SELECT id_periksa FROM periksa ORDER BY id_periksa DESC LIMIT 1";
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            int newNumber = 1;
            if (rs.next()) {
                String last = rs.getString("id_periksa");
                if (last != null && last.length() > 2) newNumber = Integer.parseInt(last.substring(2)) + 1;
            }
            txtIdPeriksa.setText(String.format("PR%03d", newNumber));
        } catch (Exception e) {
            txtIdPeriksa.setText("PR001");
        }
    }

    private void simpan() {
        String idPeriksa = txtIdPeriksa.getText().trim();
        
        if (cmbIdDaftar.getItemCount() == 0 || cmbIdDaftar.getItemAt(0).startsWith("---")) {
            JOptionPane.showMessageDialog(inputDialog, "Tidak ada pendaftaran yang menunggu pemeriksaan!");
            return;
        }
        
        String selectedItem = cmbIdDaftar.getSelectedItem().toString();
        if (selectedItem.startsWith("---")) {
            JOptionPane.showMessageDialog(inputDialog, "Pilih pendaftaran yang valid!");
            return;
        }
        
        String idDaftar = selectedItem.split(" - ")[0];
        String diagnosa = txtDiagnosa.getText().trim();
        String tglPeriksa = txtTglPeriksa.getText().trim();
        String biayaStr = txtBiayaPeriksa.getText().trim();

        if (idPeriksa.isEmpty() || idDaftar.isEmpty() || diagnosa.isEmpty() || tglPeriksa.isEmpty() || biayaStr.isEmpty()) {
            JOptionPane.showMessageDialog(inputDialog, "Semua field harus diisi!");
            return;
        }

        double biaya;
        try {
            biaya = Double.parseDouble(biayaStr);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(inputDialog, "Biaya harus berupa angka!");
            return;
        }

        try {
            String cekSql = "SELECT COUNT(*) FROM periksa WHERE id_periksa = ?";
            PreparedStatement cekPst = conn.prepareStatement(cekSql);
            cekPst.setString(1, idPeriksa);
            ResultSet rs = cekPst.executeQuery();
            rs.next();
            if (rs.getInt(1) > 0) {
                JOptionPane.showMessageDialog(inputDialog, "ID Periksa sudah ada!");
                return;
            }
            rs.close(); cekPst.close();
            
            String sql = "INSERT INTO periksa (id_periksa, id_daftar, diagnosa, tgl_periksa, biaya) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, idPeriksa);
            pst.setString(2, idDaftar);
            pst.setString(3, diagnosa);
            pst.setString(4, tglPeriksa);
            pst.setDouble(5, biaya);
            pst.executeUpdate();
            pst.close();
            
            // Simpan resep ke database
            simpanResepKeDatabase(idPeriksa);
            
            String updateStatus = "UPDATE daftar_berobat SET status = 'Selesai' WHERE id_daftar = ?";
            PreparedStatement pst2 = conn.prepareStatement(updateStatus);
            pst2.setString(1, idDaftar);
            pst2.executeUpdate();
            pst2.close();
            
            lastIdPeriksa = idPeriksa;
            
            double totalObat = 0;
            for (ObatTemp o : listObatTemp) totalObat += o.subtotal;
            JOptionPane.showMessageDialog(inputDialog, String.format(
                "Pemeriksaan berhasil disimpan!\nBiaya Periksa: Rp %,.0f\nTotal Obat: Rp %,.0f\nGrand Total: Rp %,.0f",
                biaya, totalObat, biaya + totalObat));
            
            loadData();
            clearDialogForm();
            loadComboData();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(inputDialog, "Error: " + e.getMessage());
        }
    }

    private void ubah() {
        String idPeriksa = txtIdPeriksa.getText().trim();
        if (idPeriksa.isEmpty()) return;
        
        String selectedItem = cmbIdDaftar.getSelectedItem().toString();
        String idDaftar = selectedItem.split(" - ")[0];
        String diagnosa = txtDiagnosa.getText().trim();
        String tglPeriksa = txtTglPeriksa.getText().trim();
        String biayaStr = txtBiayaPeriksa.getText().trim();

        try {
            String sql = "UPDATE periksa SET id_daftar=?, diagnosa=?, tgl_periksa=?, biaya=? WHERE id_periksa=?";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, idDaftar);
            pst.setString(2, diagnosa);
            pst.setString(3, tglPeriksa);
            pst.setDouble(4, Double.parseDouble(biayaStr));
            pst.setString(5, idPeriksa);
            pst.executeUpdate();
            pst.close();
            
            // Hapus resep lama, simpan resep baru
            String deleteResep = "DELETE FROM resep WHERE id_periksa = ?";
            PreparedStatement pstDel = conn.prepareStatement(deleteResep);
            pstDel.setString(1, idPeriksa);
            pstDel.executeUpdate();
            pstDel.close();
            
            simpanResepKeDatabase(idPeriksa);
            
            JOptionPane.showMessageDialog(inputDialog, "Data pemeriksaan berhasil diubah!");
            loadData();
            clearDialogForm();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(inputDialog, "Error: " + e.getMessage());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(inputDialog, "Biaya harus berupa angka!");
        }
    }

    private void hapus() {
        String idPeriksa = txtIdPeriksa.getText().trim();
        if (idPeriksa.isEmpty()) return;
        
        String idDaftar = "";
        try {
            String selectDaftar = "SELECT id_daftar FROM periksa WHERE id_periksa = ?";
            PreparedStatement pstSelect = conn.prepareStatement(selectDaftar);
            pstSelect.setString(1, idPeriksa);
            ResultSet rs = pstSelect.executeQuery();
            if (rs.next()) idDaftar = rs.getString("id_daftar");
            rs.close(); pstSelect.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(inputDialog, "Error: " + e.getMessage());
            return;
        }
        
        if (idDaftar.isEmpty()) return;
        
        int confirm = JOptionPane.showConfirmDialog(inputDialog, 
            "Yakin ingin menghapus pemeriksaan ini?\nSemua resep terkait juga akan dihapus!", 
            "Konfirmasi Hapus", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) return;
        
        try {
            String sql = "DELETE FROM periksa WHERE id_periksa=?";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, idPeriksa);
            pst.executeUpdate();
            pst.close();
            
            String updateStatus = "UPDATE daftar_berobat SET status = 'Menunggu' WHERE id_daftar = ?";
            PreparedStatement pst2 = conn.prepareStatement(updateStatus);
            pst2.setString(1, idDaftar);
            pst2.executeUpdate();
            pst2.close();
            
            JOptionPane.showMessageDialog(inputDialog, "Data pemeriksaan berhasil dihapus!");
            loadData();
            clearDialogForm();
            loadComboData();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(inputDialog, "Error: " + e.getMessage());
        }
    }

    private void cetakData() {
        int rowCount = tablePeriksa.getRowCount();
        if (rowCount == 0) {
            JOptionPane.showMessageDialog(this, "Tidak ada data untuk dicetak!");
            return;
        }
        
        StringBuilder sb = new StringBuilder();
        sb.append("╔════════════════════════════════════════════════════════════════════════════════╗\n");
        sb.append("║                         LAPORAN PEMERIKSAAN                                    ║\n");
        sb.append("║                         RUMAH SAKIT SEHAT SENTOSA                              ║\n");
        sb.append("╠════════════════════════════════════════════════════════════════════════════════╣\n");
        sb.append("║ Dicetak: ").append(java.time.LocalDateTime.now().format(java.time.format.DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss")));
        for (int i = 0; i < 45 - java.time.LocalDateTime.now().format(java.time.format.DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss")).length(); i++) sb.append(" ");
        sb.append("║\n");
        sb.append("╠════════════════════════════════════════════════════════════════════════════════╣\n");
        
        for (int i = 0; i < rowCount; i++) {
            sb.append("║ ").append(String.format("%2d", i + 1)).append(". ");
            sb.append("ID Periksa: ").append(String.format("%-10s", tablePeriksa.getValueAt(i, 0))).append("║\n");
            sb.append("║    Pasien  : ").append(String.format("%-50s", tablePeriksa.getValueAt(i, 2).toString().length() > 50 ? tablePeriksa.getValueAt(i, 2).toString().substring(0, 50) : tablePeriksa.getValueAt(i, 2))).append("║\n");
            sb.append("║    Dokter  : ").append(String.format("%-50s", tablePeriksa.getValueAt(i, 3).toString().length() > 50 ? tablePeriksa.getValueAt(i, 3).toString().substring(0, 50) : tablePeriksa.getValueAt(i, 3))).append("║\n");
            sb.append("║    Diagnosa: ").append(String.format("%-50s", tablePeriksa.getValueAt(i, 4).toString().length() > 50 ? tablePeriksa.getValueAt(i, 4).toString().substring(0, 50) : tablePeriksa.getValueAt(i, 4))).append("║\n");
            sb.append("║    Tanggal : ").append(String.format("%-10s", tablePeriksa.getValueAt(i, 5)));
            sb.append("  Biaya Periksa: ").append(String.format("%-15s", tablePeriksa.getValueAt(i, 6)));
            sb.append("  Total Obat: ").append(String.format("%-15s", tablePeriksa.getValueAt(i, 7))).append("║\n");
            sb.append("║    GRAND TOTAL: ").append(String.format("%-67s", tablePeriksa.getValueAt(i, 8))).append("║\n");
            sb.append("╠════════════════════════════════════════════════════════════════════════════════╣\n");
        }
        
        sb.append("║ Total Pemeriksaan: ").append(String.format("%-62d", rowCount)).append("║\n");
        sb.append("╚════════════════════════════════════════════════════════════════════════════════╝\n");
        
        JTextArea textArea = new JTextArea(sb.toString());
        textArea.setEditable(false);
        textArea.setFont(new Font("Monospaced", Font.PLAIN, 11));
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(850, 500));
        JOptionPane.showMessageDialog(this, scrollPane, "Preview Cetak Pemeriksaan", JOptionPane.INFORMATION_MESSAGE);
    }

    private void clearDialogForm() {
        txtIdPeriksa.setText("");
        if (cmbIdDaftar != null && cmbIdDaftar.getItemCount() > 0 && !cmbIdDaftar.getItemAt(0).startsWith("---")) {
            cmbIdDaftar.setSelectedIndex(0);
        }
        txtDiagnosa.setText("");
        txtTglPeriksa.setText(java.time.LocalDate.now().toString());
        txtBiayaPeriksa.setText("");
        listObatTemp.clear();
        updateTableObat();
        txtJumlahObat.setText("");
    }
}