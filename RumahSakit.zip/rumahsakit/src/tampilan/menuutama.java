/*
 * Menu Utama - Hospital Management System
 * Semua form ditampilkan di dalam content panel (seperti form_perawat)
 * @author Advan (dimodifikasi)
 */
package tampilan;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import koneksi.koneksi;  // atau sesuaikan
/**
 * Menu Utama - Hospital Management System
 * Styling: sidebar hijau seperti tampilan HMS pada gambar referensi
 */
public class menuutama extends JFrame {

    private static final long serialVersionUID = 1L;
    private static final java.util.logging.Logger logger =
        java.util.logging.Logger.getLogger(menuutama.class.getName());

    // Palet warna HMS
    private static final Color SIDEBAR_BG      = new Color(0x1B4332);
    private static final Color SIDEBAR_ACTIVE  = new Color(0x2D6A4F);
    private static final Color SIDEBAR_HOVER   = new Color(0x255C42);
    private static final Color SIDEBAR_TEXT    = new Color(0xD8F3DC);
    private static final Color SIDEBAR_MUTED   = new Color(0x74C69D);
    private static final Color TOPBAR_BG       = Color.WHITE;
    private static final Color CONTENT_BG      = new Color(0xF4F6F4);
    private static final Color BRAND_ACCENT    = new Color(0x52B788);

    // Komponen sidebar
    private JPanel sidebarPanel;
    private JPanel contentPanel;
    private String activeMenu = "Dashboard";

    // Tombol navigasi
    private JButton bpasien, bdokter, bperawat, bdaftar, bperiksa, bresep, bobat, bruangan, blaporan, badmin, blogout;

    public menuutama() {
        buildUI();
        System.out.println("Menu utama terbuka");
    }

    // -------------------------------------------------------------------------
    // UI BUILDER
    // -------------------------------------------------------------------------

    private void buildUI() {
        setTitle("Hospital Management System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1200, 750);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        add(buildSidebar(), BorderLayout.WEST);
        add(buildMainArea(), BorderLayout.CENTER);
    }

    // --- SIDEBAR -------------------------------------------------------------

    private JPanel buildSidebar() {
        sidebarPanel = new JPanel();
        sidebarPanel.setPreferredSize(new Dimension(250, 0));
        sidebarPanel.setBackground(SIDEBAR_BG);
        sidebarPanel.setLayout(new BoxLayout(sidebarPanel, BoxLayout.Y_AXIS));
        sidebarPanel.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Brand
        sidebarPanel.add(buildBrand());
        sidebarPanel.add(Box.createVerticalStrut(4));

        // Section: Master Data
        sidebarPanel.add(buildSectionLabel("Master Data"));
        sidebarPanel.add(buildNavButton("Dashboard", "🏠", false));
        bpasien   = buildNavButton("Data Pasien",   "👤", false);
        bdokter   = buildNavButton("Data Dokter",   "🩺", false);
        bperawat  = buildNavButton("Data Perawat",  "💉", false);
        bobat     = buildNavButton("Data Obat",     "💊", false);
        bruangan  = buildNavButton("Data Ruangan",  "🏥", false);
        bdaftar   = buildNavButton("Pendaftaran",   "📋", false);

        sidebarPanel.add(bpasien);
        sidebarPanel.add(bdokter);
        sidebarPanel.add(bperawat);
        sidebarPanel.add(bobat);
        sidebarPanel.add(bruangan);
        sidebarPanel.add(bdaftar);

        // Section: Transaksi
        sidebarPanel.add(buildSectionLabel("Transaksi"));
        bperiksa  = buildNavButton("Pemeriksaan",   "🔬", false);
        bresep    = buildNavButton("Pembayaran",    "💳", false);
        sidebarPanel.add(bperiksa);
        sidebarPanel.add(bresep);

        // Section: Sistem
        sidebarPanel.add(buildSectionLabel("Sistem"));
        blaporan  = buildNavButton("Laporan",       "📊", false);
        badmin    = buildNavButton("Admin",         "⚙", false);
        sidebarPanel.add(blaporan);
        sidebarPanel.add(badmin);

        // Jarak sebelum logout
        sidebarPanel.add(Box.createVerticalGlue());

        // Logout di bawah
        blogout = buildNavButton("Keluar", "🚪", false);
        blogout.setForeground(new Color(0xFF6B6B));
        sidebarPanel.add(blogout);
        sidebarPanel.add(Box.createVerticalStrut(12));

        // Pasang action listeners
        wireActions();

        return sidebarPanel;
    }

    private JPanel buildBrand() {
        JPanel brand = new JPanel(new FlowLayout(FlowLayout.LEFT, 14, 14));
        brand.setBackground(SIDEBAR_BG);
        brand.setMaximumSize(new Dimension(Integer.MAX_VALUE, 64));
        brand.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel icon = new JLabel("🏥");
        icon.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 22));

        JPanel textPane = new JPanel();
        textPane.setLayout(new BoxLayout(textPane, BoxLayout.Y_AXIS));
        textPane.setBackground(SIDEBAR_BG);

        JLabel title = new JLabel("HMS");
        title.setFont(new Font("Segoe UI", Font.BOLD, 14));
        title.setForeground(Color.WHITE);

        JLabel sub = new JLabel("Hospital System");
        sub.setFont(new Font("Segoe UI", Font.PLAIN, 10));
        sub.setForeground(SIDEBAR_MUTED);

        textPane.add(title);
        textPane.add(sub);

        brand.add(icon);
        brand.add(textPane);

        brand.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(0x2D6A4F)));
        return brand;
    }

    private JLabel buildSectionLabel(String text) {
        JLabel lbl = new JLabel(text.toUpperCase());
        lbl.setFont(new Font("Segoe UI", Font.PLAIN, 10));
        lbl.setForeground(SIDEBAR_MUTED);
        lbl.setBorder(new EmptyBorder(14, 16, 4, 16));
        lbl.setAlignmentX(Component.LEFT_ALIGNMENT);
        lbl.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
        return lbl;
    }

    private JButton buildNavButton(String text, String emoji, boolean active) {
        JButton btn = new JButton(emoji + "  " + text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                if (getModel().isRollover()) {
                    g2.setColor(SIDEBAR_HOVER);
                    g2.fillRect(0, 0, getWidth(), getHeight());
                } else if (active || getText().contains(activeMenu)) {
                    g2.setColor(SIDEBAR_ACTIVE);
                    g2.fillRect(0, 0, getWidth(), getHeight());
                    g2.setColor(BRAND_ACCENT);
                    g2.fillRect(0, 0, 4, getHeight());
                } else {
                    g2.setColor(SIDEBAR_BG);
                    g2.fillRect(0, 0, getWidth(), getHeight());
                }
                g2.dispose();
                super.paintComponent(g);
            }
        };
        
        btn.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        btn.setForeground(active ? Color.WHITE : SIDEBAR_TEXT);
        btn.setBackground(active ? SIDEBAR_ACTIVE : SIDEBAR_BG);
        btn.setOpaque(false);
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setHorizontalAlignment(SwingConstants.LEFT);
        btn.setHorizontalTextPosition(SwingConstants.RIGHT);
        btn.setBorder(new EmptyBorder(10, 18, 10, 16));
        btn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        btn.setAlignmentX(Component.LEFT_ALIGNMENT);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        
        return btn;
    }

    // --- MAIN AREA -----------------------------------------------------------

    private JPanel buildMainArea() {
        JPanel main = new JPanel(new BorderLayout());
        main.setBackground(CONTENT_BG);

        // Topbar
        JPanel topbar = new JPanel(new BorderLayout());
        topbar.setBackground(TOPBAR_BG);
        topbar.setPreferredSize(new Dimension(0, 48));
        topbar.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(0xE0E0E0)));

        JLabel topTitle = new JLabel("  ☰  Hospital Management System");
        topTitle.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        topTitle.setForeground(new Color(0x333333));

        JLabel clock = new JLabel();
        clock.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        clock.setForeground(new Color(0x777777));
        clock.setBorder(new EmptyBorder(0, 0, 0, 16));
        updateClock(clock);

        Timer timer = new Timer(1000, e -> updateClock(clock));
        timer.start();

        topbar.add(topTitle, BorderLayout.WEST);
        topbar.add(clock, BorderLayout.EAST);

        // Content panel
        contentPanel = new JPanel();
        contentPanel.setBackground(CONTENT_BG);
        contentPanel.setLayout(new BorderLayout());
        
        // Tampilkan dashboard awal
        showDashboard();

        main.add(topbar, BorderLayout.NORTH);
        main.add(contentPanel, BorderLayout.CENTER);

        return main;
    }

    private void updateClock(JLabel lbl) {
        java.time.LocalDateTime now = java.time.LocalDateTime.now();
        String[] days = {"Minggu","Senin","Selasa","Rabu","Kamis","Jumat","Sabtu"};
        String[] months = {"Jan","Feb","Mar","Apr","Mei","Jun","Jul","Agt","Sep","Okt","Nov","Des"};
        String day = days[now.getDayOfWeek().getValue() % 7];
        String month = months[now.getMonthValue() - 1];
        lbl.setText(String.format("%s, %d %s %d  •  %02d:%02d:%02d",
            day, now.getDayOfMonth(), month, now.getYear(),
            now.getHour(), now.getMinute(), now.getSecond()));
    }

    // Method untuk mengganti konten
    public void setContentPanel(JPanel panel) {
        contentPanel.removeAll();
        contentPanel.add(panel, BorderLayout.CENTER);
        contentPanel.revalidate();
        contentPanel.repaint();
    }

    // --- DASHBOARD -----------------------------------------------------------

    private void showDashboard() {
        activeMenu = "Dashboard";
        
        JPanel dashboardPanel = new JPanel();
        dashboardPanel.setBackground(CONTENT_BG);
        dashboardPanel.setBorder(new EmptyBorder(24, 24, 24, 24));
        dashboardPanel.setLayout(new BoxLayout(dashboardPanel, BoxLayout.Y_AXIS));
        
        JLabel pageTitle = new JLabel("Dashboard");
        pageTitle.setFont(new Font("Segoe UI", Font.BOLD, 24));
        pageTitle.setForeground(SIDEBAR_BG);
        pageTitle.setAlignmentX(Component.LEFT_ALIGNMENT);
        dashboardPanel.add(pageTitle);
        dashboardPanel.add(Box.createVerticalStrut(6));

        JLabel sub = new JLabel("Selamat datang di Hospital Management System");
        sub.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        sub.setForeground(new Color(0x666666));
        sub.setAlignmentX(Component.LEFT_ALIGNMENT);
        dashboardPanel.add(sub);
        dashboardPanel.add(Box.createVerticalStrut(20));

        // Card grid (2x3)
        JPanel grid = new JPanel(new GridLayout(2, 3, 12, 12));
        grid.setBackground(CONTENT_BG);
        grid.setMaximumSize(new Dimension(Integer.MAX_VALUE, 220));
        grid.setAlignmentX(Component.LEFT_ALIGNMENT);

        grid.add(buildCard("👤", "Data Pasien",  "Kelola data pasien", new Color(0xE8F5E9)));
        grid.add(buildCard("🩺", "Data Dokter",  "Kelola data dokter", new Color(0xE3F2FD)));
        grid.add(buildCard("💉", "Data Perawat", "Kelola data perawat", new Color(0xFCE4EC)));
        grid.add(buildCard("💊", "Data Obat",    "Kelola stok obat",    new Color(0xFFF8E1)));
        grid.add(buildCard("📋", "Pendaftaran",  "Pendaftaran pasien",  new Color(0xE0F7FA)));
        grid.add(buildCard("🔬", "Pemeriksaan",  "Data pemeriksaan",    new Color(0xF3E5F5)));

        dashboardPanel.add(grid);
        
        dashboardPanel.add(Box.createVerticalStrut(24));
        dashboardPanel.add(buildStatsPanel());
        
        setContentPanel(dashboardPanel);
    }
    
    private JPanel buildStatsPanel() {
        JPanel statsPanel = new JPanel(new GridLayout(1, 4, 12, 12));
        statsPanel.setBackground(CONTENT_BG);
        statsPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 100));
        statsPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
        
        statsPanel.add(buildStatCard("Total Pasien", "124", "👥", new Color(0x1B4332)));
        statsPanel.add(buildStatCard("Total Dokter", "12", "🩺", new Color(0x2D6A4F)));
        statsPanel.add(buildStatCard("Pendaftaran Hari Ini", "8", "📋", new Color(0x52B788)));
        statsPanel.add(buildStatCard("Pembayaran", "Rp 4.2Jt", "💰", new Color(0x74C69D)));
        
        return statsPanel;
    }
    
    private JPanel buildStatCard(String title, String value, String emoji, Color color) {
        JPanel card = new JPanel();
        card.setLayout(new BorderLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(0xE0E0E0), 1, true),
            new EmptyBorder(12, 16, 12, 16)
        ));
        
        JLabel emojiLbl = new JLabel(emoji);
        emojiLbl.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 24));
        
        JLabel titleLbl = new JLabel(title);
        titleLbl.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        titleLbl.setForeground(new Color(0x888888));
        
        JLabel valueLbl = new JLabel(value);
        valueLbl.setFont(new Font("Segoe UI", Font.BOLD, 18));
        valueLbl.setForeground(color);
        
        JPanel textPanel = new JPanel();
        textPanel.setLayout(new BoxLayout(textPanel, BoxLayout.Y_AXIS));
        textPanel.setBackground(Color.WHITE);
        textPanel.add(titleLbl);
        textPanel.add(valueLbl);
        
        card.add(emojiLbl, BorderLayout.WEST);
        card.add(textPanel, BorderLayout.CENTER);
        
        return card;
    }

    private JPanel buildCard(String emoji, String title, String desc, Color bg) {
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(0xE0E0E0), 1, true),
            new EmptyBorder(16, 16, 16, 16)
        ));

        JPanel iconCircle = new JPanel();
        iconCircle.setBackground(bg);
        iconCircle.setPreferredSize(new Dimension(44, 44));
        iconCircle.setMaximumSize(new Dimension(44, 44));
        iconCircle.setLayout(new BorderLayout());
        iconCircle.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));

        JLabel emojiLbl = new JLabel(emoji, SwingConstants.CENTER);
        emojiLbl.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 22));
        iconCircle.add(emojiLbl);
        iconCircle.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel titleLbl = new JLabel(title);
        titleLbl.setFont(new Font("Segoe UI", Font.BOLD, 13));
        titleLbl.setForeground(SIDEBAR_BG);
        titleLbl.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel descLbl = new JLabel(desc);
        descLbl.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        descLbl.setForeground(new Color(0x888888));
        descLbl.setAlignmentX(Component.LEFT_ALIGNMENT);

        card.add(iconCircle);
        card.add(Box.createVerticalStrut(10));
        card.add(titleLbl);
        card.add(Box.createVerticalStrut(3));
        card.add(descLbl);

        card.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        
        card.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                navigateTo(title);
            }
        });
        
        return card;
    }

    // --- FORM SEMENTARA UNTUK YANG BELUM ADA ---------------------------------
    
    private JPanel createPlaceholderForm(String title) {
        JPanel panel = new JPanel();
        panel.setBackground(CONTENT_BG);
        panel.setBorder(new EmptyBorder(50, 50, 50, 50));
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        
        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        titleLabel.setForeground(SIDEBAR_BG);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        JLabel infoLabel = new JLabel("Form ini sedang dalam pengembangan.");
        infoLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        infoLabel.setForeground(new Color(0x666666));
        infoLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        panel.add(Box.createVerticalGlue());
        panel.add(titleLabel);
        panel.add(Box.createVerticalStrut(15));
        panel.add(infoLabel);
        panel.add(Box.createVerticalGlue());
        
        return panel;
    }

    // --- NAVIGATION ----------------------------------------------------------

    private void navigateTo(String menuName) {
        activeMenu = menuName;
        
        switch(menuName) {
            case "Dashboard":
                showDashboard();
                break;
            case "Data Pasien":
                showFormPasien();
                break;
            case "Data Dokter":
                showFormDokter();
                break;
            case "Data Perawat":
                showFormPerawat();
                break;
            case "Data Obat":
                showFormObat();
                break;
            case "Data Ruangan":
                showFormRuangan();
                break;
            case "Pendaftaran":
                showFormDaftar();
                break;
            case "Pemeriksaan":
                showFormPeriksa();
                break;
            case "Pembayaran":
                showFormPembayaran();
                break;
            case "Laporan":
                showLaporan();
                break;
            case "Admin":
                showAdmin();
                break;
            default:
                showDashboard();
        }
    }

    private void showFormPasien() {
        try {
            // Coba gunakan form_pasien jika sudah ada dan extends JPanel
            Class<?> formClass = Class.forName("tampilan.form_pasien");
            Object formInstance = formClass.getDeclaredConstructor().newInstance();
            if (formInstance instanceof JPanel) {
                setContentPanel((JPanel) formInstance);
            } else {
                setContentPanel(createPlaceholderForm("Data Pasien"));
            }
        } catch (Exception e) {
            // Form belum ada atau bukan JPanel, tampilkan placeholder
            setContentPanel(createPlaceholderForm("Data Pasien"));
        }
    }

    private void showFormDokter() {
        try {
            Class<?> formClass = Class.forName("tampilan.form_dokter");
            Object formInstance = formClass.getDeclaredConstructor().newInstance();
            if (formInstance instanceof JPanel) {
                setContentPanel((JPanel) formInstance);
            } else {
                setContentPanel(createPlaceholderForm("Data Dokter"));
            }
        } catch (Exception e) {
            setContentPanel(createPlaceholderForm("Data Dokter"));
        }
    }

    private void showFormPerawat() {
        try {
            setContentPanel(new form_perawat());
        } catch (Exception e) {
            setContentPanel(createPlaceholderForm("Data Perawat"));
        }
    }

    private void showFormObat() {
        try {
            setContentPanel(new form_obat());
        } catch (Exception e) {
            setContentPanel(createPlaceholderForm("Data Obat"));
        }
    }

    private void showFormRuangan() {
        try {
            Class<?> formClass = Class.forName("tampilan.form_ruangan");
            Object formInstance = formClass.getDeclaredConstructor().newInstance();
            if (formInstance instanceof JPanel) {
                setContentPanel((JPanel) formInstance);
            } else {
                setContentPanel(createPlaceholderForm("Data Ruangan"));
            }
        } catch (Exception e) {
            setContentPanel(createPlaceholderForm("Data Ruangan"));
        }
    }

    private void showFormDaftar() {
        try {
            Class<?> formClass = Class.forName("tampilan.form_daftar");
            Object formInstance = formClass.getDeclaredConstructor().newInstance();
            if (formInstance instanceof JPanel) {
                setContentPanel((JPanel) formInstance);
            } else {
                setContentPanel(createPlaceholderForm("Pendaftaran"));
            }
        } catch (Exception e) {
            setContentPanel(createPlaceholderForm("Pendaftaran"));
        }
    }

    // Method baru:
private void showFormPeriksa() {
    try {
        setContentPanel(new form_periksa());
    } catch (Exception e) {
        setContentPanel(createPlaceholderForm("Pemeriksaan"));
        e.printStackTrace();
    }
}

    private void showFormResep() {
        try {
            Class<?> formClass = Class.forName("tampilan.form_resep");
            Object formInstance = formClass.getDeclaredConstructor().newInstance();
            if (formInstance instanceof JPanel) {
                setContentPanel((JPanel) formInstance);
            } else {
                setContentPanel(createPlaceholderForm("Pembayaran"));
            }
        } catch (Exception e) {
            setContentPanel(createPlaceholderForm("Pembayaran"));
        }
    }
    
    // Method baru:
private void showFormPembayaran() {
    try {
        setContentPanel(new form_pembayaran());
    } catch (Exception e) {
        setContentPanel(createPlaceholderForm("Pembayaran"));
        e.printStackTrace();
    }
}

    private void showLaporan() {
        setContentPanel(createPlaceholderForm("Laporan"));
    }

    private void showAdmin() {
        setContentPanel(createPlaceholderForm("Admin"));
    }
    
    
    private void showLoginForm() {
    // Sembunyikan sidebar dulu atau nonaktifkan menu
    disableSidebar(true);
    
    // Tampilkan form login di content panel
    form_login loginPanel = new form_login();
    // Modifikasi form_login agar extend JPanel, bukan JFrame
    setContentPanel(loginPanel);
}

private void disableSidebar(boolean disabled) {
    Component[] components = sidebarPanel.getComponents();
    for (Component comp : components) {
        if (comp instanceof JButton) {
            comp.setEnabled(!disabled);
        }
    }
}

    // --- ACTION WIRING -------------------------------------------------------

    private void wireActions() {
        // Dashboard
        for (Component comp : sidebarPanel.getComponents()) {
            if (comp instanceof JButton) {
                JButton btn = (JButton) comp;
                if (btn.getText().contains("Dashboard")) {
                    btn.addActionListener(e -> navigateTo("Dashboard"));
                    break;
                }
            }
        }
        
        // Data Pasien
        bpasien.addActionListener(e -> navigateTo("Data Pasien"));
        
        // Data Dokter
        bdokter.addActionListener(e -> navigateTo("Data Dokter"));
        
        // Data Perawat
        bperawat.addActionListener(e -> navigateTo("Data Perawat"));
        
        // Data Obat
        bobat.addActionListener(e -> navigateTo("Data Obat"));
        
        // Data Ruangan
        bruangan.addActionListener(e -> navigateTo("Data Ruangan"));
        
        // Pendaftaran
        bdaftar.addActionListener(e -> navigateTo("Pendaftaran"));
        
        // Pemeriksaan
        bperiksa.addActionListener(e -> navigateTo("Pemeriksaan"));
        
        // Pembayaran
        bresep.addActionListener(e -> navigateTo("Pembayaran"));
        
        // Laporan
        blaporan.addActionListener(e -> navigateTo("Laporan"));
        
        // Admin
        badmin.addActionListener(e -> navigateTo("Admin"));
        
        // Logout
        blogout.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(this, 
                "Apakah Anda yakin ingin keluar?", 
                "Konfirmasi Keluar", 
                JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                new form_login().setVisible(true);
                this.dispose();
            }
        });
    }

    // -------------------------------------------------------------------------
    // MAIN
    // -------------------------------------------------------------------------

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel("com.formdev.flatlaf.FlatLightLaf");
        } catch (Exception ignored) {
            try {
                for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                    if ("Nimbus".equals(info.getName())) {
                        UIManager.setLookAndFeel(info.getClassName());
                        break;
                    }
                }
            } catch (Exception ex) {
                logger.log(java.util.logging.Level.SEVERE, null, ex);
            }
        }
        java.awt.EventQueue.invokeLater(() -> new menuutama().setVisible(true));
    }
}