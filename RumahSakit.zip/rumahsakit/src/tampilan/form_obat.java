/*
 * Form Data Obat - Layout konsisten dengan form_perawat
 * Author: Grok
 */
package tampilan;

import javax.swing.*;
import javax.swing.table.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.ArrayList;

public class form_obat extends JPanel {
    private Connection conn;
    private DefaultTableModel tableModel;
    
    // Warna tema HMS (sama dengan form_perawat)
    private static final Color SIDEBAR_BG = new Color(0x1B4332);
    private static final Color SIDEBAR_ACTIVE = new Color(0x2D6A4F);
    private static final Color BUTTON_GREEN = new Color(0x52B788);
    private static final Color CONTENT_BG = new Color(0xF4F6F4);
    private static final Color TABLE_HEADER = new Color(0x1B4332);
    
    // Komponen Filter
    private JTextField txtFilterIdObat, txtFilterNamaObat;
    private JButton btnFilter, btnTambah, btnCetak, btnRefresh;
    
    // Tabel
    private JTable tableObat;
    private JLabel lblTotalObat;
    
    // Dialog Input/Edit
    private JDialog inputDialog;
    private JTextField txtIdObat, txtNamaObat, txtHarga;
    
    public form_obat() {
        koneksi.koneksi k = new koneksi.koneksi();
        conn = k.Connect();
        
        if (conn == null) {
            JOptionPane.showMessageDialog(this, 
                "Gagal koneksi ke database!\nPastikan MySQL sedang berjalan.",
                "Error Koneksi", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        initComponents();
        loadData();
        createInputDialog();
    }
    
    private void initComponents() {
        setLayout(new BorderLayout());
        setBackground(CONTENT_BG);
        setBorder(new EmptyBorder(15, 20, 15, 20));

        // ==================== HEADER ====================
        JLabel headerTitle = new JLabel("Data Obat");
        headerTitle.setFont(new Font("Segoe UI", Font.BOLD, 24));
        headerTitle.setForeground(SIDEBAR_BG);
        headerTitle.setBorder(new EmptyBorder(0, 0, 15, 0));

        // ==================== FILTER PANEL ====================
        JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 8));
        filterPanel.setBackground(CONTENT_BG);
        filterPanel.setBorder(new EmptyBorder(0, 0, 15, 0));

        int fieldHeight = 36;

        // ID Obat
        JPanel idPanel = createFilterField("ID Obat", txtFilterIdObat = new JTextField(18));
        filterPanel.add(idPanel);

        // Nama Obat
        JPanel namaPanel = createFilterField("Nama Obat", txtFilterNamaObat = new JTextField(18));
        filterPanel.add(namaPanel);

        // Tombol Terapkan Filter (dengan posisi agak ke bawah)
        JPanel btnFilterWrapper = new JPanel(new BorderLayout());
        btnFilterWrapper.setBackground(CONTENT_BG);
        btnFilterWrapper.setBorder(new EmptyBorder(22, 0, 0, 0));

        btnFilter = new JButton("Terapkan Filter");
        btnFilter.setBackground(SIDEBAR_BG);
        btnFilter.setForeground(Color.WHITE);
        btnFilter.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnFilter.setFocusPainted(false);
        btnFilter.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnFilter.setPreferredSize(new Dimension(140, fieldHeight));
        
        btnFilter.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { 
                btnFilter.setBackground(SIDEBAR_ACTIVE); 
            }
            public void mouseExited(MouseEvent e) { 
                btnFilter.setBackground(SIDEBAR_BG); 
            }
        });
        
        btnFilterWrapper.add(btnFilter, BorderLayout.NORTH);
        filterPanel.add(btnFilterWrapper);

        // ==================== BUTTON PANEL ====================
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 8));
        buttonPanel.setBackground(CONTENT_BG);
        buttonPanel.setBorder(new EmptyBorder(0, 0, 15, 0));

        btnTambah = new JButton("+ Tambah Data Obat Baru");
        btnTambah.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnTambah.setBackground(SIDEBAR_BG);
        btnTambah.setForeground(Color.WHITE);
        btnTambah.setFocusPainted(false);
        btnTambah.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnTambah.setBorder(new EmptyBorder(10, 18, 10, 18));

        btnCetak = new JButton("Cetak");
        btnCetak.setBackground(new Color(0x6C757D));
        btnCetak.setForeground(Color.WHITE);
        btnCetak.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnCetak.setFocusPainted(false);
        btnCetak.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnCetak.setBorder(new EmptyBorder(10, 25, 10, 25));

        btnRefresh = new JButton("Refresh");
        btnRefresh.setBackground(SIDEBAR_ACTIVE);
        btnRefresh.setForeground(Color.WHITE);
        btnRefresh.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnRefresh.setFocusPainted(false);
        btnRefresh.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnRefresh.setBorder(new EmptyBorder(10, 25, 10, 25));

        buttonPanel.add(btnTambah);
        buttonPanel.add(btnCetak);
        buttonPanel.add(btnRefresh);

        // ==================== TABLE ====================
        String[] columns = {"ID Obat", "Nama Obat", "Harga (Rp)"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override public boolean isCellEditable(int row, int column) { return false; }
        };

        tableObat = new JTable(tableModel);
        tableObat.setRowHeight(50);
        tableObat.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        tableObat.setSelectionBackground(new Color(0xD8F3DC));
        tableObat.setSelectionForeground(SIDEBAR_BG);
        tableObat.setGridColor(new Color(0xE0E0E0));
        tableObat.setShowVerticalLines(true);
        tableObat.setShowHorizontalLines(true);
        tableObat.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);

        // Lebar Kolom
        tableObat.getColumnModel().getColumn(0).setPreferredWidth(120);  // ID Obat
        tableObat.getColumnModel().getColumn(1).setPreferredWidth(300);  // Nama Obat
        tableObat.getColumnModel().getColumn(2).setPreferredWidth(150);  // Harga

        // Format harga ke Rupiah
        tableObat.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                    boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                if (column == 2 && value != null) {
                    try {
                        double harga = Double.parseDouble(value.toString());
                        setText(String.format("Rp %,.0f", harga));
                        setHorizontalAlignment(SwingConstants.RIGHT);
                    } catch (NumberFormatException e) {
                        setText(value.toString());
                    }
                } else {
                    setHorizontalAlignment(SwingConstants.LEFT);
                }
                return c;
            }
        });

        JTableHeader header = tableObat.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 13));
        header.setBackground(TABLE_HEADER);
        header.setForeground(Color.BLACK);
        header.setPreferredSize(new Dimension(0, 25));

        JScrollPane scrollPane = new JScrollPane(tableObat);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(0xE0E0E0)));
        scrollPane.getViewport().setBackground(Color.WHITE);

        // ==================== BOTTOM PANEL ====================
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        bottomPanel.setBackground(CONTENT_BG);
        bottomPanel.setBorder(new EmptyBorder(15, 0, 0, 0));
        lblTotalObat = new JLabel("Total Obat: 0");
        lblTotalObat.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblTotalObat.setForeground(SIDEBAR_BG);
        bottomPanel.add(lblTotalObat);

        // ==================== SUSUNAN UTAMA ====================
        JPanel northPanel = new JPanel(new BorderLayout(0, 8));
        northPanel.setBackground(CONTENT_BG);
        northPanel.add(headerTitle, BorderLayout.NORTH);
        northPanel.add(filterPanel, BorderLayout.CENTER);
        northPanel.add(buttonPanel, BorderLayout.SOUTH);

        add(northPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);

        // Action Listeners
        btnTambah.addActionListener(e -> showInputDialog(false, null));
        btnFilter.addActionListener(e -> applyFilter());
        btnRefresh.addActionListener(e -> { resetFilter(); loadData(); });
        btnCetak.addActionListener(e -> JOptionPane.showMessageDialog(this,
            "Fitur Cetak belum diimplementasikan.", "Info", JOptionPane.INFORMATION_MESSAGE));

        tableObat.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    int row = tableObat.getSelectedRow();
                    if (row >= 0) showInputDialog(true, row);
                }
            }
        });
    }

    private JPanel createFilterField(String labelText, JTextField field) {
        JPanel panel = new JPanel(new BorderLayout(5, 3));
        panel.setBackground(CONTENT_BG);
        
        JLabel lbl = new JLabel(labelText);
        lbl.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lbl.setForeground(SIDEBAR_BG);
        
        field.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        field.setPreferredSize(new Dimension(180, 36));
        field.addActionListener(e -> applyFilter());
        
        panel.add(lbl, BorderLayout.NORTH);
        panel.add(field, BorderLayout.CENTER);
        return panel;
    }

    // ==================== INPUT DIALOG ====================
    private void createInputDialog() {
        inputDialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(this), 
                                 "Input Data Obat", true);
        inputDialog.setSize(500, 320);
        inputDialog.setLocationRelativeTo(this);
        inputDialog.setResizable(true);

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(new EmptyBorder(30, 35, 30, 35));
        formPanel.setBackground(Color.WHITE);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(12, 15, 12, 15);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // ID Obat
        gbc.gridy = 0;
        addFormRow(formPanel, gbc, "ID Obat", txtIdObat = new JTextField(20));
        
        // Nama Obat
        gbc.gridy = 1;
        addFormRow(formPanel, gbc, "Nama Obat", txtNamaObat = new JTextField(20));
        
        // Harga
        gbc.gridy = 2;
        addFormRow(formPanel, gbc, "Harga (Rp)", txtHarga = new JTextField(20));

        // Buttons
        gbc.gridy = 3; gbc.gridx = 0; gbc.gridwidth = 2; gbc.anchor = GridBagConstraints.CENTER;
        gbc.fill = GridBagConstraints.NONE;

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));

        JButton btnSimpan = new JButton("Simpan");
        JButton btnUbah = new JButton("Ubah");
        JButton btnHapus = new JButton("Hapus");
        JButton btnBatal = new JButton("Batal");

        btnSimpan.setBackground(BUTTON_GREEN);
        btnUbah.setBackground(new Color(0xFFC107));
        btnHapus.setBackground(new Color(0xDC3545));
        btnBatal.setBackground(new Color(0x6C757D));

        btnSimpan.setForeground(Color.WHITE);
        btnUbah.setForeground(Color.WHITE);
        btnHapus.setForeground(Color.WHITE);
        btnBatal.setForeground(Color.WHITE);

        btnSimpan.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnUbah.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnHapus.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnBatal.setFont(new Font("Segoe UI", Font.BOLD, 12));

        btnSimpan.setFocusPainted(false);
        btnUbah.setFocusPainted(false);
        btnHapus.setFocusPainted(false);
        btnBatal.setFocusPainted(false);

        btnSimpan.setPreferredSize(new Dimension(100, 38));
        btnUbah.setPreferredSize(new Dimension(100, 38));
        btnHapus.setPreferredSize(new Dimension(100, 38));
        btnBatal.setPreferredSize(new Dimension(100, 38));

        btnPanel.add(btnSimpan);
        btnPanel.add(btnUbah);
        btnPanel.add(btnHapus);
        btnPanel.add(btnBatal);

        formPanel.add(btnPanel, gbc);
        inputDialog.add(formPanel, BorderLayout.CENTER);

        btnSimpan.addActionListener(e -> { simpan(); inputDialog.dispose(); });
        btnUbah.addActionListener(e -> { ubah(); inputDialog.dispose(); });
        btnHapus.addActionListener(e -> {
            if (JOptionPane.showConfirmDialog(inputDialog, "Yakin hapus data ini?", 
                "Konfirmasi", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
                hapus(); inputDialog.dispose();
            }
        });
        btnBatal.addActionListener(e -> inputDialog.dispose());
    }

    private void addFormRow(JPanel panel, GridBagConstraints gbc, String labelText, JTextField field) {
        gbc.gridx = 0; gbc.weightx = 0;
        JLabel label = new JLabel(labelText);
        label.setFont(new Font("Segoe UI", Font.BOLD, 13));
        label.setForeground(SIDEBAR_BG);
        panel.add(label, gbc);

        gbc.gridx = 1; gbc.weightx = 1.0;
        field.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        panel.add(field, gbc);
        gbc.gridx = 0;
    }

    private void showInputDialog(boolean isEdit, Integer row) {
        clearDialogForm();
        if (isEdit && row != null) {
            txtIdObat.setText(tableModel.getValueAt(row, 0).toString());
            txtNamaObat.setText(tableModel.getValueAt(row, 1).toString());
            txtHarga.setText(tableModel.getValueAt(row, 2).toString());
            inputDialog.setTitle("Edit Data Obat");
        } else {
            generateIdObat();
            inputDialog.setTitle("Tambah Data Obat");
        }
        inputDialog.setVisible(true);
    }

    private void loadData() {
        loadDataWithFilter("", "");
    }

    private void applyFilter() {
        String idObat = txtFilterIdObat.getText().trim();
        String namaObat = txtFilterNamaObat.getText().trim();
        loadDataWithFilter(idObat, namaObat);
    }

    private void resetFilter() {
        txtFilterIdObat.setText("");
        txtFilterNamaObat.setText("");
        loadData();
    }

    private void loadDataWithFilter(String idObat, String namaObat) {
        tableModel.setRowCount(0);
        if (conn == null) return;

        StringBuilder sql = new StringBuilder("SELECT * FROM obat WHERE 1=1");
        ArrayList<Object> params = new ArrayList<>();

        if (!idObat.isEmpty()) {
            sql.append(" AND id_obat LIKE ?");
            params.add("%" + idObat + "%");
        }
        if (!namaObat.isEmpty()) {
            sql.append(" AND nama_obat LIKE ?");
            params.add("%" + namaObat + "%");
        }

        sql.append(" ORDER BY id_obat");

        try (PreparedStatement pst = conn.prepareStatement(sql.toString())) {
            for (int i = 0; i < params.size(); i++) {
                pst.setObject(i + 1, params.get(i));
            }
            ResultSet rs = pst.executeQuery();
            int count = 0;
            while (rs.next()) {
                tableModel.addRow(new Object[]{
                    rs.getString("id_obat"),
                    rs.getString("nama_obat"),
                    rs.getDouble("harga")
                });
                count++;
            }
            lblTotalObat.setText("Total Obat: " + count);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error load data: " + e.getMessage());
        }
    }

    private void generateIdObat() {
        try {
            String sql = "SELECT id_obat FROM obat ORDER BY id_obat DESC LIMIT 1";
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            int newNumber = 1;
            if (rs.next()) {
                String last = rs.getString("id_obat");
                if (last != null && last.length() > 1) {
                    String angka = last.replaceAll("[^0-9]", "");
                    if (!angka.isEmpty()) {
                        newNumber = Integer.parseInt(angka) + 1;
                    }
                }
            }
            txtIdObat.setText(String.format("OB%03d", newNumber));
        } catch (Exception e) {
            txtIdObat.setText("OB001");
        }
    }

    private void simpan() {
        String id = txtIdObat.getText().trim();
        String nama = txtNamaObat.getText().trim();
        String hargaStr = txtHarga.getText().trim();

        if (id.isEmpty() || nama.isEmpty() || hargaStr.isEmpty()) {
            JOptionPane.showMessageDialog(inputDialog, "Semua field harus diisi!");
            return;
        }

        double harga;
        try {
            harga = Double.parseDouble(hargaStr);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(inputDialog, "Harga harus berupa angka!");
            return;
        }

        try {
            String cekSql = "SELECT COUNT(*) FROM obat WHERE id_obat = ?";
            PreparedStatement cekPst = conn.prepareStatement(cekSql);
            cekPst.setString(1, id);
            ResultSet rs = cekPst.executeQuery();
            rs.next();
            if (rs.getInt(1) > 0) {
                JOptionPane.showMessageDialog(inputDialog, "ID Obat sudah ada!");
                rs.close();
                cekPst.close();
                return;
            }
            rs.close();
            cekPst.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(inputDialog, "Error: " + e.getMessage());
            return;
        }

        try {
            String sql = "INSERT INTO obat (id_obat, nama_obat, harga) VALUES (?, ?, ?)";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, id);
            pst.setString(2, nama);
            pst.setDouble(3, harga);
            pst.executeUpdate();
            pst.close();
            JOptionPane.showMessageDialog(inputDialog, "Data berhasil disimpan!");
            loadData();
            clearDialogForm();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(inputDialog, "Error: " + e.getMessage());
        }
    }

    private void ubah() {
        String id = txtIdObat.getText().trim();
        if (id.isEmpty()) return;

        try {
            String sql = "UPDATE obat SET nama_obat=?, harga=? WHERE id_obat=?";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, txtNamaObat.getText().trim());
            pst.setDouble(2, Double.parseDouble(txtHarga.getText().trim()));
            pst.setString(3, id);
            pst.executeUpdate();
            pst.close();
            JOptionPane.showMessageDialog(inputDialog, "Data berhasil diubah!");
            loadData();
            clearDialogForm();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(inputDialog, "Error: " + e.getMessage());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(inputDialog, "Harga harus berupa angka!");
        }
    }

    private void hapus() {
        String id = txtIdObat.getText().trim();
        if (id.isEmpty()) return;

        try {
            String sql = "DELETE FROM obat WHERE id_obat=?";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, id);
            pst.executeUpdate();
            pst.close();
            JOptionPane.showMessageDialog(inputDialog, "Data berhasil dihapus!");
            loadData();
            clearDialogForm();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(inputDialog, "Error: " + e.getMessage());
        }
    }

    private void clearDialogForm() {
        txtIdObat.setText("");
        txtNamaObat.setText("");
        txtHarga.setText("");
    }
}