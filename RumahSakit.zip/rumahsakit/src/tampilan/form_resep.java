/*
 * Form Resep Obat - Pengelolaan resep dari hasil pemeriksaan
 * Dilengkapi constructor dengan parameter id_periksa
 */
package tampilan;

import javax.swing.*;
import javax.swing.table.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.ArrayList;

public class form_resep extends JPanel {
    private Connection conn;
    private DefaultTableModel tableModel;
    
    private static final Color SIDEBAR_BG = new Color(0x1B4332);
    private static final Color SIDEBAR_ACTIVE = new Color(0x2D6A4F);
    private static final Color BUTTON_GREEN = new Color(0x52B788);
    private static final Color CONTENT_BG = new Color(0xF4F6F4);
    private static final Color TABLE_HEADER = new Color(0x1B4332);
    
    private JTextField txtFilterPasien, txtFilterObat;
    private JButton btnFilter, btnTambah, btnCetak, btnRefresh;
    private JTable tableResep;
    private JLabel lblTotalResep, lblGrandTotal;
    
    private JDialog inputDialog;
    private JTextField txtIdResep, txtJumlah;
    private JComboBox<String> cmbIdPeriksa, cmbIdObat;
    private JTextArea txtDetailResep;
    private JLabel lblTotalResepDialog;
    
    private String presetIdPeriksa; // Untuk menyimpan id_periksa dari constructor
    
    // Constructor default (tanpa parameter)
    public form_resep() {
        koneksi.koneksi k = new koneksi.koneksi();
        conn = k.Connect();
        
        if (conn == null) {
            JOptionPane.showMessageDialog(this, "Gagal koneksi ke database!");
            return;
        }
        
        initComponents();
        loadData();
        loadComboData();
        createInputDialog();
    }
    
    // Constructor dengan parameter id_periksa (dipanggil dari form_periksa)
    public form_resep(String idPeriksa) {
        this.presetIdPeriksa = idPeriksa;
        
        koneksi.koneksi k = new koneksi.koneksi();
        conn = k.Connect();
        
        if (conn == null) {
            JOptionPane.showMessageDialog(this, "Gagal koneksi ke database!");
            return;
        }
        
        initComponents();
        loadData();
        loadComboData();
        createInputDialog();
        
        // Set default id_periksa jika ada
        if (presetIdPeriksa != null && !presetIdPeriksa.isEmpty()) {
            setDefaultIdPeriksa(presetIdPeriksa);
        }
    }
    
    private void initComponents() {
        setLayout(new BorderLayout());
        setBackground(CONTENT_BG);
        setBorder(new EmptyBorder(15, 20, 15, 20));

        JLabel headerTitle = new JLabel("Resep Obat");
        headerTitle.setFont(new Font("Segoe UI", Font.BOLD, 24));
        headerTitle.setForeground(SIDEBAR_BG);
        headerTitle.setBorder(new EmptyBorder(0, 0, 15, 0));

        // Filter Panel
        JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 8));
        filterPanel.setBackground(CONTENT_BG);
        filterPanel.setBorder(new EmptyBorder(0, 0, 15, 0));

        int fieldHeight = 36;

        // Filter Nama Pasien
        JPanel pasienPanel = new JPanel(new BorderLayout(5, 3));
        pasienPanel.setBackground(CONTENT_BG);
        JLabel lblFilterPasien = new JLabel("Nama Pasien");
        lblFilterPasien.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblFilterPasien.setForeground(SIDEBAR_BG);
        txtFilterPasien = new JTextField(18);
        txtFilterPasien.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        txtFilterPasien.setPreferredSize(new Dimension(180, fieldHeight));
        txtFilterPasien.addActionListener(e -> applyFilter());
        pasienPanel.add(lblFilterPasien, BorderLayout.NORTH);
        pasienPanel.add(txtFilterPasien, BorderLayout.CENTER);
        filterPanel.add(pasienPanel);

        // Filter Nama Obat
        JPanel obatPanel = new JPanel(new BorderLayout(5, 3));
        obatPanel.setBackground(CONTENT_BG);
        JLabel lblFilterObat = new JLabel("Nama Obat");
        lblFilterObat.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblFilterObat.setForeground(SIDEBAR_BG);
        txtFilterObat = new JTextField(18);
        txtFilterObat.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        txtFilterObat.setPreferredSize(new Dimension(180, fieldHeight));
        txtFilterObat.addActionListener(e -> applyFilter());
        obatPanel.add(lblFilterObat, BorderLayout.NORTH);
        obatPanel.add(txtFilterObat, BorderLayout.CENTER);
        filterPanel.add(obatPanel);

        // Tombol Filter
        JPanel btnFilterWrapper = new JPanel(new BorderLayout());
        btnFilterWrapper.setBackground(CONTENT_BG);
        btnFilterWrapper.setBorder(new EmptyBorder(22, 0, 0, 0));

        btnFilter = new JButton("Terapkan Filter");
        btnFilter.setBackground(SIDEBAR_BG);
        btnFilter.setForeground(Color.WHITE);
        btnFilter.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnFilter.setFocusPainted(false);
        btnFilter.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnFilter.setPreferredSize(new Dimension(140, fieldHeight));
        btnFilter.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { btnFilter.setBackground(SIDEBAR_ACTIVE); }
            public void mouseExited(MouseEvent e) { btnFilter.setBackground(SIDEBAR_BG); }
        });
        btnFilterWrapper.add(btnFilter, BorderLayout.NORTH);
        filterPanel.add(btnFilterWrapper);

        // Button Panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 8));
        buttonPanel.setBackground(CONTENT_BG);
        buttonPanel.setBorder(new EmptyBorder(0, 0, 15, 0));

        btnTambah = new JButton("+ Tambah Resep Baru");
        btnTambah.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnTambah.setBackground(SIDEBAR_BG);
        btnTambah.setForeground(Color.WHITE);
        btnTambah.setFocusPainted(false);
        btnTambah.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnTambah.setBorder(new EmptyBorder(10, 18, 10, 18));

        btnCetak = new JButton("🖨️ Cetak Resep");
        btnCetak.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnCetak.setBackground(new Color(0x6C757D));
        btnCetak.setForeground(Color.WHITE);
        btnCetak.setFocusPainted(false);
        btnCetak.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnCetak.setBorder(new EmptyBorder(10, 25, 10, 25));

        btnRefresh = new JButton("⟳ Refresh");
        btnRefresh.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnRefresh.setBackground(SIDEBAR_ACTIVE);
        btnRefresh.setForeground(Color.WHITE);
        btnRefresh.setFocusPainted(false);
        btnRefresh.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnRefresh.setBorder(new EmptyBorder(10, 25, 10, 25));

        buttonPanel.add(btnTambah);
        buttonPanel.add(btnCetak);
        buttonPanel.add(btnRefresh);

        // Table
        String[] columns = {"ID Resep", "ID Periksa", "Pasien", "Obat", "Jumlah", "Subtotal", "Status Bayar"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override public boolean isCellEditable(int row, int column) { return false; }
        };

        tableResep = new JTable(tableModel);
        tableResep.setRowHeight(50);
        tableResep.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        tableResep.setSelectionBackground(new Color(0xD8F3DC));
        tableResep.setSelectionForeground(SIDEBAR_BG);
        tableResep.setGridColor(new Color(0xE0E0E0));
        tableResep.setShowVerticalLines(true);
        tableResep.setShowHorizontalLines(true);
        tableResep.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);

        tableResep.getColumnModel().getColumn(0).setPreferredWidth(100);
        tableResep.getColumnModel().getColumn(1).setPreferredWidth(100);
        tableResep.getColumnModel().getColumn(2).setPreferredWidth(180);
        tableResep.getColumnModel().getColumn(3).setPreferredWidth(180);
        tableResep.getColumnModel().getColumn(4).setPreferredWidth(80);
        tableResep.getColumnModel().getColumn(5).setPreferredWidth(120);
        tableResep.getColumnModel().getColumn(6).setPreferredWidth(100);

        JTableHeader header = tableResep.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 13));
        header.setBackground(TABLE_HEADER);
        header.setForeground(Color.BLACK);
        header.setPreferredSize(new Dimension(0, 35));

        JScrollPane scrollPane = new JScrollPane(tableResep);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(0xE0E0E0)));
        scrollPane.getViewport().setBackground(Color.WHITE);

        // Bottom Panel
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        bottomPanel.setBackground(CONTENT_BG);
        bottomPanel.setBorder(new EmptyBorder(15, 0, 0, 0));
        lblTotalResep = new JLabel("Total Resep: 0");
        lblTotalResep.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblTotalResep.setForeground(SIDEBAR_BG);
        bottomPanel.add(lblTotalResep);
        
        lblGrandTotal = new JLabel("   |   Grand Total: Rp 0");
        lblGrandTotal.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblGrandTotal.setForeground(new Color(0xDC3545));
        bottomPanel.add(lblGrandTotal);

        // Layout Utama
        JPanel northPanel = new JPanel(new BorderLayout(0, 8));
        northPanel.setBackground(CONTENT_BG);
        northPanel.add(headerTitle, BorderLayout.NORTH);
        northPanel.add(filterPanel, BorderLayout.CENTER);
        northPanel.add(buttonPanel, BorderLayout.SOUTH);

        add(northPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);

        // Action Listeners
        btnTambah.addActionListener(e -> showInputDialog(false, null));
        btnFilter.addActionListener(e -> applyFilter());
        btnRefresh.addActionListener(e -> { resetFilter(); loadData(); });
        btnCetak.addActionListener(e -> cetakResep());

        tableResep.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    int row = tableResep.getSelectedRow();
                    if (row >= 0) showInputDialog(true, row);
                }
            }
        });
    }
    
    // Method untuk menset default id_periksa (dipanggil dari constructor)
    private void setDefaultIdPeriksa(String idPeriksa) {
        SwingUtilities.invokeLater(() -> {
            if (cmbIdPeriksa != null) {
                for (int i = 0; i < cmbIdPeriksa.getItemCount(); i++) {
                    String item = cmbIdPeriksa.getItemAt(i);
                    if (item != null && item.startsWith(idPeriksa)) {
                        cmbIdPeriksa.setSelectedIndex(i);
                        break;
                    }
                }
            }
            // Load resep yang sudah ada untuk pemeriksaan ini
            loadExistingResep(idPeriksa);
        });
    }
    
    // Method untuk load resep yang sudah ada untuk pemeriksaan tertentu
    private void loadExistingResep(String idPeriksa) {
        try {
            String sql = 
                "SELECT o.nama_obat, r.jumlah, r.subtotal " +
                "FROM resep r " +
                "JOIN obat o ON r.id_obat = o.id_obat " +
                "WHERE r.id_periksa = ?";
            
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, idPeriksa);
            ResultSet rs = pst.executeQuery();
            
            // Clear text area
            txtDetailResep.setText("");
            double total = 0;
            int no = 1;
            
            while (rs.next()) {
                String nama = rs.getString("nama_obat");
                int jumlah = rs.getInt("jumlah");
                double subtotal = rs.getDouble("subtotal");
                
                // Format tampilan yang rapi
                String line = String.format("%2d. %-25s x %3d = Rp %,12.0f\n", no, nama, jumlah, subtotal);
                txtDetailResep.append(line);
                total += subtotal;
                no++;
            }
            
            if (no == 1) {
                txtDetailResep.setText("Belum ada resep untuk pemeriksaan ini.\nSilakan tambah obat di atas.");
            }
            
            lblTotalResepDialog.setText(String.format("Rp %,.0f", total));
            
            rs.close();
            pst.close();
        } catch (SQLException e) {
            txtDetailResep.setText("Error loading resep: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    private void loadComboData() {
        try {
            Statement st = conn.createStatement();
            
            // Load pemeriksaan yang sudah ada
            cmbIdPeriksa = new JComboBox<>();
            ResultSet rs = st.executeQuery(
                "SELECT p.id_periksa, d.nama_pasien, p.tgl_periksa " +
                "FROM periksa p " +
                "JOIN daftar_berobat d ON p.id_daftar = d.id_daftar " +
                "ORDER BY p.tgl_periksa DESC"
            );
            while (rs.next()) {
                cmbIdPeriksa.addItem(rs.getString("id_periksa") + " - " + rs.getString("nama_pasien") + " (" + rs.getString("tgl_periksa") + ")");
            }
            
            if (cmbIdPeriksa.getItemCount() == 0) {
                cmbIdPeriksa.addItem("--- Tidak ada data pemeriksaan ---");
            }
            rs.close();

            // Load obat
            cmbIdObat = new JComboBox<>();
            rs = st.executeQuery("SELECT id_obat, nama_obat, harga FROM obat ORDER BY nama_obat");
            while (rs.next()) {
                cmbIdObat.addItem(rs.getString("id_obat") + " - " + rs.getString("nama_obat") + " (Rp " + String.format("%,.0f", rs.getDouble("harga")) + ")");
            }
            
            if (cmbIdObat.getItemCount() == 0) {
                cmbIdObat.addItem("--- Tidak ada data obat ---");
            }
            rs.close();
            st.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading combo data: " + e.getMessage());
        }
    }
    
    private void createInputDialog() {
        inputDialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(this), "Input Resep Obat", true);
        inputDialog.setSize(650, 650);
        inputDialog.setLocationRelativeTo(this);
        inputDialog.setResizable(true);

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(new EmptyBorder(25, 30, 25, 30));
        formPanel.setBackground(Color.WHITE);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 15, 10, 15);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // ID Resep
        gbc.gridy = 0;
        gbc.gridx = 0; gbc.weightx = 0;
        JLabel lblId = new JLabel("ID Resep");
        lblId.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblId.setForeground(SIDEBAR_BG);
        formPanel.add(lblId, gbc);
        gbc.gridx = 1; gbc.weightx = 1.0;
        txtIdResep = new JTextField(20);
        txtIdResep.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        txtIdResep.setEditable(false);
        txtIdResep.setBackground(new Color(0xF5F5F5));
        formPanel.add(txtIdResep, gbc);

        // Pilih Pemeriksaan
        gbc.gridy = 1;
        gbc.gridx = 0; gbc.weightx = 0;
        JLabel lblPeriksa = new JLabel("Pilih Pemeriksaan");
        lblPeriksa.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblPeriksa.setForeground(SIDEBAR_BG);
        formPanel.add(lblPeriksa, gbc);
        gbc.gridx = 1; gbc.weightx = 1.0;
        formPanel.add(cmbIdPeriksa, gbc);

        // Pilih Obat
        gbc.gridy = 2;
        gbc.gridx = 0; gbc.weightx = 0;
        JLabel lblObat = new JLabel("Pilih Obat");
        lblObat.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblObat.setForeground(SIDEBAR_BG);
        formPanel.add(lblObat, gbc);
        gbc.gridx = 1; gbc.weightx = 1.0;
        formPanel.add(cmbIdObat, gbc);

        // Jumlah
        gbc.gridy = 3;
        gbc.gridx = 0; gbc.weightx = 0;
        JLabel lblJumlah = new JLabel("Jumlah");
        lblJumlah.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblJumlah.setForeground(SIDEBAR_BG);
        formPanel.add(lblJumlah, gbc);
        gbc.gridx = 1; gbc.weightx = 1.0;
        txtJumlah = new JTextField(20);
        txtJumlah.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        formPanel.add(txtJumlah, gbc);

        // Tombol Hitung & Tambah
        JPanel btnHitungPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 5, 0));
        btnHitungPanel.setBackground(Color.WHITE);
        JButton btnHitung = new JButton("Hitung & Tambahkan");
        btnHitung.setBackground(SIDEBAR_ACTIVE);
        btnHitung.setForeground(Color.WHITE);
        btnHitung.setFont(new Font("Segoe UI", Font.BOLD, 11));
        btnHitung.setFocusPainted(false);
        btnHitung.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnHitung.addActionListener(e -> hitungDanTambah());
        btnHitungPanel.add(btnHitung);
        
        gbc.gridy = 4;
        gbc.gridx = 1;
        formPanel.add(btnHitungPanel, gbc);

        // Detail Resep (List obat yang sudah ditambahkan)
        gbc.gridy = 5;
        gbc.gridx = 0; gbc.weightx = 0;
        JLabel lblDetail = new JLabel("Daftar Resep");
        lblDetail.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblDetail.setForeground(SIDEBAR_BG);
        formPanel.add(lblDetail, gbc);
        gbc.gridx = 1; gbc.weightx = 1.0;
        txtDetailResep = new JTextArea(10, 30);
        txtDetailResep.setFont(new Font("Monospaced", Font.PLAIN, 12));
        txtDetailResep.setEditable(false);
        txtDetailResep.setBackground(new Color(0xF5F5F5));
        JScrollPane scrollDetail = new JScrollPane(txtDetailResep);
        scrollDetail.setPreferredSize(new Dimension(400, 180));
        formPanel.add(scrollDetail, gbc);

        // Total Resep
        gbc.gridy = 6;
        gbc.gridx = 0; gbc.weightx = 0;
        JLabel lblTotal = new JLabel("Total Resep");
        lblTotal.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblTotal.setForeground(SIDEBAR_BG);
        formPanel.add(lblTotal, gbc);
        gbc.gridx = 1; gbc.weightx = 1.0;
        lblTotalResepDialog = new JLabel("Rp 0");
        lblTotalResepDialog.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblTotalResepDialog.setForeground(new Color(0xDC3545));
        formPanel.add(lblTotalResepDialog, gbc);

        // Buttons
        gbc.gridy = 7; gbc.gridx = 0; gbc.gridwidth = 2; gbc.anchor = GridBagConstraints.CENTER;
        gbc.fill = GridBagConstraints.NONE;

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        JButton btnSimpan = new JButton("Selesai & Tutup");
        JButton btnUbah = new JButton("Ubah");
        JButton btnHapus = new JButton("Hapus");
        JButton btnBatal = new JButton("Batal");

        btnSimpan.setBackground(BUTTON_GREEN);
        btnUbah.setBackground(new Color(0xFFC107));
        btnHapus.setBackground(new Color(0xDC3545));
        btnBatal.setBackground(new Color(0x6C757D));
        btnSimpan.setForeground(Color.WHITE);
        btnUbah.setForeground(Color.WHITE);
        btnHapus.setForeground(Color.WHITE);
        btnBatal.setForeground(Color.WHITE);
        btnSimpan.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnUbah.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnHapus.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnBatal.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnSimpan.setFocusPainted(false);
        btnUbah.setFocusPainted(false);
        btnHapus.setFocusPainted(false);
        btnBatal.setFocusPainted(false);
        btnSimpan.setPreferredSize(new Dimension(120, 38));
        btnUbah.setPreferredSize(new Dimension(100, 38));
        btnHapus.setPreferredSize(new Dimension(100, 38));
        btnBatal.setPreferredSize(new Dimension(100, 38));

        btnPanel.add(btnSimpan);
        btnPanel.add(btnUbah);
        btnPanel.add(btnHapus);
        btnPanel.add(btnBatal);
        formPanel.add(btnPanel, gbc);
        inputDialog.add(formPanel, BorderLayout.CENTER);

        btnSimpan.addActionListener(e -> { 
            JOptionPane.showMessageDialog(inputDialog, "Resep telah tersimpan!\nSilakan lanjut ke pembayaran.");
            loadData();
            inputDialog.dispose(); 
        });
        btnUbah.addActionListener(e -> { ubah(); inputDialog.dispose(); });
        btnHapus.addActionListener(e -> {
            if (JOptionPane.showConfirmDialog(inputDialog, "Yakin hapus resep ini?", "Konfirmasi", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
                hapus(); inputDialog.dispose();
            }
        });
        btnBatal.addActionListener(e -> inputDialog.dispose());
    }
    
    // Method untuk hitung dan langsung simpan ke database
    private void hitungDanTambah() {
        // Cek apakah combo box kosong atau berisi pesan error
        if (cmbIdPeriksa.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(inputDialog, "Pilih pemeriksaan terlebih dahulu!");
            return;
        }
        
        String selectedPeriksa = cmbIdPeriksa.getSelectedItem().toString();
        if (selectedPeriksa.startsWith("---")) {
            JOptionPane.showMessageDialog(inputDialog, "Pilih pemeriksaan yang valid!");
            return;
        }
        
        if (cmbIdObat.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(inputDialog, "Pilih obat terlebih dahulu!");
            return;
        }
        
        String selectedObat = cmbIdObat.getSelectedItem().toString();
        if (selectedObat.startsWith("---")) {
            JOptionPane.showMessageDialog(inputDialog, "Pilih obat yang valid!");
            return;
        }
        
        String idPeriksa = selectedPeriksa.split(" - ")[0];
        String idObat = selectedObat.split(" - ")[0];
        String jumlahStr = txtJumlah.getText().trim();
        
        if (jumlahStr.isEmpty()) {
            JOptionPane.showMessageDialog(inputDialog, "Masukkan jumlah terlebih dahulu!");
            return;
        }
        
        int jumlah;
        try {
            jumlah = Integer.parseInt(jumlahStr);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(inputDialog, "Jumlah harus berupa angka!");
            return;
        }
        
        if (jumlah <= 0) {
            JOptionPane.showMessageDialog(inputDialog, "Jumlah harus lebih dari 0!");
            return;
        }
        
        try {
            // Cek apakah obat sudah ada di resep untuk pemeriksaan ini
            String cekSql = "SELECT COUNT(*) FROM resep WHERE id_periksa = ? AND id_obat = ?";
            PreparedStatement cekPst = conn.prepareStatement(cekSql);
            cekPst.setString(1, idPeriksa);
            cekPst.setString(2, idObat);
            ResultSet rs = cekPst.executeQuery();
            rs.next();
            
            if (rs.getInt(1) > 0) {
                // Update jumlah yang sudah ada
                String updateSql = "UPDATE resep SET jumlah = jumlah + ? WHERE id_periksa = ? AND id_obat = ?";
                PreparedStatement updatePst = conn.prepareStatement(updateSql);
                updatePst.setInt(1, jumlah);
                updatePst.setString(2, idPeriksa);
                updatePst.setString(3, idObat);
                updatePst.executeUpdate();
                updatePst.close();
                JOptionPane.showMessageDialog(inputDialog, "Jumlah obat diperbarui!");
            } else {
                // Insert resep baru
                String sql = "INSERT INTO resep (id_resep, id_periksa, id_obat, jumlah) VALUES (?, ?, ?, ?)";
                PreparedStatement pst = conn.prepareStatement(sql);
                String idResep = generateIdResepForInsert();
                pst.setString(1, idResep);
                pst.setString(2, idPeriksa);
                pst.setString(3, idObat);
                pst.setInt(4, jumlah);
                pst.executeUpdate();
                pst.close();
                JOptionPane.showMessageDialog(inputDialog, "Obat berhasil ditambahkan ke resep!");
            }
            
            rs.close();
            cekPst.close();
            
            // Refresh detail resep
            loadExistingResep(idPeriksa);
            
            // Reset form jumlah
            txtJumlah.setText("");
            
            // Refresh tabel utama
            loadData();
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(inputDialog, "Error: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    private String generateIdResepForInsert() {
        try {
            String sql = "SELECT id_resep FROM resep ORDER BY id_resep DESC LIMIT 1";
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            int newNumber = 1;
            if (rs.next()) {
                String last = rs.getString("id_resep");
                if (last != null && last.length() > 2) {
                    newNumber = Integer.parseInt(last.substring(2)) + 1;
                }
            }
            rs.close();
            st.close();
            return String.format("RP%03d", newNumber);
        } catch (Exception e) {
            return "RP001";
        }
    }

    private void showInputDialog(boolean isEdit, Integer row) {
        clearDialogForm();
        if (isEdit && row != null) {
            txtIdResep.setText(tableModel.getValueAt(row, 0).toString());
            
            String idPeriksa = tableModel.getValueAt(row, 1).toString();
            for (int i = 0; i < cmbIdPeriksa.getItemCount(); i++) {
                String item = cmbIdPeriksa.getItemAt(i);
                if (item != null && item.startsWith(idPeriksa)) {
                    cmbIdPeriksa.setSelectedIndex(i);
                    break;
                }
            }
            
            // Load detail resep untuk edit
            if (presetIdPeriksa == null) {
                loadExistingResep(idPeriksa);
            }
            
            txtJumlah.setText(tableModel.getValueAt(row, 4).toString());
            inputDialog.setTitle("Edit Resep");
        } else {
            generateIdResep();
            inputDialog.setTitle("Tambah Resep Baru");
        }
        inputDialog.setVisible(true);
    }

    private void loadData() { 
        loadDataWithFilter("", ""); 
    }

    private void applyFilter() {
        String pasien = txtFilterPasien.getText().trim();
        String obat = txtFilterObat.getText().trim();
        loadDataWithFilter(pasien, obat);
    }

    private void resetFilter() {
        txtFilterPasien.setText("");
        txtFilterObat.setText("");
        loadData();
    }

    private void loadDataWithFilter(String namaPasien, String namaObat) {
        tableModel.setRowCount(0);
        if (conn == null) return;

        StringBuilder sql = new StringBuilder(
            "SELECT r.id_resep, r.id_periksa, d.nama_pasien, " +
            "o.nama_obat, r.jumlah, r.subtotal, " +
            "CASE WHEN p.id_pembayaran IS NOT NULL THEN 'LUNAS' ELSE 'BELUM' END as status " +
            "FROM resep r " +
            "JOIN periksa pk ON r.id_periksa = pk.id_periksa " +
            "JOIN daftar_berobat d ON pk.id_daftar = d.id_daftar " +
            "JOIN obat o ON r.id_obat = o.id_obat " +
            "LEFT JOIN pembayaran p ON r.id_resep = p.id_resep " +
            "WHERE 1=1"
        );
        ArrayList<Object> params = new ArrayList<>();

        if (!namaPasien.isEmpty()) { 
            sql.append(" AND d.nama_pasien LIKE ?"); 
            params.add("%" + namaPasien + "%"); 
        }
        if (!namaObat.isEmpty()) { 
            sql.append(" AND o.nama_obat LIKE ?"); 
            params.add("%" + namaObat + "%"); 
        }
        sql.append(" ORDER BY r.id_resep");

        try (PreparedStatement pst = conn.prepareStatement(sql.toString())) {
            for (int i = 0; i < params.size(); i++) {
                pst.setObject(i + 1, params.get(i));
            }
            ResultSet rs = pst.executeQuery();
            int count = 0;
            double grandTotal = 0;
            while (rs.next()) {
                double subtotal = rs.getDouble("subtotal");
                tableModel.addRow(new Object[]{
                    rs.getString("id_resep"),
                    rs.getString("id_periksa"),
                    rs.getString("nama_pasien"),
                    rs.getString("nama_obat"),
                    rs.getString("jumlah"),
                    "Rp " + String.format("%,.0f", subtotal),
                    rs.getString("status")
                });
                count++;
                grandTotal += subtotal;
            }
            lblTotalResep.setText("Total Resep: " + count);
            lblGrandTotal.setText("   |   Grand Total: Rp " + String.format("%,.0f", grandTotal));
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error load data: " + e.getMessage());
        }
    }

    private void generateIdResep() {
        try {
            String sql = "SELECT id_resep FROM resep ORDER BY id_resep DESC LIMIT 1";
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            int newNumber = 1;
            if (rs.next()) {
                String last = rs.getString("id_resep");
                if (last != null && last.length() > 2) {
                    newNumber = Integer.parseInt(last.substring(2)) + 1;
                }
            }
            txtIdResep.setText(String.format("RP%03d", newNumber));
            rs.close();
            st.close();
        } catch (Exception e) {
            txtIdResep.setText("RP001");
        }
    }

    private void simpan() {
        String idResep = txtIdResep.getText().trim();
        if (cmbIdPeriksa.getSelectedItem() == null || cmbIdObat.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(inputDialog, "Pilih pemeriksaan dan obat terlebih dahulu!");
            return;
        }
        
        String selectedPeriksa = cmbIdPeriksa.getSelectedItem().toString();
        if (selectedPeriksa.startsWith("---")) {
            JOptionPane.showMessageDialog(inputDialog, "Pilih pemeriksaan yang valid!");
            return;
        }
        
        String selectedObat = cmbIdObat.getSelectedItem().toString();
        if (selectedObat.startsWith("---")) {
            JOptionPane.showMessageDialog(inputDialog, "Pilih obat yang valid!");
            return;
        }
        
        String idPeriksa = selectedPeriksa.split(" - ")[0];
        String idObat = selectedObat.split(" - ")[0];
        String jumlahStr = txtJumlah.getText().trim();

        if (idResep.isEmpty() || idPeriksa.isEmpty() || idObat.isEmpty() || jumlahStr.isEmpty()) {
            JOptionPane.showMessageDialog(inputDialog, "Semua field harus diisi!");
            return;
        }

        int jumlah;
        try {
            jumlah = Integer.parseInt(jumlahStr);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(inputDialog, "Jumlah harus berupa angka!");
            return;
        }

        try {
            String sql = "INSERT INTO resep (id_resep, id_periksa, id_obat, jumlah) VALUES (?, ?, ?, ?)";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, idResep);
            pst.setString(2, idPeriksa);
            pst.setString(3, idObat);
            pst.setInt(4, jumlah);
            pst.executeUpdate();
            pst.close();
            JOptionPane.showMessageDialog(inputDialog, "Resep berhasil disimpan!");
            loadData();
            clearDialogForm();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(inputDialog, "Error: " + e.getMessage());
        }
    }

    private void ubah() {
        String idResep = txtIdResep.getText().trim();
        if (idResep.isEmpty()) return;
        
        String selectedPeriksa = cmbIdPeriksa.getSelectedItem().toString();
        String idPeriksa = selectedPeriksa.split(" - ")[0];
        String selectedObat = cmbIdObat.getSelectedItem().toString();
        String idObat = selectedObat.split(" - ")[0];
        String jumlahStr = txtJumlah.getText().trim();

        try {
            String sql = "UPDATE resep SET id_periksa=?, id_obat=?, jumlah=? WHERE id_resep=?";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, idPeriksa);
            pst.setString(2, idObat);
            pst.setInt(3, Integer.parseInt(jumlahStr));
            pst.setString(4, idResep);
            pst.executeUpdate();
            pst.close();
            JOptionPane.showMessageDialog(inputDialog, "Resep berhasil diubah!");
            loadData();
            clearDialogForm();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(inputDialog, "Error: " + e.getMessage());
        }
    }

    private void hapus() {
        String idResep = txtIdResep.getText().trim();
        if (idResep.isEmpty()) return;
        
        try {
            String sql = "DELETE FROM resep WHERE id_resep=?";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, idResep);
            pst.executeUpdate();
            pst.close();
            JOptionPane.showMessageDialog(inputDialog, "Resep berhasil dihapus!");
            loadData();
            
            // Refresh detail resep jika ada preset
            if (presetIdPeriksa != null && !presetIdPeriksa.isEmpty()) {
                loadExistingResep(presetIdPeriksa);
            }
            clearDialogForm();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(inputDialog, "Error: " + e.getMessage());
        }
    }

    private void cetakResep() {
        int row = tableResep.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Pilih resep yang akan dicetak!");
            return;
        }
        
        String idResep = tableModel.getValueAt(row, 0).toString();
        String pasien = tableModel.getValueAt(row, 2).toString();
        String obat = tableModel.getValueAt(row, 3).toString();
        String jumlah = tableModel.getValueAt(row, 4).toString();
        String subtotal = tableModel.getValueAt(row, 5).toString();
        
        StringBuilder sb = new StringBuilder();
        sb.append("╔════════════════════════════════════════════╗\n");
        sb.append("║              RESEP OBAT                    ║\n");
        sb.append("║        RUMAH SAKIT SEHAT SENTOSA           ║\n");
        sb.append("╠════════════════════════════════════════════╣\n");
        sb.append("║ No. Resep   : ").append(String.format("%-20s", idResep)).append("║\n");
        sb.append("║ Pasien      : ").append(String.format("%-20s", pasien.length() > 20 ? pasien.substring(0, 20) : pasien)).append("║\n");
        sb.append("╠════════════════════════════════════════════╣\n");
        sb.append("║ Obat        : ").append(String.format("%-20s", obat.length() > 20 ? obat.substring(0, 20) : obat)).append("║\n");
        sb.append("║ Jumlah      : ").append(String.format("%-20s", jumlah)).append("║\n");
        sb.append("║ Subtotal    : ").append(String.format("%-20s", subtotal)).append("║\n");
        sb.append("╠════════════════════════════════════════════╣\n");
        sb.append("║         TERIMA KASIH                        ║\n");
        sb.append("║    Semoga Lekas Sembuh                      ║\n");
        sb.append("╚════════════════════════════════════════════╝\n");
        
        JTextArea textArea = new JTextArea(sb.toString());
        textArea.setEditable(false);
        textArea.setFont(new Font("Monospaced", Font.BOLD, 12));
        textArea.setBackground(Color.BLACK);
        textArea.setForeground(Color.WHITE);
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(480, 350));
        JOptionPane.showMessageDialog(this, scrollPane, "Cetak Resep", JOptionPane.INFORMATION_MESSAGE);
    }

    private void clearDialogForm() {
        if (presetIdPeriksa == null || presetIdPeriksa.isEmpty()) {
            txtIdResep.setText("");
            if (cmbIdPeriksa != null && cmbIdPeriksa.getItemCount() > 0 
                && !cmbIdPeriksa.getItemAt(0).startsWith("---")) {
                cmbIdPeriksa.setSelectedIndex(0);
            }
            txtDetailResep.setText("");
            lblTotalResepDialog.setText("Rp 0");
        }
        if (cmbIdObat != null && cmbIdObat.getItemCount() > 0) {
            cmbIdObat.setSelectedIndex(0);
        }
        txtJumlah.setText("");
    }
}