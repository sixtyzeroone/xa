/*
 * Form Data Pasien - Dengan No Ruangan, Nama Pasien, Alamat, No KTP/NIK
 */
package tampilan;

import javax.swing.*;
import javax.swing.table.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.ArrayList;

public class form_pasien extends JPanel {
    private Connection conn;
    private DefaultTableModel tableModel;
    
    // Warna tema HMS
    private static final Color SIDEBAR_BG = new Color(0x1B4332);
    private static final Color SIDEBAR_ACTIVE = new Color(0x2D6A4F);
    private static final Color BUTTON_GREEN = new Color(0x52B788);
    private static final Color CONTENT_BG = new Color(0xF4F6F4);
    private static final Color TABLE_HEADER = new Color(0x1B4332);
    
    // Komponen Filter
    private JTextField txtFilterNama, txtFilterRuangan;
    private JButton btnFilter, btnTambah, btnCetak, btnRefresh;
    
    // Tabel
    private JTable tablePasien;
    private JLabel lblTotalPasien;
    
    // Dialog Input/Edit
    private JDialog inputDialog;
    private JTextField txtNoRuangan, txtNamaPasien, txtAlamat, txtNoKtp, txtNoTelp;
    private JRadioButton rbLaki, rbPerempuan;
    private ButtonGroup bgJk;
    
    public form_pasien() {
        koneksi.koneksi k = new koneksi.koneksi();
        conn = k.Connect();
        
        if (conn == null) {
            JOptionPane.showMessageDialog(this, 
                "Gagal koneksi ke database!\nPastikan MySQL sedang berjalan.",
                "Error Koneksi", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        initComponents();
        loadData();
        createInputDialog();
    }
    
    private void initComponents() {
        setLayout(new BorderLayout());
        setBackground(CONTENT_BG);
        setBorder(new EmptyBorder(15, 20, 15, 20));

        // Header
        JLabel headerTitle = new JLabel("Data Pasien");
        headerTitle.setFont(new Font("Segoe UI", Font.BOLD, 24));
        headerTitle.setForeground(SIDEBAR_BG);
        headerTitle.setBorder(new EmptyBorder(0, 0, 15, 0));

        // Filter Panel
        JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 8));
        filterPanel.setBackground(CONTENT_BG);
        filterPanel.setBorder(new EmptyBorder(0, 0, 15, 0));

        int fieldHeight = 36;

        // Filter Nama Pasien
        JPanel namaPanel = new JPanel(new BorderLayout(5, 3));
        namaPanel.setBackground(CONTENT_BG);
        JLabel lblFilterNama = new JLabel("Nama Pasien");
        lblFilterNama.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblFilterNama.setForeground(SIDEBAR_BG);
        txtFilterNama = new JTextField(18);
        txtFilterNama.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        txtFilterNama.setPreferredSize(new Dimension(200, fieldHeight));
        txtFilterNama.addActionListener(e -> applyFilter());
        namaPanel.add(lblFilterNama, BorderLayout.NORTH);
        namaPanel.add(txtFilterNama, BorderLayout.CENTER);
        filterPanel.add(namaPanel);

        // Filter No Ruangan
        JPanel ruanganPanel = new JPanel(new BorderLayout(5, 3));
        ruanganPanel.setBackground(CONTENT_BG);
        JLabel lblFilterRuangan = new JLabel("No. Ruangan");
        lblFilterRuangan.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblFilterRuangan.setForeground(SIDEBAR_BG);
        txtFilterRuangan = new JTextField(18);
        txtFilterRuangan.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        txtFilterRuangan.setPreferredSize(new Dimension(150, fieldHeight));
        txtFilterRuangan.addActionListener(e -> applyFilter());
        ruanganPanel.add(lblFilterRuangan, BorderLayout.NORTH);
        ruanganPanel.add(txtFilterRuangan, BorderLayout.CENTER);
        filterPanel.add(ruanganPanel);

        // Tombol Filter
        JPanel btnFilterWrapper = new JPanel(new BorderLayout());
        btnFilterWrapper.setBackground(CONTENT_BG);
        btnFilterWrapper.setBorder(new EmptyBorder(22, 0, 0, 0));

        btnFilter = new JButton("Terapkan Filter");
        btnFilter.setBackground(SIDEBAR_BG);
        btnFilter.setForeground(Color.WHITE);
        btnFilter.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnFilter.setFocusPainted(false);
        btnFilter.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnFilter.setPreferredSize(new Dimension(140, fieldHeight));
        btnFilter.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { btnFilter.setBackground(SIDEBAR_ACTIVE); }
            public void mouseExited(MouseEvent e) { btnFilter.setBackground(SIDEBAR_BG); }
        });
        btnFilterWrapper.add(btnFilter, BorderLayout.NORTH);
        filterPanel.add(btnFilterWrapper);

        // Button Panel (Tambah, Cetak, Refresh)
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 8));
        buttonPanel.setBackground(CONTENT_BG);
        buttonPanel.setBorder(new EmptyBorder(0, 0, 15, 0));

        btnTambah = new JButton("+ Tambah Data Pasien Baru");
        btnTambah.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnTambah.setBackground(SIDEBAR_BG);
        btnTambah.setForeground(Color.WHITE);
        btnTambah.setFocusPainted(false);
        btnTambah.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnTambah.setBorder(new EmptyBorder(10, 18, 10, 18));

        btnCetak = new JButton("🖨️ Cetak");
        btnCetak.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnCetak.setBackground(new Color(0x6C757D));
        btnCetak.setForeground(Color.WHITE);
        btnCetak.setFocusPainted(false);
        btnCetak.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnCetak.setBorder(new EmptyBorder(10, 25, 10, 25));

        btnRefresh = new JButton("⟳ Refresh");
        btnRefresh.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnRefresh.setBackground(SIDEBAR_ACTIVE);
        btnRefresh.setForeground(Color.WHITE);
        btnRefresh.setFocusPainted(false);
        btnRefresh.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnRefresh.setBorder(new EmptyBorder(10, 25, 10, 25));

        buttonPanel.add(btnTambah);
        buttonPanel.add(btnCetak);
        buttonPanel.add(btnRefresh);

        // Table
        String[] columns = {"No. Ruangan", "Nama Pasien", "Alamat", "No. KTP/NIK", "JK", "No. Telp"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override public boolean isCellEditable(int row, int column) { return false; }
        };

        tablePasien = new JTable(tableModel);
        tablePasien.setRowHeight(50);
        tablePasien.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        tablePasien.setSelectionBackground(new Color(0xD8F3DC));
        tablePasien.setSelectionForeground(SIDEBAR_BG);
        tablePasien.setGridColor(new Color(0xE0E0E0));
        tablePasien.setShowVerticalLines(true);
        tablePasien.setShowHorizontalLines(true);
        tablePasien.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);

        // Setting lebar kolom
        tablePasien.getColumnModel().getColumn(0).setPreferredWidth(100);  // No. Ruangan
        tablePasien.getColumnModel().getColumn(1).setPreferredWidth(200);  // Nama Pasien
        tablePasien.getColumnModel().getColumn(2).setPreferredWidth(200);  // Alamat
        tablePasien.getColumnModel().getColumn(3).setPreferredWidth(150);  // No. KTP/NIK
        tablePasien.getColumnModel().getColumn(4).setPreferredWidth(60);   // JK
        tablePasien.getColumnModel().getColumn(5).setPreferredWidth(120);  // No. Telp

        JTableHeader header = tablePasien.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 13));
        header.setBackground(TABLE_HEADER);
        header.setForeground(Color.BLACK);
        header.setPreferredSize(new Dimension(0, 35));

        JScrollPane scrollPane = new JScrollPane(tablePasien);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(0xE0E0E0)));
        scrollPane.getViewport().setBackground(Color.WHITE);

        // Bottom Panel (Total)
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        bottomPanel.setBackground(CONTENT_BG);
        bottomPanel.setBorder(new EmptyBorder(15, 0, 0, 0));
        lblTotalPasien = new JLabel("Total Pasien: 0");
        lblTotalPasien.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblTotalPasien.setForeground(SIDEBAR_BG);
        bottomPanel.add(lblTotalPasien);

        // Layout Utama
        JPanel northPanel = new JPanel(new BorderLayout(0, 8));
        northPanel.setBackground(CONTENT_BG);
        northPanel.add(headerTitle, BorderLayout.NORTH);
        northPanel.add(filterPanel, BorderLayout.CENTER);
        northPanel.add(buttonPanel, BorderLayout.SOUTH);

        add(northPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);

        // Action Listeners
        btnTambah.addActionListener(e -> showInputDialog(false, null));
        btnFilter.addActionListener(e -> applyFilter());
        btnRefresh.addActionListener(e -> { resetFilter(); loadData(); });
        btnCetak.addActionListener(e -> cetakData());

        tablePasien.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    int row = tablePasien.getSelectedRow();
                    if (row >= 0) showInputDialog(true, row);
                }
            }
        });
    }

    private void createInputDialog() {
        inputDialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(this), "Input Data Pasien", true);
        inputDialog.setSize(550, 550);
        inputDialog.setLocationRelativeTo(this);
        inputDialog.setResizable(true);

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(new EmptyBorder(25, 30, 25, 30));
        formPanel.setBackground(Color.WHITE);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 15, 10, 15);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // No. Ruangan
        gbc.gridy = 0;
        gbc.gridx = 0; gbc.weightx = 0;
        JLabel lblRuangan = new JLabel("No. Ruangan");
        lblRuangan.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblRuangan.setForeground(SIDEBAR_BG);
        formPanel.add(lblRuangan, gbc);
        gbc.gridx = 1; gbc.weightx = 1.0;
        txtNoRuangan = new JTextField(20);
        txtNoRuangan.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        formPanel.add(txtNoRuangan, gbc);

        // Nama Pasien
        gbc.gridy = 1;
        gbc.gridx = 0; gbc.weightx = 0;
        JLabel lblNama = new JLabel("Nama Pasien");
        lblNama.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblNama.setForeground(SIDEBAR_BG);
        formPanel.add(lblNama, gbc);
        gbc.gridx = 1; gbc.weightx = 1.0;
        txtNamaPasien = new JTextField(20);
        txtNamaPasien.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        formPanel.add(txtNamaPasien, gbc);

        // Alamat
        gbc.gridy = 2;
        gbc.gridx = 0; gbc.weightx = 0;
        JLabel lblAlamat = new JLabel("Alamat");
        lblAlamat.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblAlamat.setForeground(SIDEBAR_BG);
        formPanel.add(lblAlamat, gbc);
        gbc.gridx = 1; gbc.weightx = 1.0;
        txtAlamat = new JTextField(20);
        txtAlamat.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        formPanel.add(txtAlamat, gbc);

        // No. KTP/NIK
        gbc.gridy = 3;
        gbc.gridx = 0; gbc.weightx = 0;
        JLabel lblKtp = new JLabel("No. KTP/NIK");
        lblKtp.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblKtp.setForeground(SIDEBAR_BG);
        formPanel.add(lblKtp, gbc);
        gbc.gridx = 1; gbc.weightx = 1.0;
        txtNoKtp = new JTextField(20);
        txtNoKtp.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        formPanel.add(txtNoKtp, gbc);

        // Jenis Kelamin
        gbc.gridy = 4;
        gbc.gridx = 0; gbc.weightx = 0;
        JLabel lblJk = new JLabel("Jenis Kelamin");
        lblJk.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblJk.setForeground(SIDEBAR_BG);
        formPanel.add(lblJk, gbc);
        gbc.gridx = 1; gbc.weightx = 1.0;
        JPanel jkPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 25, 0));
        jkPanel.setBackground(Color.WHITE);
        rbLaki = new JRadioButton("Laki-laki");
        rbPerempuan = new JRadioButton("Perempuan");
        rbLaki.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        rbPerempuan.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        bgJk = new ButtonGroup();
        bgJk.add(rbLaki); bgJk.add(rbPerempuan);
        jkPanel.add(rbLaki); jkPanel.add(rbPerempuan);
        formPanel.add(jkPanel, gbc);

        // No. Telp
        gbc.gridy = 5;
        gbc.gridx = 0; gbc.weightx = 0;
        JLabel lblTelp = new JLabel("No. Telp");
        lblTelp.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblTelp.setForeground(SIDEBAR_BG);
        formPanel.add(lblTelp, gbc);
        gbc.gridx = 1; gbc.weightx = 1.0;
        txtNoTelp = new JTextField(20);
        txtNoTelp.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        formPanel.add(txtNoTelp, gbc);

        // Buttons
        gbc.gridy = 6; gbc.gridx = 0; gbc.gridwidth = 2; gbc.anchor = GridBagConstraints.CENTER;
        gbc.fill = GridBagConstraints.NONE;

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        JButton btnSimpan = new JButton("Simpan");
        JButton btnUbah = new JButton("Ubah");
        JButton btnHapus = new JButton("Hapus");
        JButton btnBatal = new JButton("Batal");

        btnSimpan.setBackground(BUTTON_GREEN);
        btnUbah.setBackground(new Color(0xFFC107));
        btnHapus.setBackground(new Color(0xDC3545));
        btnBatal.setBackground(new Color(0x6C757D));
        btnSimpan.setForeground(Color.WHITE);
        btnUbah.setForeground(Color.WHITE);
        btnHapus.setForeground(Color.WHITE);
        btnBatal.setForeground(Color.WHITE);
        btnSimpan.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnUbah.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnHapus.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnBatal.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnSimpan.setFocusPainted(false);
        btnUbah.setFocusPainted(false);
        btnHapus.setFocusPainted(false);
        btnBatal.setFocusPainted(false);
        btnSimpan.setPreferredSize(new Dimension(100, 38));
        btnUbah.setPreferredSize(new Dimension(100, 38));
        btnHapus.setPreferredSize(new Dimension(100, 38));
        btnBatal.setPreferredSize(new Dimension(100, 38));

        btnPanel.add(btnSimpan);
        btnPanel.add(btnUbah);
        btnPanel.add(btnHapus);
        btnPanel.add(btnBatal);
        formPanel.add(btnPanel, gbc);
        inputDialog.add(formPanel, BorderLayout.CENTER);

        btnSimpan.addActionListener(e -> { simpan(); inputDialog.dispose(); });
        btnUbah.addActionListener(e -> { ubah(); inputDialog.dispose(); });
        btnHapus.addActionListener(e -> {
            if (JOptionPane.showConfirmDialog(inputDialog, "Yakin hapus data ini?", "Konfirmasi", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
                hapus(); inputDialog.dispose();
            }
        });
        btnBatal.addActionListener(e -> inputDialog.dispose());
    }

    private void showInputDialog(boolean isEdit, Integer row) {
        clearDialogForm();
        if (isEdit && row != null) {
            txtNoRuangan.setText(tableModel.getValueAt(row, 0).toString());
            txtNamaPasien.setText(tableModel.getValueAt(row, 1).toString());
            txtAlamat.setText(tableModel.getValueAt(row, 2).toString());
            txtNoKtp.setText(tableModel.getValueAt(row, 3).toString());
            String jk = tableModel.getValueAt(row, 4).toString();
            if (jk.equals("L")) rbLaki.setSelected(true);
            else rbPerempuan.setSelected(true);
            txtNoTelp.setText(tableModel.getValueAt(row, 5).toString());
            inputDialog.setTitle("Edit Data Pasien");
        } else {
            inputDialog.setTitle("Tambah Data Pasien");
        }
        inputDialog.setVisible(true);
    }

    private void loadData() { loadDataWithFilter("", ""); }

    private void applyFilter() {
        String nama = txtFilterNama.getText().trim();
        String ruangan = txtFilterRuangan.getText().trim();
        loadDataWithFilter(nama, ruangan);
    }

    private void resetFilter() {
        txtFilterNama.setText("");
        txtFilterRuangan.setText("");
        loadData();
    }

    private void loadDataWithFilter(String nama, String ruangan) {
        tableModel.setRowCount(0);
        if (conn == null) return;

        StringBuilder sql = new StringBuilder("SELECT * FROM pasien WHERE 1=1");
        ArrayList<Object> params = new ArrayList<>();

        if (!nama.isEmpty()) { 
            sql.append(" AND nama LIKE ?"); 
            params.add("%" + nama + "%"); 
        }
        if (!ruangan.isEmpty()) { 
            sql.append(" AND no_ruangan LIKE ?"); 
            params.add("%" + ruangan + "%"); 
        }
        
        sql.append(" ORDER BY no_ruangan");

        try (PreparedStatement pst = conn.prepareStatement(sql.toString())) {
            for (int i = 0; i < params.size(); i++) pst.setObject(i + 1, params.get(i));
            ResultSet rs = pst.executeQuery();
            int count = 0;
            while (rs.next()) {
                tableModel.addRow(new Object[]{
                    rs.getString("no_ruangan"),
                    rs.getString("nama"),
                    rs.getString("alamat"),
                    rs.getString("no_ktp"),
                    rs.getString("jk"),
                    rs.getString("no_telp") != null ? rs.getString("no_telp") : ""
                });
                count++;
            }
            lblTotalPasien.setText("Total Pasien: " + count);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error load data: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void simpan() {
        String noRuangan = txtNoRuangan.getText().trim();
        String nama = txtNamaPasien.getText().trim();
        String alamat = txtAlamat.getText().trim();
        String noKtp = txtNoKtp.getText().trim();
        String jk = rbLaki.isSelected() ? "L" : (rbPerempuan.isSelected() ? "P" : "");
        String noTelp = txtNoTelp.getText().trim();

        if (noRuangan.isEmpty() || nama.isEmpty() || alamat.isEmpty() || noKtp.isEmpty() || jk.isEmpty()) {
            JOptionPane.showMessageDialog(inputDialog, "Semua field wajib diisi (No Ruangan, Nama, Alamat, No KTP, Jenis Kelamin)!");
            return;
        }

        try {
            String cekSql = "SELECT COUNT(*) FROM pasien WHERE no_ruangan = ?";
            PreparedStatement cekPst = conn.prepareStatement(cekSql);
            cekPst.setString(1, noRuangan);
            ResultSet rs = cekPst.executeQuery();
            rs.next();
            if (rs.getInt(1) > 0) {
                JOptionPane.showMessageDialog(inputDialog, "No Ruangan sudah terisi! Gunakan ruangan lain.");
                rs.close(); cekPst.close(); return;
            }
            rs.close(); cekPst.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(inputDialog, "Error: " + e.getMessage()); return;
        }

        try {
            String sql = "INSERT INTO pasien (no_ruangan, nama, alamat, no_ktp, jk, no_telp) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, noRuangan);
            pst.setString(2, nama);
            pst.setString(3, alamat);
            pst.setString(4, noKtp);
            pst.setString(5, jk);
            pst.setString(6, noTelp);
            pst.executeUpdate(); 
            pst.close();
            JOptionPane.showMessageDialog(inputDialog, "Data berhasil disimpan!");
            loadData(); 
            clearDialogForm();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(inputDialog, "Error: " + e.getMessage());
        }
    }

    private void ubah() {
        String noRuangan = txtNoRuangan.getText().trim();
        if (noRuangan.isEmpty()) return;
        
        try {
            String sql = "UPDATE pasien SET nama=?, alamat=?, no_ktp=?, jk=?, no_telp=? WHERE no_ruangan=?";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, txtNamaPasien.getText().trim());
            pst.setString(2, txtAlamat.getText().trim());
            pst.setString(3, txtNoKtp.getText().trim());
            pst.setString(4, rbLaki.isSelected() ? "L" : "P");
            pst.setString(5, txtNoTelp.getText().trim());
            pst.setString(6, noRuangan);
            pst.executeUpdate(); 
            pst.close();
            JOptionPane.showMessageDialog(inputDialog, "Data berhasil diubah!");
            loadData(); 
            clearDialogForm();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(inputDialog, "Error: " + e.getMessage());
        }
    }

    private void hapus() {
        String noRuangan = txtNoRuangan.getText().trim();
        if (noRuangan.isEmpty()) return;
        
        try {
            String sql = "DELETE FROM pasien WHERE no_ruangan=?";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, noRuangan);
            pst.executeUpdate(); 
            pst.close();
            JOptionPane.showMessageDialog(inputDialog, "Data berhasil dihapus!");
            loadData(); 
            clearDialogForm();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(inputDialog, "Error: " + e.getMessage());
        }
    }

    private void cetakData() {
        int rowCount = tablePasien.getRowCount();
        if (rowCount == 0) {
            JOptionPane.showMessageDialog(this, "Tidak ada data untuk dicetak!", "Info", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        
        // Membuat preview cetak sederhana
        StringBuilder sb = new StringBuilder();
        sb.append("=== DATA PASIEN ===\n");
        sb.append("========================================\n\n");
        
        for (int i = 0; i < rowCount; i++) {
            sb.append((i+1) + ". ");
            sb.append("No Ruangan: ").append(tablePasien.getValueAt(i, 0)).append("\n");
            sb.append("   Nama Pasien: ").append(tablePasien.getValueAt(i, 1)).append("\n");
            sb.append("   Alamat: ").append(tablePasien.getValueAt(i, 2)).append("\n");
            sb.append("   No KTP/NIK: ").append(tablePasien.getValueAt(i, 3)).append("\n");
            sb.append("   JK: ").append(tablePasien.getValueAt(i, 4)).append("\n");
            sb.append("   No Telp: ").append(tablePasien.getValueAt(i, 5)).append("\n");
            sb.append("----------------------------------------\n");
        }
        
        sb.append("\nTotal Pasien: ").append(rowCount);
        sb.append("\n========================================");
        
        // Tampilkan di dialog
        JTextArea textArea = new JTextArea(sb.toString());
        textArea.setEditable(false);
        textArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(500, 400));
        
        JOptionPane.showMessageDialog(this, scrollPane, "Preview Cetak Data Pasien", JOptionPane.INFORMATION_MESSAGE);
    }

    private void clearDialogForm() {
        txtNoRuangan.setText("");
        txtNamaPasien.setText("");
        txtAlamat.setText("");
        txtNoKtp.setText("");
        txtNoTelp.setText("");
        bgJk.clearSelection();
    }
}