/*
 * Form Pembayaran - Berdasarkan Resep Obat dari Pemeriksaan
 * Terintegrasi dengan form_periksa yang sudah memiliki fitur resep
 */
package tampilan;

import javax.swing.*;
import javax.swing.table.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.ArrayList;

public class form_pembayaran extends JPanel {
    private Connection conn;
    private DefaultTableModel tableModel;
    
    private static final Color SIDEBAR_BG = new Color(0x1B4332);
    private static final Color SIDEBAR_ACTIVE = new Color(0x2D6A4F);
    private static final Color BUTTON_GREEN = new Color(0x52B788);
    private static final Color CONTENT_BG = new Color(0xF4F6F4);
    private static final Color TABLE_HEADER = new Color(0x1B4332);
    
    private JTextField txtFilterPasien, txtFilterStatus;
    private JButton btnFilter, btnBayar, btnCetak, btnRefresh, btnCekData;
    private JTable tablePembayaran;
    private JLabel lblTotalPembayaran, lblGrandTotal;
    
    private JDialog inputDialog;
    private JTextField txtIdPembayaran, txtTotalBayar, txtTglBayar;
    private JComboBox<String> cmbIdResep, cmbMetode;
    private JTextArea txtDetailResep;
    
    public form_pembayaran() {
        koneksi.koneksi k = new koneksi.koneksi();
        conn = k.Connect();
        
        if (conn == null) {
            JOptionPane.showMessageDialog(this, "Gagal koneksi ke database!");
            return;
        }
        
        initComponents();
        loadData();
        loadComboData();
        createInputDialog();
    }
    
    private void initComponents() {
        setLayout(new BorderLayout());
        setBackground(CONTENT_BG);
        setBorder(new EmptyBorder(15, 20, 15, 20));

        JLabel headerTitle = new JLabel("Pembayaran Berobat");
        headerTitle.setFont(new Font("Segoe UI", Font.BOLD, 24));
        headerTitle.setForeground(SIDEBAR_BG);
        headerTitle.setBorder(new EmptyBorder(0, 0, 15, 0));

        // Filter Panel
        JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 8));
        filterPanel.setBackground(CONTENT_BG);
        filterPanel.setBorder(new EmptyBorder(0, 0, 15, 0));

        int fieldHeight = 36;

        // Filter Nama Pasien
        JPanel pasienPanel = new JPanel(new BorderLayout(5, 3));
        pasienPanel.setBackground(CONTENT_BG);
        JLabel lblFilterPasien = new JLabel("Nama Pasien");
        lblFilterPasien.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblFilterPasien.setForeground(SIDEBAR_BG);
        txtFilterPasien = new JTextField(18);
        txtFilterPasien.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        txtFilterPasien.setPreferredSize(new Dimension(180, fieldHeight));
        txtFilterPasien.addActionListener(e -> applyFilter());
        pasienPanel.add(lblFilterPasien, BorderLayout.NORTH);
        pasienPanel.add(txtFilterPasien, BorderLayout.CENTER);
        filterPanel.add(pasienPanel);

        // Filter Status Pembayaran
        JPanel statusPanel = new JPanel(new BorderLayout(5, 3));
        statusPanel.setBackground(CONTENT_BG);
        JLabel lblFilterStatus = new JLabel("Status/Metode");
        lblFilterStatus.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblFilterStatus.setForeground(SIDEBAR_BG);
        txtFilterStatus = new JTextField(18);
        txtFilterStatus.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        txtFilterStatus.setPreferredSize(new Dimension(150, fieldHeight));
        txtFilterStatus.setToolTipText("Filter berdasarkan metode (Tunai/Transfer/E-Wallet)");
        txtFilterStatus.addActionListener(e -> applyFilter());
        statusPanel.add(lblFilterStatus, BorderLayout.NORTH);
        statusPanel.add(txtFilterStatus, BorderLayout.CENTER);
        filterPanel.add(statusPanel);

        // Tombol Filter
        JPanel btnFilterWrapper = new JPanel(new BorderLayout());
        btnFilterWrapper.setBackground(CONTENT_BG);
        btnFilterWrapper.setBorder(new EmptyBorder(22, 0, 0, 0));

        btnFilter = new JButton("Terapkan Filter");
        btnFilter.setBackground(SIDEBAR_BG);
        btnFilter.setForeground(Color.WHITE);
        btnFilter.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnFilter.setFocusPainted(false);
        btnFilter.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnFilter.setPreferredSize(new Dimension(140, fieldHeight));
        btnFilter.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { btnFilter.setBackground(SIDEBAR_ACTIVE); }
            public void mouseExited(MouseEvent e) { btnFilter.setBackground(SIDEBAR_BG); }
        });
        btnFilterWrapper.add(btnFilter, BorderLayout.NORTH);
        filterPanel.add(btnFilterWrapper);

        // Button Panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 8));
        buttonPanel.setBackground(CONTENT_BG);
        buttonPanel.setBorder(new EmptyBorder(0, 0, 15, 0));

        btnBayar = new JButton("💰 Proses Pembayaran");
        btnBayar.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnBayar.setBackground(new Color(0x28A745));
        btnBayar.setForeground(Color.WHITE);
        btnBayar.setFocusPainted(false);
        btnBayar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnBayar.setBorder(new EmptyBorder(10, 18, 10, 18));

        btnCetak = new JButton("🖨️ Cetak Struk");
        btnCetak.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnCetak.setBackground(new Color(0x6C757D));
        btnCetak.setForeground(Color.WHITE);
        btnCetak.setFocusPainted(false);
        btnCetak.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnCetak.setBorder(new EmptyBorder(10, 25, 10, 25));

        btnRefresh = new JButton("⟳ Refresh");
        btnRefresh.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnRefresh.setBackground(SIDEBAR_ACTIVE);
        btnRefresh.setForeground(Color.WHITE);
        btnRefresh.setFocusPainted(false);
        btnRefresh.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnRefresh.setBorder(new EmptyBorder(10, 25, 10, 25));
        
        btnCekData = new JButton("🔍 Cek Data Database");
        btnCekData.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnCekData.setBackground(new Color(0x17A2B8));
        btnCekData.setForeground(Color.WHITE);
        btnCekData.setFocusPainted(false);
        btnCekData.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnCekData.setBorder(new EmptyBorder(10, 18, 10, 18));

        buttonPanel.add(btnBayar);
        buttonPanel.add(btnCetak);
        buttonPanel.add(btnRefresh);
        buttonPanel.add(btnCekData);

        // Table
        String[] columns = {"ID Bayar", "ID Resep", "Pasien", "Total Bayar", "Tgl Bayar", "Metode", "Status"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override public boolean isCellEditable(int row, int column) { return false; }
        };

        tablePembayaran = new JTable(tableModel);
        tablePembayaran.setRowHeight(50);
        tablePembayaran.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        tablePembayaran.setSelectionBackground(new Color(0xD8F3DC));
        tablePembayaran.setSelectionForeground(SIDEBAR_BG);
        tablePembayaran.setGridColor(new Color(0xE0E0E0));
        tablePembayaran.setShowVerticalLines(true);
        tablePembayaran.setShowHorizontalLines(true);
        tablePembayaran.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);

        tablePembayaran.getColumnModel().getColumn(0).setPreferredWidth(100);
        tablePembayaran.getColumnModel().getColumn(1).setPreferredWidth(100);
        tablePembayaran.getColumnModel().getColumn(2).setPreferredWidth(180);
        tablePembayaran.getColumnModel().getColumn(3).setPreferredWidth(120);
        tablePembayaran.getColumnModel().getColumn(4).setPreferredWidth(100);
        tablePembayaran.getColumnModel().getColumn(5).setPreferredWidth(100);
        tablePembayaran.getColumnModel().getColumn(6).setPreferredWidth(100);

        JTableHeader header = tablePembayaran.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 13));
        header.setBackground(TABLE_HEADER);
        header.setForeground(Color.BLACK);
        header.setPreferredSize(new Dimension(0, 35));

        JScrollPane scrollPane = new JScrollPane(tablePembayaran);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(0xE0E0E0)));
        scrollPane.getViewport().setBackground(Color.WHITE);

        // Bottom Panel
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        bottomPanel.setBackground(CONTENT_BG);
        bottomPanel.setBorder(new EmptyBorder(15, 0, 0, 0));
        lblTotalPembayaran = new JLabel("Total Transaksi: 0");
        lblTotalPembayaran.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblTotalPembayaran.setForeground(SIDEBAR_BG);
        bottomPanel.add(lblTotalPembayaran);
        
        lblGrandTotal = new JLabel("   |   Grand Total: Rp 0");
        lblGrandTotal.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblGrandTotal.setForeground(new Color(0xDC3545));
        bottomPanel.add(lblGrandTotal);

        // Layout Utama
        JPanel northPanel = new JPanel(new BorderLayout(0, 8));
        northPanel.setBackground(CONTENT_BG);
        northPanel.add(headerTitle, BorderLayout.NORTH);
        northPanel.add(filterPanel, BorderLayout.CENTER);
        northPanel.add(buttonPanel, BorderLayout.SOUTH);

        add(northPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);

        // Action Listeners
        btnBayar.addActionListener(e -> showInputDialog(false, null));
        btnFilter.addActionListener(e -> applyFilter());
        btnRefresh.addActionListener(e -> { resetFilter(); loadData(); loadComboData(); });
        btnCetak.addActionListener(e -> cetakStruk());
        btnCekData.addActionListener(e -> cekDataDatabase());

        tablePembayaran.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    int row = tablePembayaran.getSelectedRow();
                    if (row >= 0) showDetailPembayaran(row);
                }
            }
        });
    }
    
    // Method untuk cek data database (debugging)
    private void cekDataDatabase() {
        try {
            Statement st = conn.createStatement();
            
            // Cek jumlah resep
            ResultSet rs = st.executeQuery("SELECT COUNT(*) as total FROM resep");
            rs.next();
            int totalResep = rs.getInt("total");
            rs.close();
            
            // Cek jumlah periksa
            rs = st.executeQuery("SELECT COUNT(*) as total FROM periksa");
            rs.next();
            int totalPeriksa = rs.getInt("total");
            rs.close();
            
            // Cek jumlah pembayaran
            rs = st.executeQuery("SELECT COUNT(*) as total FROM pembayaran");
            rs.next();
            int totalPembayaranDb = rs.getInt("total");
            rs.close();
            
            // Cek resep yang belum dibayar
            rs = st.executeQuery(
                "SELECT COUNT(*) as total FROM resep r " +
                "WHERE r.id_resep NOT IN (SELECT COALESCE(id_resep, '') FROM pembayaran)"
            );
            rs.next();
            int totalBelumBayar = rs.getInt("total");
            rs.close();
            
            // Ambil sample data resep
            StringBuilder sampleResep = new StringBuilder();
            rs = st.executeQuery("SELECT id_resep, id_periksa, id_obat, jumlah, subtotal FROM resep LIMIT 5");
            while (rs.next()) {
                sampleResep.append("  - ").append(rs.getString("id_resep"))
                          .append(" (periksa: ").append(rs.getString("id_periksa"))
                          .append(", obat: ").append(rs.getString("id_obat"))
                          .append(", jml: ").append(rs.getInt("jumlah"))
                          .append(", Rp ").append(String.format("%,.0f", rs.getDouble("subtotal")))
                          .append(")\n");
            }
            rs.close();
            
            String msg = String.format(
                "╔══════════════════════════════════════════════════════════════╗\n" +
                "║                    INFO DATABASE                             ║\n" +
                "╠══════════════════════════════════════════════════════════════╣\n" +
                "║ Total Pemeriksaan (periksa)     : %-26d ║\n" +
                "║ Total Resep                     : %-26d ║\n" +
                "║ Total Pembayaran                : %-26d ║\n" +
                "╠══════════════════════════════════════════════════════════════╣\n" +
                "║ Resep BELUM Dibayar             : %-26d ║\n" +
                "╠══════════════════════════════════════════════════════════════╣\n" +
                "║ SAMPLE DATA RESEP (max 5):                                  ║\n" +
                "%s" +
                "╚══════════════════════════════════════════════════════════════╝\n\n" +
                "💡 TIPS:\n" +
                "• Jika Total Resep = 0, buka menu Pemeriksaan dan buat pemeriksaan dengan resep\n" +
                "• Jika Resep Belum Dibayar = 0, semua resep sudah lunas\n" +
                "• Klik Refresh setelah menambah data baru",
                totalPeriksa, totalResep, totalPembayaranDb, totalBelumBayar, sampleResep.toString()
            );
            
            JTextArea textArea = new JTextArea(msg);
            textArea.setEditable(false);
            textArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
            JScrollPane scrollPane = new JScrollPane(textArea);
            scrollPane.setPreferredSize(new Dimension(700, 500));
            JOptionPane.showMessageDialog(this, scrollPane, "Info Database", JOptionPane.INFORMATION_MESSAGE);
            
            st.close();
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    private void loadComboData() {
        try {
            // Refresh combo box
            if (cmbIdResep == null) {
                cmbIdResep = new JComboBox<>();
            }
            cmbIdResep.removeAllItems();
            
            Statement st = conn.createStatement();
            
            // Query untuk ambil resep yang belum dibayar
            String sql = 
                "SELECT r.id_resep, d.nama_pasien, SUM(r.subtotal) as total, COUNT(r.id_obat) as jml_obat " +
                "FROM resep r " +
                "JOIN periksa p ON r.id_periksa = p.id_periksa " +
                "JOIN daftar_berobat d ON p.id_daftar = d.id_daftar " +
                "WHERE r.id_resep NOT IN (SELECT COALESCE(id_resep, '') FROM pembayaran) " +
                "GROUP BY r.id_resep, d.nama_pasien " +
                "ORDER BY r.id_resep";
            
            ResultSet rs = st.executeQuery(sql);
            
            boolean hasData = false;
            while (rs.next()) {
                String idResep = rs.getString("id_resep");
                String pasien = rs.getString("nama_pasien");
                double total = rs.getDouble("total");
                int jmlObat = rs.getInt("jml_obat");
                
                String displayText = idResep + " - " + pasien + " (" + jmlObat + " obat) - Rp " + String.format("%,.0f", total);
                cmbIdResep.addItem(displayText);
                hasData = true;
            }
            rs.close();
            st.close();
            
            if (!hasData) {
                cmbIdResep.addItem("--- Tidak ada resep yang belum dibayar ---");
            }
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading combo data: " + e.getMessage());
            e.printStackTrace();
            cmbIdResep.addItem("--- Error loading data ---");
        }
    }
    
    private void createInputDialog() {
        inputDialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(this), "Proses Pembayaran", true);
        inputDialog.setSize(700, 650);
        inputDialog.setLocationRelativeTo(this);
        inputDialog.setResizable(true);

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(new EmptyBorder(25, 30, 25, 30));
        formPanel.setBackground(Color.WHITE);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 15, 10, 15);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // ID Pembayaran
        gbc.gridy = 0;
        gbc.gridx = 0; gbc.weightx = 0;
        JLabel lblId = new JLabel("ID Pembayaran");
        lblId.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblId.setForeground(SIDEBAR_BG);
        formPanel.add(lblId, gbc);
        gbc.gridx = 1; gbc.weightx = 1.0;
        txtIdPembayaran = new JTextField(20);
        txtIdPembayaran.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        txtIdPembayaran.setEditable(false);
        txtIdPembayaran.setBackground(new Color(0xF5F5F5));
        formPanel.add(txtIdPembayaran, gbc);

        // Pilih Resep
        gbc.gridy = 1;
        gbc.gridx = 0; gbc.weightx = 0;
        JLabel lblResep = new JLabel("Pilih Resep");
        lblResep.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblResep.setForeground(SIDEBAR_BG);
        formPanel.add(lblResep, gbc);
        gbc.gridx = 1; gbc.weightx = 1.0;
        formPanel.add(cmbIdResep, gbc);
        
        // Tombol Cek Detail
        JPanel btnCekPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 5, 0));
        btnCekPanel.setBackground(Color.WHITE);
        JButton btnCekDetail = new JButton("📋 Cek Detail Resep");
        btnCekDetail.setBackground(SIDEBAR_ACTIVE);
        btnCekDetail.setForeground(Color.WHITE);
        btnCekDetail.setFont(new Font("Segoe UI", Font.BOLD, 11));
        btnCekDetail.setFocusPainted(false);
        btnCekDetail.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnCekDetail.addActionListener(e -> loadDetailResep());
        btnCekPanel.add(btnCekDetail);
        
        gbc.gridy = 2;
        gbc.gridx = 1;
        formPanel.add(btnCekPanel, gbc);

        // Detail Resep
        gbc.gridy = 3;
        gbc.gridx = 0; gbc.weightx = 0;
        JLabel lblDetail = new JLabel("Detail Resep");
        lblDetail.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblDetail.setForeground(SIDEBAR_BG);
        formPanel.add(lblDetail, gbc);
        gbc.gridx = 1; gbc.weightx = 1.0;
        txtDetailResep = new JTextArea(10, 30);
        txtDetailResep.setFont(new Font("Monospaced", Font.PLAIN, 12));
        txtDetailResep.setEditable(false);
        txtDetailResep.setBackground(new Color(0xF5F5F5));
        JScrollPane scrollDetail = new JScrollPane(txtDetailResep);
        scrollDetail.setPreferredSize(new Dimension(450, 180));
        formPanel.add(scrollDetail, gbc);

        // Total Bayar
        gbc.gridy = 4;
        gbc.gridx = 0; gbc.weightx = 0;
        JLabel lblTotal = new JLabel("Total Bayar (Rp)");
        lblTotal.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblTotal.setForeground(SIDEBAR_BG);
        formPanel.add(lblTotal, gbc);
        gbc.gridx = 1; gbc.weightx = 1.0;
        txtTotalBayar = new JTextField(20);
        txtTotalBayar.setFont(new Font("Segoe UI", Font.BOLD, 14));
        txtTotalBayar.setForeground(new Color(0xDC3545));
        txtTotalBayar.setEditable(false);
        txtTotalBayar.setBackground(new Color(0xF5F5F5));
        formPanel.add(txtTotalBayar, gbc);

        // Tanggal Bayar
        gbc.gridy = 5;
        gbc.gridx = 0; gbc.weightx = 0;
        JLabel lblTgl = new JLabel("Tanggal Bayar");
        lblTgl.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblTgl.setForeground(SIDEBAR_BG);
        formPanel.add(lblTgl, gbc);
        gbc.gridx = 1; gbc.weightx = 1.0;
        txtTglBayar = new JTextField(20);
        txtTglBayar.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        txtTglBayar.setText(java.time.LocalDate.now().toString());
        formPanel.add(txtTglBayar, gbc);

        // Metode Pembayaran
        gbc.gridy = 6;
        gbc.gridx = 0; gbc.weightx = 0;
        JLabel lblMetode = new JLabel("Metode Pembayaran");
        lblMetode.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblMetode.setForeground(SIDEBAR_BG);
        formPanel.add(lblMetode, gbc);
        gbc.gridx = 1; gbc.weightx = 1.0;
        cmbMetode = new JComboBox<>(new String[]{"Tunai", "Transfer Bank", "E-Wallet", "Kartu Kredit"});
        cmbMetode.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        formPanel.add(cmbMetode, gbc);

        // Buttons
        gbc.gridy = 7; gbc.gridx = 0; gbc.gridwidth = 2; gbc.anchor = GridBagConstraints.CENTER;
        gbc.fill = GridBagConstraints.NONE;

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        JButton btnSimpan = new JButton("✅ Proses & Bayar");
        JButton btnBatal = new JButton("❌ Batal");

        btnSimpan.setBackground(BUTTON_GREEN);
        btnBatal.setBackground(new Color(0x6C757D));
        btnSimpan.setForeground(Color.WHITE);
        btnBatal.setForeground(Color.WHITE);
        btnSimpan.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnBatal.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnSimpan.setFocusPainted(false);
        btnBatal.setFocusPainted(false);
        btnSimpan.setPreferredSize(new Dimension(130, 40));
        btnBatal.setPreferredSize(new Dimension(100, 40));

        btnPanel.add(btnSimpan);
        btnPanel.add(btnBatal);
        formPanel.add(btnPanel, gbc);
        inputDialog.add(formPanel, BorderLayout.CENTER);

        btnSimpan.addActionListener(e -> { simpan(); inputDialog.dispose(); });
        btnBatal.addActionListener(e -> inputDialog.dispose());
    }
    
    private void loadDetailResep() {
        if (cmbIdResep.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(inputDialog, "Pilih resep terlebih dahulu!");
            return;
        }
        
        String selected = cmbIdResep.getSelectedItem().toString();
        if (selected.startsWith("---")) {
            JOptionPane.showMessageDialog(inputDialog, 
                "⚠️ TIDAK ADA RESEP YANG TERSEDIA!\n\n" +
                "Penyebab:\n" +
                "1. Belum ada pemeriksaan yang dibuat\n" +
                "2. Pemeriksaan belum memiliki resep obat\n" +
                "3. Semua resep sudah dibayar\n\n" +
                "Solusi:\n" +
                "• Buka menu Pemeriksaan\n" +
                "• Buat pemeriksaan baru dengan resep obat\n" +
                "• Klik Refresh setelah selesai");
            return;
        }
        
        // Ambil ID resep dari string
        String idResep = selected.split(" - ")[0];
        
        try {
            String sql = 
                "SELECT o.nama_obat, r.jumlah, r.subtotal, o.harga " +
                "FROM resep r " +
                "JOIN obat o ON r.id_obat = o.id_obat " +
                "WHERE r.id_resep = ?";
            
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, idResep);
            ResultSet rs = pst.executeQuery();
            
            StringBuilder sb = new StringBuilder();
            sb.append("╔════════════════════════════════════════════════════════════════╗\n");
            sb.append("║                       DETAIL RESEP OBAT                        ║\n");
            sb.append("╠════════════════════════════════════════════════════════════════╣\n");
            sb.append("║ ID Resep : ").append(String.format("%-46s", idResep)).append("║\n");
            sb.append("╠════════════════════════════════════════════════════════════════╣\n");
            sb.append("║ No. │ Nama Obat                         │ Jml │ Harga     │ Subtotal ║\n");
            sb.append("╠════════════════════════════════════════════════════════════════╣\n");
            
            double total = 0;
            int no = 1;
            boolean hasData = false;
            
            while (rs.next()) {
                hasData = true;
                String nama = rs.getString("nama_obat");
                int jumlah = rs.getInt("jumlah");
                double harga = rs.getDouble("harga");
                double subtotal = rs.getDouble("subtotal");
                
                String namaTrunc = nama.length() > 29 ? nama.substring(0, 26) + "..." : nama;
                sb.append(String.format("║ %2d. │ %-29s │ %3d │ Rp %,6.0f │ Rp %,8.0f ║\n", 
                      no, namaTrunc, jumlah, harga, subtotal));
                total += subtotal;
                no++;
            }
            
            if (!hasData) {
                sb.append("║                       TIDAK ADA DATA OBAT                      ║\n");
            }
            
            sb.append("╠════════════════════════════════════════════════════════════════╣\n");
            sb.append(String.format("║                                              TOTAL │ Rp %,10.0f ║\n", total));
            sb.append("╚════════════════════════════════════════════════════════════════╝\n");
            
            txtDetailResep.setText(sb.toString());
            txtTotalBayar.setText(String.format("Rp %,.0f", total));
            
            rs.close();
            pst.close();
            
            if (!hasData) {
                JOptionPane.showMessageDialog(inputDialog, 
                    "⚠️ Resep ini tidak memiliki detail obat!\n" +
                    "Kemungkinan data rusak. Silakan hapus resep ini dan buat ulang.");
            }
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(inputDialog, "Error: " + e.getMessage());
            e.printStackTrace();
            txtDetailResep.setText("Error loading detail: " + e.getMessage());
        }
    }

    private void showInputDialog(boolean isEdit, Integer row) {
        clearDialogForm();
        generateIdPembayaran();
        loadComboData();
        
        // Cek apakah ada resep yang tersedia
        if (cmbIdResep.getItemCount() > 0 && cmbIdResep.getItemAt(0).startsWith("---")) {
            int confirm = JOptionPane.showConfirmDialog(this, 
                "⚠️ Belum ada resep yang tersedia untuk dibayar!\n\n" +
                "Apakah Anda ingin membuka menu Pemeriksaan untuk membuat resep?",
                "Info", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
            if (confirm == JOptionPane.YES_OPTION) {
                // Buka form pemeriksaan
                SwingUtilities.getWindowAncestor(this).dispose();
                new menuutama().setVisible(true);
                // TODO: Buka langsung form pemeriksaan
            }
            return;
        }
        
        inputDialog.setTitle("Proses Pembayaran");
        inputDialog.setVisible(true);
    }
    
    private void showDetailPembayaran(int row) {
        String idBayar = tableModel.getValueAt(row, 0).toString();
        String idResep = tableModel.getValueAt(row, 1).toString();
        String pasien = tableModel.getValueAt(row, 2).toString();
        String total = tableModel.getValueAt(row, 3).toString();
        String tgl = tableModel.getValueAt(row, 4).toString();
        String metode = tableModel.getValueAt(row, 5).toString();
        
        StringBuilder detail = new StringBuilder();
        detail.append("╔════════════════════════════════════════════════════════╗\n");
        detail.append("║                 DETAIL PEMBAYARAN                      ║\n");
        detail.append("╠════════════════════════════════════════════════════════╣\n");
        detail.append("║ ID Pembayaran : ").append(String.format("%-28s", idBayar)).append("║\n");
        detail.append("║ ID Resep      : ").append(String.format("%-28s", idResep)).append("║\n");
        detail.append("║ Pasien        : ").append(String.format("%-28s", pasien.length() > 28 ? pasien.substring(0, 25) + "..." : pasien)).append("║\n");
        detail.append("║ Total Bayar   : ").append(String.format("%-28s", total)).append("║\n");
        detail.append("║ Tanggal       : ").append(String.format("%-28s", tgl)).append("║\n");
        detail.append("║ Metode        : ").append(String.format("%-28s", metode)).append("║\n");
        detail.append("║ Status        : LUNAS                                   ║\n");
        detail.append("╚════════════════════════════════════════════════════════╝\n");
        
        JTextArea textArea = new JTextArea(detail.toString());
        textArea.setEditable(false);
        textArea.setFont(new Font("Monospaced", Font.BOLD, 12));
        textArea.setBackground(Color.BLACK);
        textArea.setForeground(Color.WHITE);
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(550, 280));
        JOptionPane.showMessageDialog(this, scrollPane, "Detail Pembayaran", JOptionPane.INFORMATION_MESSAGE);
    }

    private void loadData() { 
        loadDataWithFilter("", ""); 
    }

    private void applyFilter() {
        String pasien = txtFilterPasien.getText().trim();
        String status = txtFilterStatus.getText().trim();
        loadDataWithFilter(pasien, status);
    }

    private void resetFilter() {
        txtFilterPasien.setText("");
        txtFilterStatus.setText("");
        loadData();
    }

    private void loadDataWithFilter(String namaPasien, String metode) {
        tableModel.setRowCount(0);
        if (conn == null) return;

        StringBuilder sql = new StringBuilder(
            "SELECT pb.id_pembayaran, pb.id_resep, d.nama_pasien, " +
            "pb.total_bayar, pb.tgl_bayar, pb.metode " +
            "FROM pembayaran pb " +
            "JOIN resep r ON pb.id_resep = r.id_resep " +
            "JOIN periksa p ON r.id_periksa = p.id_periksa " +
            "JOIN daftar_berobat d ON p.id_daftar = d.id_daftar WHERE 1=1"
        );
        ArrayList<Object> params = new ArrayList<>();

        if (!namaPasien.isEmpty()) { 
            sql.append(" AND d.nama_pasien LIKE ?"); 
            params.add("%" + namaPasien + "%"); 
        }
        if (!metode.isEmpty() && !metode.equalsIgnoreCase("Semua")) { 
            sql.append(" AND pb.metode LIKE ?"); 
            params.add("%" + metode + "%"); 
        }
        sql.append(" ORDER BY pb.tgl_bayar DESC");

        try (PreparedStatement pst = conn.prepareStatement(sql.toString())) {
            for (int i = 0; i < params.size(); i++) {
                pst.setObject(i + 1, params.get(i));
            }
            ResultSet rs = pst.executeQuery();
            int count = 0;
            double grandTotal = 0;
            while (rs.next()) {
                double total = rs.getDouble("total_bayar");
                tableModel.addRow(new Object[]{
                    rs.getString("id_pembayaran"),
                    rs.getString("id_resep"),
                    rs.getString("nama_pasien"),
                    "Rp " + String.format("%,.0f", total),
                    rs.getString("tgl_bayar"),
                    rs.getString("metode"),
                    "LUNAS"
                });
                count++;
                grandTotal += total;
            }
            lblTotalPembayaran.setText("Total Transaksi: " + count);
            lblGrandTotal.setText("   |   Grand Total: Rp " + String.format("%,.0f", grandTotal));
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error load data: " + e.getMessage());
        }
    }

    private void generateIdPembayaran() {
        try {
            String sql = "SELECT id_pembayaran FROM pembayaran ORDER BY id_pembayaran DESC LIMIT 1";
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            int newNumber = 1;
            if (rs.next()) {
                String last = rs.getString("id_pembayaran");
                if (last != null && last.length() > 2) {
                    newNumber = Integer.parseInt(last.substring(2)) + 1;
                }
            }
            txtIdPembayaran.setText(String.format("BY%03d", newNumber));
            rs.close();
            st.close();
        } catch (Exception e) {
            txtIdPembayaran.setText("BY001");
        }
    }

    private void simpan() {
        String idBayar = txtIdPembayaran.getText().trim();
        
        if (cmbIdResep.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(inputDialog, "Pilih resep terlebih dahulu!");
            return;
        }
        
        String selected = cmbIdResep.getSelectedItem().toString();
        if (selected.startsWith("---")) {
            JOptionPane.showMessageDialog(inputDialog, "Tidak ada resep yang tersedia untuk dibayar!");
            return;
        }
        
        String idResep = selected.split(" - ")[0];
        String totalBayarStr = txtTotalBayar.getText().trim().replace("Rp ", "").replace(",", "");
        String tglBayar = txtTglBayar.getText().trim();
        String metode = cmbMetode.getSelectedItem().toString();

        if (idBayar.isEmpty() || idResep.isEmpty() || totalBayarStr.isEmpty() || tglBayar.isEmpty()) {
            JOptionPane.showMessageDialog(inputDialog, "Semua field harus diisi!");
            return;
        }

        double totalBayar;
        try {
            totalBayar = Double.parseDouble(totalBayarStr);
            if (totalBayar <= 0) throw new NumberFormatException();
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(inputDialog, "Total bayar tidak valid!");
            return;
        }

        // Konfirmasi pembayaran
        int confirm = JOptionPane.showConfirmDialog(inputDialog, 
            String.format("╔════════════════════════════════════════╗\n" +
                          "║         KONFIRMASI PEMBAYARAN          ║\n" +
                          "╠════════════════════════════════════════╣\n" +
                          "║ ID Resep   : %-18s ║\n" +
                          "║ Total Bayar: Rp %,-15.0f ║\n" +
                          "║ Metode     : %-18s ║\n" +
                          "╠════════════════════════════════════════╣\n" +
                          "║   Lanjutkan pembayaran?                ║\n" +
                          "╚════════════════════════════════════════╝",
                          idResep, totalBayar, metode),
            "Konfirmasi Pembayaran", 
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE);
        
        if (confirm != JOptionPane.YES_OPTION) return;

        try {
            // Cek apakah sudah pernah dibayar
            String cekSql = "SELECT COUNT(*) FROM pembayaran WHERE id_resep = ?";
            PreparedStatement cekPst = conn.prepareStatement(cekSql);
            cekPst.setString(1, idResep);
            ResultSet rs = cekPst.executeQuery();
            rs.next();
            if (rs.getInt(1) > 0) {
                JOptionPane.showMessageDialog(inputDialog, "❌ Resep ini sudah dibayar sebelumnya!");
                rs.close();
                cekPst.close();
                return;
            }
            rs.close();
            cekPst.close();
            
            // Insert pembayaran
            String sql = "INSERT INTO pembayaran (id_pembayaran, id_resep, total_bayar, tgl_bayar, metode) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, idBayar);
            pst.setString(2, idResep);
            pst.setDouble(3, totalBayar);
            pst.setString(4, tglBayar);
            pst.setString(5, metode);
            int rowsInserted = pst.executeUpdate();
            pst.close();
            
            if (rowsInserted > 0) {
                JOptionPane.showMessageDialog(inputDialog, 
                    String.format("✅ PEMBAYARAN BERHASIL!\n\n" +
                                  "╔════════════════════════════════════════╗\n" +
                                  "║ ID Pembayaran: %-18s ║\n" +
                                  "║ Total         : Rp %,-15.0f ║\n" +
                                  "║ Metode        : %-18s ║\n" +
                                  "╚════════════════════════════════════════╝\n\n" +
                                  "Terima kasih!", 
                                  idBayar, totalBayar, metode),
                    "Sukses", JOptionPane.INFORMATION_MESSAGE);
                
                // Refresh data
                loadData();
                loadComboData();
                clearDialogForm();
            } else {
                JOptionPane.showMessageDialog(inputDialog, "Gagal memproses pembayaran!");
            }
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(inputDialog, "Error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void cetakStruk() {
        int row = tablePembayaran.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Pilih data pembayaran yang akan dicetak!");
            return;
        }
        
        String idBayar = tableModel.getValueAt(row, 0).toString();
        String idResep = tableModel.getValueAt(row, 1).toString();
        String pasien = tableModel.getValueAt(row, 2).toString();
        String total = tableModel.getValueAt(row, 3).toString();
        String tgl = tableModel.getValueAt(row, 4).toString();
        String metode = tableModel.getValueAt(row, 5).toString();
        
        StringBuilder sb = new StringBuilder();
        sb.append("╔════════════════════════════════════════════════════════╗\n");
        sb.append("║                    STRUK PEMBAYARAN                    ║\n");
        sb.append("║              RUMAH SAKIT SEHAT SENTOSA                 ║\n");
        sb.append("╠════════════════════════════════════════════════════════╣\n");
        sb.append("║ No. Pembayaran : ").append(String.format("%-28s", idBayar)).append("║\n");
        sb.append("║ No. Resep      : ").append(String.format("%-28s", idResep)).append("║\n");
        sb.append("║ Pasien         : ").append(String.format("%-28s", pasien.length() > 28 ? pasien.substring(0, 25) + "..." : pasien)).append("║\n");
        sb.append("╠════════════════════════════════════════════════════════╣\n");
        sb.append("║ Tanggal        : ").append(String.format("%-28s", tgl)).append("║\n");
        sb.append("║ Metode         : ").append(String.format("%-28s", metode)).append("║\n");
        sb.append("╠════════════════════════════════════════════════════════╣\n");
        sb.append("║ Total Bayar    : ").append(String.format("%-28s", total)).append("║\n");
        sb.append("╠════════════════════════════════════════════════════════╣\n");
        sb.append("║                    TERIMA KASIH                        ║\n");
        sb.append("║                Semoga Lekas Sembuh                     ║\n");
        sb.append("╚════════════════════════════════════════════════════════╝\n");
        
        JTextArea textArea = new JTextArea(sb.toString());
        textArea.setEditable(false);
        textArea.setFont(new Font("Monospaced", Font.BOLD, 12));
        textArea.setBackground(Color.BLACK);
        textArea.setForeground(Color.WHITE);
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(550, 380));
        JOptionPane.showMessageDialog(this, scrollPane, "Cetak Struk Pembayaran", JOptionPane.INFORMATION_MESSAGE);
    }

    private void clearDialogForm() {
        txtIdPembayaran.setText("");
        txtDetailResep.setText("");
        txtTotalBayar.setText("");
        txtTglBayar.setText(java.time.LocalDate.now().toString());
        cmbMetode.setSelectedIndex(0);
        if (cmbIdResep != null && cmbIdResep.getItemCount() > 0) {
            cmbIdResep.setSelectedIndex(0);
        }
    }
}