/*
 * Form Pendaftaran Berobat - Input Manual No Ruangan & Nama Pasien
 */
package tampilan;

import javax.swing.*;
import javax.swing.table.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.ArrayList;

public class form_daftar extends JPanel {
    private Connection conn;
    private DefaultTableModel tableModel;
    
    private static final Color SIDEBAR_BG = new Color(0x1B4332);
    private static final Color SIDEBAR_ACTIVE = new Color(0x2D6A4F);
    private static final Color BUTTON_GREEN = new Color(0x52B788);
    private static final Color CONTENT_BG = new Color(0xF4F6F4);
    private static final Color TABLE_HEADER = new Color(0x1B4332);
    
    private JTextField txtFilterPasien, txtFilterDokter;
    private JComboBox<String> cmbFilterStatus;
    private JButton btnFilter, btnTambah, btnCetak, btnRefresh;
    private JTable tableDaftar;
    private JLabel lblTotalDaftar;
    
    private JDialog inputDialog;
    private JTextField txtIdDaftar, txtNoRuangan, txtNamaPasien, txtTglDaftar;
    private JComboBox<String> cmbKdDokter, cmbStatus;
    
    public form_daftar() {
        koneksi.koneksi k = new koneksi.koneksi();
        conn = k.Connect();
        
        if (conn == null) {
            JOptionPane.showMessageDialog(this, "Gagal koneksi ke database!");
            return;
        }
        
        initComponents();
        loadData();
        loadComboData();
        createInputDialog();
    }
    
    private void initComponents() {
        setLayout(new BorderLayout());
        setBackground(CONTENT_BG);
        setBorder(new EmptyBorder(15, 20, 15, 20));

        JLabel headerTitle = new JLabel("Pendaftaran Berobat");
        headerTitle.setFont(new Font("Segoe UI", Font.BOLD, 24));
        headerTitle.setForeground(SIDEBAR_BG);
        headerTitle.setBorder(new EmptyBorder(0, 0, 15, 0));

        // Filter Panel
        JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 8));
        filterPanel.setBackground(CONTENT_BG);
        filterPanel.setBorder(new EmptyBorder(0, 0, 15, 0));

        int fieldHeight = 36;

        // Filter Nama Pasien
        JPanel pasienPanel = new JPanel(new BorderLayout(5, 3));
        pasienPanel.setBackground(CONTENT_BG);
        JLabel lblFilterPasien = new JLabel("Nama Pasien");
        lblFilterPasien.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblFilterPasien.setForeground(SIDEBAR_BG);
        txtFilterPasien = new JTextField(18);
        txtFilterPasien.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        txtFilterPasien.setPreferredSize(new Dimension(180, fieldHeight));
        txtFilterPasien.addActionListener(e -> applyFilter());
        pasienPanel.add(lblFilterPasien, BorderLayout.NORTH);
        pasienPanel.add(txtFilterPasien, BorderLayout.CENTER);
        filterPanel.add(pasienPanel);

        // Filter Nama Dokter
        JPanel dokterPanel = new JPanel(new BorderLayout(5, 3));
        dokterPanel.setBackground(CONTENT_BG);
        JLabel lblFilterDokter = new JLabel("Nama Dokter");
        lblFilterDokter.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblFilterDokter.setForeground(SIDEBAR_BG);
        txtFilterDokter = new JTextField(18);
        txtFilterDokter.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        txtFilterDokter.setPreferredSize(new Dimension(180, fieldHeight));
        txtFilterDokter.addActionListener(e -> applyFilter());
        dokterPanel.add(lblFilterDokter, BorderLayout.NORTH);
        dokterPanel.add(txtFilterDokter, BorderLayout.CENTER);
        filterPanel.add(dokterPanel);

        // Filter Status
        JPanel statusFilterPanel = new JPanel(new BorderLayout(5, 3));
        statusFilterPanel.setBackground(CONTENT_BG);
        JLabel lblFilterStatus = new JLabel("Status");
        lblFilterStatus.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblFilterStatus.setForeground(SIDEBAR_BG);
        cmbFilterStatus = new JComboBox<>(new String[]{"Semua", "Menunggu", "Selesai"});
        cmbFilterStatus.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        cmbFilterStatus.setPreferredSize(new Dimension(120, fieldHeight));
        statusFilterPanel.add(lblFilterStatus, BorderLayout.NORTH);
        statusFilterPanel.add(cmbFilterStatus, BorderLayout.CENTER);
        filterPanel.add(statusFilterPanel);

        // Tombol Filter
        JPanel btnFilterWrapper = new JPanel(new BorderLayout());
        btnFilterWrapper.setBackground(CONTENT_BG);
        btnFilterWrapper.setBorder(new EmptyBorder(22, 0, 0, 0));

        btnFilter = new JButton("Terapkan Filter");
        btnFilter.setBackground(SIDEBAR_BG);
        btnFilter.setForeground(Color.WHITE);
        btnFilter.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnFilter.setFocusPainted(false);
        btnFilter.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnFilter.setPreferredSize(new Dimension(140, fieldHeight));
        btnFilter.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { btnFilter.setBackground(SIDEBAR_ACTIVE); }
            public void mouseExited(MouseEvent e) { btnFilter.setBackground(SIDEBAR_BG); }
        });
        btnFilterWrapper.add(btnFilter, BorderLayout.NORTH);
        filterPanel.add(btnFilterWrapper);

        // Button Panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 8));
        buttonPanel.setBackground(CONTENT_BG);
        buttonPanel.setBorder(new EmptyBorder(0, 0, 15, 0));

        btnTambah = new JButton("+ Tambah Pendaftaran Baru");
        btnTambah.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnTambah.setBackground(SIDEBAR_BG);
        btnTambah.setForeground(Color.WHITE);
        btnTambah.setFocusPainted(false);
        btnTambah.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnTambah.setBorder(new EmptyBorder(10, 18, 10, 18));

        btnCetak = new JButton("🖨️ Cetak");
        btnCetak.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnCetak.setBackground(new Color(0x6C757D));
        btnCetak.setForeground(Color.WHITE);
        btnCetak.setFocusPainted(false);
        btnCetak.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnCetak.setBorder(new EmptyBorder(10, 25, 10, 25));

        btnRefresh = new JButton("⟳ Refresh");
        btnRefresh.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnRefresh.setBackground(SIDEBAR_ACTIVE);
        btnRefresh.setForeground(Color.WHITE);
        btnRefresh.setFocusPainted(false);
        btnRefresh.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnRefresh.setBorder(new EmptyBorder(10, 25, 10, 25));

        buttonPanel.add(btnTambah);
        buttonPanel.add(btnCetak);
        buttonPanel.add(btnRefresh);

        // Table
        String[] columns = {"ID Daftar", "No Ruangan", "Nama Pasien", "Kd Dokter", "Nama Dokter", "Tgl Daftar", "Status"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override public boolean isCellEditable(int row, int column) { return false; }
        };

        tableDaftar = new JTable(tableModel);
        tableDaftar.setRowHeight(50);
        tableDaftar.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        tableDaftar.setSelectionBackground(new Color(0xD8F3DC));
        tableDaftar.setSelectionForeground(SIDEBAR_BG);
        tableDaftar.setGridColor(new Color(0xE0E0E0));
        tableDaftar.setShowVerticalLines(true);
        tableDaftar.setShowHorizontalLines(true);
        tableDaftar.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);

        tableDaftar.getColumnModel().getColumn(0).setPreferredWidth(100);
        tableDaftar.getColumnModel().getColumn(1).setPreferredWidth(100);
        tableDaftar.getColumnModel().getColumn(2).setPreferredWidth(180);
        tableDaftar.getColumnModel().getColumn(3).setPreferredWidth(90);
        tableDaftar.getColumnModel().getColumn(4).setPreferredWidth(180);
        tableDaftar.getColumnModel().getColumn(5).setPreferredWidth(100);
        tableDaftar.getColumnModel().getColumn(6).setPreferredWidth(100);

        JTableHeader header = tableDaftar.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 13));
        header.setBackground(TABLE_HEADER);
        header.setForeground(Color.BLACK);
        header.setPreferredSize(new Dimension(0, 35));

        JScrollPane scrollPane = new JScrollPane(tableDaftar);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(0xE0E0E0)));
        scrollPane.getViewport().setBackground(Color.WHITE);

        // Bottom Panel
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        bottomPanel.setBackground(CONTENT_BG);
        bottomPanel.setBorder(new EmptyBorder(15, 0, 0, 0));
        lblTotalDaftar = new JLabel("Total Pendaftaran: 0");
        lblTotalDaftar.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblTotalDaftar.setForeground(SIDEBAR_BG);
        bottomPanel.add(lblTotalDaftar);

        // Layout Utama
        JPanel northPanel = new JPanel(new BorderLayout(0, 8));
        northPanel.setBackground(CONTENT_BG);
        northPanel.add(headerTitle, BorderLayout.NORTH);
        northPanel.add(filterPanel, BorderLayout.CENTER);
        northPanel.add(buttonPanel, BorderLayout.SOUTH);

        add(northPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);

        // Action Listeners
        btnTambah.addActionListener(e -> showInputDialog(false, null));
        btnFilter.addActionListener(e -> applyFilter());
        btnRefresh.addActionListener(e -> { resetFilter(); loadData(); });
        btnCetak.addActionListener(e -> cetakData());

        tableDaftar.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    int row = tableDaftar.getSelectedRow();
                    if (row >= 0) showInputDialog(true, row);
                }
            }
        });
    }

    private void loadComboData() {
        try {
            Statement st = conn.createStatement();
            
            // Load dokter untuk combo box
            cmbKdDokter = new JComboBox<>();
            ResultSet rs = st.executeQuery("SELECT kd_dokter, nama, spesialis FROM dokter ORDER BY kd_dokter");
            while (rs.next()) {
                cmbKdDokter.addItem(rs.getString("kd_dokter") + " - " + rs.getString("nama") + " (" + rs.getString("spesialis") + ")");
            }
            rs.close();
            st.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading combo data: " + e.getMessage());
        }
    }

    private void createInputDialog() {
        inputDialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(this), "Input Pendaftaran", true);
        inputDialog.setSize(550, 520);
        inputDialog.setLocationRelativeTo(this);
        inputDialog.setResizable(true);

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(new EmptyBorder(25, 30, 25, 30));
        formPanel.setBackground(Color.WHITE);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 15, 10, 15);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // ID Daftar
        gbc.gridy = 0;
        gbc.gridx = 0; gbc.weightx = 0;
        JLabel lblId = new JLabel("ID Daftar");
        lblId.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblId.setForeground(SIDEBAR_BG);
        formPanel.add(lblId, gbc);
        gbc.gridx = 1; gbc.weightx = 1.0;
        txtIdDaftar = new JTextField(20);
        txtIdDaftar.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        txtIdDaftar.setEditable(false);
        txtIdDaftar.setBackground(new Color(0xF5F5F5));
        formPanel.add(txtIdDaftar, gbc);

        // No Ruangan (Input Manual)
        gbc.gridy = 1;
        gbc.gridx = 0; gbc.weightx = 0;
        JLabel lblNoRuangan = new JLabel("No Ruangan");
        lblNoRuangan.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblNoRuangan.setForeground(SIDEBAR_BG);
        formPanel.add(lblNoRuangan, gbc);
        gbc.gridx = 1; gbc.weightx = 1.0;
        txtNoRuangan = new JTextField(20);
        txtNoRuangan.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        txtNoRuangan.setToolTipText("Contoh: R001, R002, dst");
        formPanel.add(txtNoRuangan, gbc);

        // Nama Pasien (Input Manual)
        gbc.gridy = 2;
        gbc.gridx = 0; gbc.weightx = 0;
        JLabel lblNamaPasien = new JLabel("Nama Pasien");
        lblNamaPasien.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblNamaPasien.setForeground(SIDEBAR_BG);
        formPanel.add(lblNamaPasien, gbc);
        gbc.gridx = 1; gbc.weightx = 1.0;
        txtNamaPasien = new JTextField(20);
        txtNamaPasien.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        txtNamaPasien.setToolTipText("Masukkan nama lengkap pasien");
        formPanel.add(txtNamaPasien, gbc);

        // Pilih Dokter (Dropdown)
        gbc.gridy = 3;
        gbc.gridx = 0; gbc.weightx = 0;
        JLabel lblDokter = new JLabel("Pilih Dokter");
        lblDokter.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblDokter.setForeground(SIDEBAR_BG);
        formPanel.add(lblDokter, gbc);
        gbc.gridx = 1; gbc.weightx = 1.0;
        formPanel.add(cmbKdDokter, gbc);

        // Tanggal Daftar
        gbc.gridy = 4;
        gbc.gridx = 0; gbc.weightx = 0;
        JLabel lblTgl = new JLabel("Tanggal Daftar");
        lblTgl.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblTgl.setForeground(SIDEBAR_BG);
        formPanel.add(lblTgl, gbc);
        gbc.gridx = 1; gbc.weightx = 1.0;
        txtTglDaftar = new JTextField(20);
        txtTglDaftar.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        txtTglDaftar.setText(java.time.LocalDate.now().toString());
        formPanel.add(txtTglDaftar, gbc);

        // Status
        gbc.gridy = 5;
        gbc.gridx = 0; gbc.weightx = 0;
        JLabel lblStatus = new JLabel("Status");
        lblStatus.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblStatus.setForeground(SIDEBAR_BG);
        formPanel.add(lblStatus, gbc);
        gbc.gridx = 1; gbc.weightx = 1.0;
        cmbStatus = new JComboBox<>(new String[]{"Menunggu", "Selesai"});
        cmbStatus.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        formPanel.add(cmbStatus, gbc);

        // Buttons
        gbc.gridy = 6; gbc.gridx = 0; gbc.gridwidth = 2; gbc.anchor = GridBagConstraints.CENTER;
        gbc.fill = GridBagConstraints.NONE;

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        JButton btnSimpan = new JButton("Simpan");
        JButton btnUbah = new JButton("Ubah");
        JButton btnHapus = new JButton("Hapus");
        JButton btnBatal = new JButton("Batal");

        btnSimpan.setBackground(BUTTON_GREEN);
        btnUbah.setBackground(new Color(0xFFC107));
        btnHapus.setBackground(new Color(0xDC3545));
        btnBatal.setBackground(new Color(0x6C757D));
        btnSimpan.setForeground(Color.WHITE);
        btnUbah.setForeground(Color.WHITE);
        btnHapus.setForeground(Color.WHITE);
        btnBatal.setForeground(Color.WHITE);
        btnSimpan.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnUbah.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnHapus.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnBatal.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnSimpan.setFocusPainted(false);
        btnUbah.setFocusPainted(false);
        btnHapus.setFocusPainted(false);
        btnBatal.setFocusPainted(false);
        btnSimpan.setPreferredSize(new Dimension(100, 38));
        btnUbah.setPreferredSize(new Dimension(100, 38));
        btnHapus.setPreferredSize(new Dimension(100, 38));
        btnBatal.setPreferredSize(new Dimension(100, 38));

        btnPanel.add(btnSimpan);
        btnPanel.add(btnUbah);
        btnPanel.add(btnHapus);
        btnPanel.add(btnBatal);
        formPanel.add(btnPanel, gbc);
        inputDialog.add(formPanel, BorderLayout.CENTER);

        btnSimpan.addActionListener(e -> { simpan(); inputDialog.dispose(); });
        btnUbah.addActionListener(e -> { ubah(); inputDialog.dispose(); });
        btnHapus.addActionListener(e -> {
            if (JOptionPane.showConfirmDialog(inputDialog, "Yakin hapus data ini?", "Konfirmasi", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
                hapus(); inputDialog.dispose();
            }
        });
        btnBatal.addActionListener(e -> inputDialog.dispose());
    }

    private void showInputDialog(boolean isEdit, Integer row) {
        clearDialogForm();
        if (isEdit && row != null) {
            txtIdDaftar.setText(tableModel.getValueAt(row, 0).toString());
            txtNoRuangan.setText(tableModel.getValueAt(row, 1).toString());
            txtNamaPasien.setText(tableModel.getValueAt(row, 2).toString());
            
            String kdDokter = tableModel.getValueAt(row, 3).toString();
            for (int i = 0; i < cmbKdDokter.getItemCount(); i++) {
                if (cmbKdDokter.getItemAt(i).startsWith(kdDokter)) {
                    cmbKdDokter.setSelectedIndex(i);
                    break;
                }
            }
            
            txtTglDaftar.setText(tableModel.getValueAt(row, 5).toString());
            String status = tableModel.getValueAt(row, 6).toString();
            if (status.equals("Menunggu")) cmbStatus.setSelectedIndex(0);
            else cmbStatus.setSelectedIndex(1);
            
            inputDialog.setTitle("Edit Pendaftaran");
        } else {
            generateIdDaftar();
            txtNoRuangan.setText("");
            txtNamaPasien.setText("");
            txtTglDaftar.setText(java.time.LocalDate.now().toString());
            cmbStatus.setSelectedIndex(0);
            inputDialog.setTitle("Tambah Pendaftaran");
        }
        inputDialog.setVisible(true);
    }

    private void loadData() { 
        loadDataWithFilter("", "", "Semua"); 
    }

    private void applyFilter() {
        String pasien = txtFilterPasien.getText().trim();
        String dokter = txtFilterDokter.getText().trim();
        String status = cmbFilterStatus.getSelectedItem().toString();
        loadDataWithFilter(pasien, dokter, status);
    }

    private void resetFilter() {
        txtFilterPasien.setText("");
        txtFilterDokter.setText("");
        cmbFilterStatus.setSelectedIndex(0);
        loadData();
    }

    private void loadDataWithFilter(String namaPasien, String namaDokter, String status) {
        tableModel.setRowCount(0);
        if (conn == null) return;

        StringBuilder sql = new StringBuilder(
            "SELECT d.id_daftar, d.no_ruangan, d.nama_pasien, " +
            "d.kd_dokter, dk.nama as nama_dokter, d.tgl_daftar, d.status " +
            "FROM daftar_berobat d " +
            "LEFT JOIN dokter dk ON d.kd_dokter = dk.kd_dokter WHERE 1=1"
        );
        ArrayList<Object> params = new ArrayList<>();

        if (!namaPasien.isEmpty()) { 
            sql.append(" AND d.nama_pasien LIKE ?"); 
            params.add("%" + namaPasien + "%"); 
        }
        if (!namaDokter.isEmpty()) { 
            sql.append(" AND dk.nama LIKE ?"); 
            params.add("%" + namaDokter + "%"); 
        }
        if (!status.equals("Semua")) { 
            sql.append(" AND d.status = ?"); 
            params.add(status); 
        }
        sql.append(" ORDER BY d.tgl_daftar DESC");

        try (PreparedStatement pst = conn.prepareStatement(sql.toString())) {
            for (int i = 0; i < params.size(); i++) {
                pst.setObject(i + 1, params.get(i));
            }
            ResultSet rs = pst.executeQuery();
            int count = 0;
            while (rs.next()) {
                tableModel.addRow(new Object[]{
                    rs.getString("id_daftar"),
                    rs.getString("no_ruangan"),
                    rs.getString("nama_pasien"),
                    rs.getString("kd_dokter"),
                    rs.getString("nama_dokter") != null ? rs.getString("nama_dokter") : "-",
                    rs.getString("tgl_daftar"),
                    rs.getString("status")
                });
                count++;
            }
            lblTotalDaftar.setText("Total Pendaftaran: " + count);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error load data: " + e.getMessage());
        }
    }

    private void generateIdDaftar() {
        try {
            String sql = "SELECT id_daftar FROM daftar_berobat ORDER BY id_daftar DESC LIMIT 1";
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            int newNumber = 1;
            if (rs.next()) {
                String last = rs.getString("id_daftar");
                if (last != null && last.length() > 2) {
                    newNumber = Integer.parseInt(last.substring(2)) + 1;
                }
            }
            txtIdDaftar.setText(String.format("DF%03d", newNumber));
            rs.close();
            st.close();
        } catch (Exception e) {
            txtIdDaftar.setText("DF001");
        }
    }

    private void simpan() {
    String id = txtIdDaftar.getText().trim();
    String noRuangan = txtNoRuangan.getText().trim();
    String namaPasien = txtNamaPasien.getText().trim();
    String kdDokter = cmbKdDokter.getSelectedItem().toString().split(" - ")[0];
    String tgl = txtTglDaftar.getText().trim();
    String status = cmbStatus.getSelectedItem().toString();

    if (id.isEmpty() || noRuangan.isEmpty() || namaPasien.isEmpty() || kdDokter.isEmpty() || tgl.isEmpty()) {
        JOptionPane.showMessageDialog(inputDialog, "Semua field harus diisi!");
        return;
    }

    try {
        // CEK APAKAH ID SUDAH ADA SEBELUM INSERT
        String cekSql = "SELECT COUNT(*) FROM daftar_berobat WHERE id_daftar = ?";
        PreparedStatement cekPst = conn.prepareStatement(cekSql);
        cekPst.setString(1, id);
        ResultSet rs = cekPst.executeQuery();
        rs.next();
        
        if (rs.getInt(1) > 0) {
            JOptionPane.showMessageDialog(inputDialog, "ID Daftar '" + id + "' sudah ada!\nSilakan refresh atau gunakan ID lain.");
            generateIdDaftar(); // Generate ID baru
            rs.close();
            cekPst.close();
            return;
        }
        rs.close();
        cekPst.close();
        
        // INSERT DATA BARU
        String sql = "INSERT INTO daftar_berobat (id_daftar, no_ruangan, nama_pasien, kd_dokter, tgl_daftar, status) VALUES (?, ?, ?, ?, ?, ?)";
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setString(1, id);
        pst.setString(2, noRuangan);
        pst.setString(3, namaPasien);
        pst.setString(4, kdDokter);
        pst.setString(5, tgl);
        pst.setString(6, status);
        pst.executeUpdate();
        pst.close();
        
        JOptionPane.showMessageDialog(inputDialog, "Data berhasil disimpan!");
        loadData();
        clearDialogForm();
        
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(inputDialog, "Error: " + e.getMessage());
        e.printStackTrace();
    }
}

    private void ubah() {
        String id = txtIdDaftar.getText().trim();
        if (id.isEmpty()) return;
        
        String noRuangan = txtNoRuangan.getText().trim();
        String namaPasien = txtNamaPasien.getText().trim();
        String kdDokter = cmbKdDokter.getSelectedItem().toString().split(" - ")[0];
        String tgl = txtTglDaftar.getText().trim();
        String status = cmbStatus.getSelectedItem().toString();

        try {
            String sql = "UPDATE daftar_berobat SET no_ruangan=?, nama_pasien=?, kd_dokter=?, tgl_daftar=?, status=? WHERE id_daftar=?";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, noRuangan);
            pst.setString(2, namaPasien);
            pst.setString(3, kdDokter);
            pst.setString(4, tgl);
            pst.setString(5, status);
            pst.setString(6, id);
            pst.executeUpdate();
            pst.close();
            JOptionPane.showMessageDialog(inputDialog, "Data berhasil diubah!");
            loadData();
            clearDialogForm();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(inputDialog, "Error: " + e.getMessage());
        }
    }

    private void hapus() {
        String id = txtIdDaftar.getText().trim();
        if (id.isEmpty()) return;
        
        try {
            String sql = "DELETE FROM daftar_berobat WHERE id_daftar=?";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, id);
            pst.executeUpdate();
            pst.close();
            JOptionPane.showMessageDialog(inputDialog, "Data berhasil dihapus!");
            loadData();
            clearDialogForm();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(inputDialog, "Error: " + e.getMessage());
        }
    }

    private void cetakData() {
        int rowCount = tableDaftar.getRowCount();
        if (rowCount == 0) {
            JOptionPane.showMessageDialog(this, "Tidak ada data untuk dicetak!");
            return;
        }
        
        StringBuilder sb = new StringBuilder();
        sb.append("=== DATA PENDAFTARAN BEROBAT ===\n");
        sb.append("========================================\n\n");
        sb.append("Dicetak: ").append(java.time.LocalDateTime.now().format(java.time.format.DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss"))).append("\n\n");
        
        for (int i = 0; i < rowCount; i++) {
            sb.append((i+1) + ". ");
            sb.append("ID Daftar: ").append(tableDaftar.getValueAt(i, 0)).append("\n");
            sb.append("   No Ruangan: ").append(tableDaftar.getValueAt(i, 1)).append("\n");
            sb.append("   Pasien: ").append(tableDaftar.getValueAt(i, 2)).append("\n");
            sb.append("   Dokter: ").append(tableDaftar.getValueAt(i, 4)).append("\n");
            sb.append("   Tanggal: ").append(tableDaftar.getValueAt(i, 5)).append("\n");
            sb.append("   Status: ").append(tableDaftar.getValueAt(i, 6)).append("\n");
            sb.append("----------------------------------------\n");
        }
        sb.append("\nTotal Pendaftaran: ").append(rowCount);
        
        JTextArea textArea = new JTextArea(sb.toString());
        textArea.setEditable(false);
        textArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(550, 450));
        JOptionPane.showMessageDialog(this, scrollPane, "Preview Cetak Pendaftaran", JOptionPane.INFORMATION_MESSAGE);
    }

    private void clearDialogForm() {
        txtIdDaftar.setText("");
        txtNoRuangan.setText("");
        txtNamaPasien.setText("");
        if (cmbKdDokter.getItemCount() > 0) {
            cmbKdDokter.setSelectedIndex(0);
        }
        txtTglDaftar.setText(java.time.LocalDate.now().toString());
        cmbStatus.setSelectedIndex(0);
    }
}