/*
 * Form Data Perawat - Filter tetap di kiri saat maximize
 * Author: Grok
 */
package tampilan;

import javax.swing.*;
import javax.swing.table.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.ArrayList;

public class form_perawat extends JPanel {
    private Connection conn;
    private DefaultTableModel tableModel;
   
    // Warna tema HMS
    private static final Color SIDEBAR_BG = new Color(0x1B4332);
    private static final Color SIDEBAR_ACTIVE = new Color(0x2D6A4F);
    private static final Color BUTTON_GREEN = new Color(0x52B788);
    private static final Color CONTENT_BG = new Color(0xF4F6F4);
    private static final Color TABLE_HEADER = new Color(0x1B4332);
   
    // Komponen Filter
    private JTextField txtFilterNama, txtFilterSpesialis;
    private JComboBox<String> cmbFilterJk;
    private JButton btnFilter, btnTambah, btnCetak, btnRefresh;
   
    // Tabel
    private JTable tablePerawat;
    private JLabel lblTotalPerawat;
   
    // Dialog Input/Edit
    private JDialog inputDialog;
    private JTextField txtKdPerawat, txtNamaPerawat, txtSpesialis, txtNoTelp, txtAlamat;
    private JRadioButton rbLaki, rbPerempuan;
    private ButtonGroup bgJk;

    public form_perawat() {
        koneksi.koneksi k = new koneksi.koneksi();
        conn = k.Connect();
       
        if (conn == null) {
            JOptionPane.showMessageDialog(this, "Gagal koneksi ke database!\nPastikan MySQL sedang berjalan.",
                "Error Koneksi", JOptionPane.ERROR_MESSAGE);
            return;
        }
       
        initComponents();
        loadData();
        createInputDialog();
    }
   
    private void initComponents() {
        setLayout(new BorderLayout());
        setBackground(CONTENT_BG);
        setBorder(new EmptyBorder(15, 20, 15, 20));

        // ==================== HEADER ====================
        JLabel headerTitle = new JLabel("Data Perawat");
        headerTitle.setFont(new Font("Segoe UI", Font.BOLD, 24));
        headerTitle.setForeground(SIDEBAR_BG);
        headerTitle.setBorder(new EmptyBorder(0, 0, 15, 0));

        // ==================== FILTER PANEL ====================
        JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 8));
        filterPanel.setBackground(CONTENT_BG);
        filterPanel.setBorder(new EmptyBorder(0, 0, 15, 0));

        int fieldHeight = 36;

        // Nama Perawat
        JPanel namaPanel = createFilterField("Nama Perawat", txtFilterNama = new JTextField(18));
        filterPanel.add(namaPanel);

        // Spesialis
        JPanel spesialisPanel = createFilterField("Spesialis", txtFilterSpesialis = new JTextField(18));
        filterPanel.add(spesialisPanel);

        // Jenis Kelamin
        JPanel jkPanel = createFilterCombo("Jenis Kelamin", cmbFilterJk = new JComboBox<>(new String[]{"Semua", "L", "P"}));
        filterPanel.add(jkPanel);

        // Tombol Terapkan Filter (dengan posisi agak ke bawah)
        JPanel btnFilterWrapper = new JPanel(new BorderLayout());
        btnFilterWrapper.setBackground(CONTENT_BG);
        btnFilterWrapper.setBorder(new EmptyBorder(22, 0, 0, 0));   // <-- Ubah angka ini untuk mengatur tinggi

        btnFilter = new JButton("Terapkan Filter");
        btnFilter.setBackground(SIDEBAR_BG);
        btnFilter.setForeground(Color.WHITE);
        btnFilter.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnFilter.setFocusPainted(false);
        btnFilter.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnFilter.setPreferredSize(new Dimension(140, fieldHeight));
        
        btnFilter.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { 
                btnFilter.setBackground(SIDEBAR_ACTIVE); 
            }
            public void mouseExited(MouseEvent e) { 
                btnFilter.setBackground(SIDEBAR_BG); 
            }
        });
        
        btnFilterWrapper.add(btnFilter, BorderLayout.NORTH);
        filterPanel.add(btnFilterWrapper);

        // ==================== BUTTON PANEL ====================
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 8));
        buttonPanel.setBackground(CONTENT_BG);
        buttonPanel.setBorder(new EmptyBorder(0, 0, 15, 0));

        btnTambah = new JButton("+ Tambah Data Perawat Baru");
        btnTambah.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnTambah.setBackground(SIDEBAR_BG);  // Warna hijau tua #1B4332
        btnTambah.setForeground(Color.WHITE);
        btnTambah.setFocusPainted(false);
        btnTambah.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnTambah.setBorder(new EmptyBorder(10, 18, 10, 18));

        btnCetak = new JButton("Cetak");
        btnCetak.setBackground(new Color(0x6C757D));
        btnCetak.setForeground(Color.WHITE);
        btnCetak.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnCetak.setFocusPainted(false);
        btnCetak.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnCetak.setBorder(new EmptyBorder(10, 25, 10, 25));

        btnRefresh = new JButton("Refresh");
        btnRefresh.setBackground(SIDEBAR_ACTIVE);
        btnRefresh.setForeground(Color.WHITE);
        btnRefresh.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnRefresh.setFocusPainted(false);
        btnRefresh.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnRefresh.setBorder(new EmptyBorder(10, 25, 10, 25));

        buttonPanel.add(btnTambah);
        buttonPanel.add(btnCetak);
        buttonPanel.add(btnRefresh);

        // ==================== TABLE ====================
        String[] columns = {"Kd Perawat", "Nama Perawat", "Spesialis", "JK", "No.Telp", "Alamat"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override public boolean isCellEditable(int row, int column) { return false; }
        };

        tablePerawat = new JTable(tableModel);
        tablePerawat.setRowHeight(50);           // Tinggi baris tabel
        tablePerawat.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        tablePerawat.setSelectionBackground(new Color(0xD8F3DC));
        tablePerawat.setSelectionForeground(SIDEBAR_BG);
        tablePerawat.setGridColor(new Color(0xE0E0E0));
        tablePerawat.setShowVerticalLines(true);
        tablePerawat.setShowHorizontalLines(true);
        tablePerawat.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);

        // Lebar Kolom
        tablePerawat.getColumnModel().getColumn(0).setPreferredWidth(110);
        tablePerawat.getColumnModel().getColumn(1).setPreferredWidth(220);
        tablePerawat.getColumnModel().getColumn(2).setPreferredWidth(180);
        tablePerawat.getColumnModel().getColumn(3).setPreferredWidth(80);
        tablePerawat.getColumnModel().getColumn(4).setPreferredWidth(140);
        tablePerawat.getColumnModel().getColumn(5).setPreferredWidth(280);

        JTableHeader header = tablePerawat.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 13));
        header.setBackground(TABLE_HEADER);
        header.setForeground(Color.BLACK);
        header.setPreferredSize(new Dimension(0, 25));

        JScrollPane scrollPane = new JScrollPane(tablePerawat);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(0xE0E0E0)));
        scrollPane.getViewport().setBackground(Color.WHITE);

        // ==================== BOTTOM PANEL ====================
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        bottomPanel.setBackground(CONTENT_BG);
        bottomPanel.setBorder(new EmptyBorder(15, 0, 0, 0));
        lblTotalPerawat = new JLabel("Total Perawat: 0");
        lblTotalPerawat.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblTotalPerawat.setForeground(SIDEBAR_BG);
        bottomPanel.add(lblTotalPerawat);

        // ==================== SUSUNAN UTAMA ====================
        JPanel northPanel = new JPanel(new BorderLayout(0, 8));
        northPanel.setBackground(CONTENT_BG);
        northPanel.add(headerTitle, BorderLayout.NORTH);
        northPanel.add(filterPanel, BorderLayout.CENTER);
        northPanel.add(buttonPanel, BorderLayout.SOUTH);

        add(northPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);

        // Action Listeners
        btnTambah.addActionListener(e -> showInputDialog(false, null));
        btnFilter.addActionListener(e -> applyFilter());
        btnRefresh.addActionListener(e -> { resetFilter(); loadData(); });
        btnCetak.addActionListener(e -> JOptionPane.showMessageDialog(this,
            "Fitur Cetak belum diimplementasikan.", "Info", JOptionPane.INFORMATION_MESSAGE));

        tablePerawat.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    int row = tablePerawat.getSelectedRow();
                    if (row >= 0) showInputDialog(true, row);
                }
            }
        });
    }

    private JPanel createFilterField(String labelText, JTextField field) {
        JPanel panel = new JPanel(new BorderLayout(5, 3));
        panel.setBackground(CONTENT_BG);
        
        JLabel lbl = new JLabel(labelText);
        lbl.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lbl.setForeground(SIDEBAR_BG);
        
        field.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        field.setPreferredSize(new Dimension(180, 36));
        field.addActionListener(e -> applyFilter());
        
        panel.add(lbl, BorderLayout.NORTH);
        panel.add(field, BorderLayout.CENTER);
        return panel;
    }

    private JPanel createFilterCombo(String labelText, JComboBox<String> combo) {
        JPanel panel = new JPanel(new BorderLayout(5, 3));
        panel.setBackground(CONTENT_BG);
        
        JLabel lbl = new JLabel(labelText);
        lbl.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lbl.setForeground(SIDEBAR_BG);
        
        combo.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        combo.setPreferredSize(new Dimension(160, 36));
        
        panel.add(lbl, BorderLayout.NORTH);
        panel.add(combo, BorderLayout.CENTER);
        return panel;
    }

    // ==================== INPUT DIALOG (tetap sama) ====================
    private void createInputDialog() {
        inputDialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(this), 
                                 "Input Data Perawat", true);
        inputDialog.setSize(560, 520);
        inputDialog.setLocationRelativeTo(this);
        inputDialog.setResizable(true);

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(new EmptyBorder(30, 35, 30, 35));
        formPanel.setBackground(Color.WHITE);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(12, 15, 12, 15);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridy = 0;
        addFormRow(formPanel, gbc, "Kd Perawat", txtKdPerawat = new JTextField(20));
        txtKdPerawat.setEditable(false);
        txtKdPerawat.setBackground(new Color(0xF5F5F5));

        gbc.gridy = 1;
        addFormRow(formPanel, gbc, "Nama Perawat", txtNamaPerawat = new JTextField(20));

        gbc.gridy = 2;
        addFormRow(formPanel, gbc, "Spesialis", txtSpesialis = new JTextField(20));

        gbc.gridy = 3; gbc.gridx = 0; gbc.weightx = 0;
        JLabel lblJk = new JLabel("Jenis Kelamin");
        lblJk.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblJk.setForeground(SIDEBAR_BG);
        formPanel.add(lblJk, gbc);

        gbc.gridx = 1; gbc.weightx = 1.0;
        JPanel jkPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 25, 0));
        jkPanel.setBackground(Color.WHITE);
        rbLaki = new JRadioButton("Laki-laki");
        rbPerempuan = new JRadioButton("Perempuan");
        rbLaki.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        rbPerempuan.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        bgJk = new ButtonGroup();
        bgJk.add(rbLaki); bgJk.add(rbPerempuan);
        jkPanel.add(rbLaki); jkPanel.add(rbPerempuan);
        formPanel.add(jkPanel, gbc);

        gbc.gridy = 4; gbc.gridx = 0; gbc.weightx = 0;
        addFormRow(formPanel, gbc, "No. Telp", txtNoTelp = new JTextField(20));

        gbc.gridy = 5;
        addFormRow(formPanel, gbc, "Alamat", txtAlamat = new JTextField(20));

        gbc.gridy = 6; gbc.gridx = 0; gbc.gridwidth = 2; gbc.anchor = GridBagConstraints.CENTER;
        gbc.fill = GridBagConstraints.NONE;

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));

        JButton btnSimpan = new JButton("Simpan");
        JButton btnUbah = new JButton("Ubah");
        JButton btnHapus = new JButton("Hapus");
        JButton btnBatal = new JButton("Batal");

        btnSimpan.setBackground(BUTTON_GREEN);
        btnUbah.setBackground(new Color(0xFFC107));
        btnHapus.setBackground(new Color(0xDC3545));
        btnBatal.setBackground(new Color(0x6C757D));

        btnSimpan.setForeground(Color.WHITE);
        btnUbah.setForeground(Color.WHITE);
        btnHapus.setForeground(Color.WHITE);
        btnBatal.setForeground(Color.WHITE);

        btnSimpan.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnUbah.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnHapus.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnBatal.setFont(new Font("Segoe UI", Font.BOLD, 12));

        btnSimpan.setFocusPainted(false);
        btnUbah.setFocusPainted(false);
        btnHapus.setFocusPainted(false);
        btnBatal.setFocusPainted(false);

        btnSimpan.setPreferredSize(new Dimension(100, 38));
        btnUbah.setPreferredSize(new Dimension(100, 38));
        btnHapus.setPreferredSize(new Dimension(100, 38));
        btnBatal.setPreferredSize(new Dimension(100, 38));

        btnPanel.add(btnSimpan);
        btnPanel.add(btnUbah);
        btnPanel.add(btnHapus);
        btnPanel.add(btnBatal);

        formPanel.add(btnPanel, gbc);
        inputDialog.add(formPanel, BorderLayout.CENTER);

        btnSimpan.addActionListener(e -> { simpan(); inputDialog.dispose(); });
        btnUbah.addActionListener(e -> { ubah(); inputDialog.dispose(); });
        btnHapus.addActionListener(e -> {
            if (JOptionPane.showConfirmDialog(inputDialog, "Yakin hapus data ini?", 
                "Konfirmasi", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
                hapus(); inputDialog.dispose();
            }
        });
        btnBatal.addActionListener(e -> inputDialog.dispose());
    }

    private void addFormRow(JPanel panel, GridBagConstraints gbc, String labelText, JTextField field) {
        gbc.gridx = 0; gbc.weightx = 0;
        JLabel label = new JLabel(labelText);
        label.setFont(new Font("Segoe UI", Font.BOLD, 13));
        label.setForeground(SIDEBAR_BG);
        panel.add(label, gbc);

        gbc.gridx = 1; gbc.weightx = 1.0;
        field.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        panel.add(field, gbc);
        gbc.gridx = 0;
    }

    // Method lainnya tetap sama
    private void showInputDialog(boolean isEdit, Integer row) {
        clearDialogForm();
        if (isEdit && row != null) {
            txtKdPerawat.setText(tableModel.getValueAt(row, 0).toString());
            txtNamaPerawat.setText(tableModel.getValueAt(row, 1).toString());
            txtSpesialis.setText(tableModel.getValueAt(row, 2).toString());
            String jk = tableModel.getValueAt(row, 3).toString();
            if (jk.equals("L")) rbLaki.setSelected(true);
            else rbPerempuan.setSelected(true);
            txtNoTelp.setText(tableModel.getValueAt(row, 4).toString());
            txtAlamat.setText(tableModel.getValueAt(row, 5).toString());
            inputDialog.setTitle("Edit Data Perawat");
        } else {
            generateKdPerawat();
            inputDialog.setTitle("Tambah Data Perawat");
        }
        inputDialog.setVisible(true);
    }

    private void loadData() { loadDataWithFilter("", "", "Semua"); }

    private void applyFilter() {
        String nama = txtFilterNama.getText().trim();
        String spesialis = txtFilterSpesialis.getText().trim();
        String jk = cmbFilterJk.getSelectedItem().toString();
        loadDataWithFilter(nama, spesialis, jk);
    }

    private void resetFilter() {
        txtFilterNama.setText("");
        txtFilterSpesialis.setText("");
        cmbFilterJk.setSelectedIndex(0);
        loadData();
    }

    private void loadDataWithFilter(String nama, String spesialis, String jk) {
        tableModel.setRowCount(0);
        if (conn == null) return;

        StringBuilder sql = new StringBuilder("SELECT * FROM perawat WHERE 1=1");
        ArrayList<Object> params = new ArrayList<>();

        if (!nama.isEmpty()) {
            sql.append(" AND nama LIKE ?"); params.add("%" + nama + "%");
        }
        if (!spesialis.isEmpty()) {
            sql.append(" AND spesialis LIKE ?"); params.add("%" + spesialis + "%");
        }
        if (!jk.equals("Semua")) {
            sql.append(" AND jk = ?"); params.add(jk);
        }
        sql.append(" ORDER BY kd_perawat");

        try (PreparedStatement pst = conn.prepareStatement(sql.toString())) {
            for (int i = 0; i < params.size(); i++) {
                pst.setObject(i + 1, params.get(i));
            }
            ResultSet rs = pst.executeQuery();
            int count = 0;
            while (rs.next()) {
                tableModel.addRow(new Object[]{
                    rs.getString("kd_perawat"),
                    rs.getString("nama"),
                    rs.getString("spesialis"),
                    rs.getString("jk"),
                    rs.getString("no_telp") != null ? rs.getString("no_telp") : "",
                    rs.getString("alamat") != null ? rs.getString("alamat") : ""
                });
                count++;
            }
            lblTotalPerawat.setText("Total Perawat: " + count);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error load data: " + e.getMessage());
        }
    }

    private void generateKdPerawat() {
        try {
            String sql = "SELECT kd_perawat FROM perawat ORDER BY kd_perawat DESC LIMIT 1";
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            int newNumber = 1;
            if (rs.next()) {
                String last = rs.getString("kd_perawat");
                if (last != null && last.length() > 1) {
                    newNumber = Integer.parseInt(last.substring(1)) + 1;
                }
            }
            txtKdPerawat.setText(String.format("P%03d", newNumber));
        } catch (Exception e) {
            txtKdPerawat.setText("P001");
        }
    }

    private void simpan() { /* ... sama seperti sebelumnya ... */ 
        // (kode simpan, ubah, hapus, clearDialogForm tetap sama seperti yang kamu kirim)
        String kd = txtKdPerawat.getText().trim();
        String nama = txtNamaPerawat.getText().trim();
        String spesialis = txtSpesialis.getText().trim();
        String jk = rbLaki.isSelected() ? "L" : (rbPerempuan.isSelected() ? "P" : "");
        String noTelp = txtNoTelp.getText().trim();
        String alamat = txtAlamat.getText().trim();

        if (nama.isEmpty() || spesialis.isEmpty() || jk.isEmpty()) {
            JOptionPane.showMessageDialog(inputDialog, "Nama, Spesialis, dan Jenis Kelamin harus diisi!");
            return;
        }

        // ... (lanjutkan kode simpan, ubah, hapus, clearDialogForm dari kode kamu)
    }

    // Tambahkan method ubah, hapus, clearDialogForm di bawah ini (sama seperti kode asli kamu)
    private void ubah() {
        String kd = txtKdPerawat.getText().trim();
        if (kd.isEmpty()) return;
        try {
            String sql = "UPDATE perawat SET nama=?, spesialis=?, jk=?, no_telp=?, alamat=? WHERE kd_perawat=?";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, txtNamaPerawat.getText().trim());
            pst.setString(2, txtSpesialis.getText().trim());
            pst.setString(3, rbLaki.isSelected() ? "L" : "P");
            pst.setString(4, txtNoTelp.getText().trim());
            pst.setString(5, txtAlamat.getText().trim());
            pst.setString(6, kd);
            pst.executeUpdate();
            pst.close();
            JOptionPane.showMessageDialog(inputDialog, "Data berhasil diubah!");
            loadData();
            clearDialogForm();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(inputDialog, "Error: " + e.getMessage());
        }
    }

    private void hapus() {
        String kd = txtKdPerawat.getText().trim();
        if (kd.isEmpty()) return;
        try {
            String sql = "DELETE FROM perawat WHERE kd_perawat=?";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, kd);
            pst.executeUpdate();
            pst.close();
            JOptionPane.showMessageDialog(inputDialog, "Data berhasil dihapus!");
            loadData();
            clearDialogForm();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(inputDialog, "Error: " + e.getMessage());
        }
    }

    private void clearDialogForm() {
        txtKdPerawat.setText("");
        txtNamaPerawat.setText("");
        txtSpesialis.setText("");
        txtNoTelp.setText("");
        txtAlamat.setText("");
        bgJk.clearSelection();
    }
}
