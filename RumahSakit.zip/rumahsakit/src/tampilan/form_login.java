/*
 * Form Login - Hospital Management System
 * Dengan teks di tengah (center alignment)
 */
package tampilan;

import javax.swing.*;
import java.awt.*;
import java.sql.*;
import koneksi.koneksi;

public class form_login extends JPanel {
    private Connection conn;
    
    private JTextField txtUsername;
    private JPasswordField txtPassword;
    private JButton btnLogin;
    
    public form_login() {
        // Koneksi database
        try {
            koneksi k = new koneksi();
            conn = k.Connect();
            
            if (conn == null) {
                JOptionPane.showMessageDialog(this, 
                    "Gagal koneksi ke database!\nPastikan MySQL sedang berjalan.", 
                    "Error Koneksi", 
                    JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception e) {
            System.out.println("Error koneksi: " + e.getMessage());
            e.printStackTrace();
        }
        
        initComponents();
    }
    
    private void initComponents() {
        setLayout(new GridBagLayout());
        setBackground(new Color(0xF4F6F4));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        
        // Panel form login
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new BoxLayout(formPanel, BoxLayout.Y_AXIS));
        formPanel.setBackground(Color.WHITE);
        formPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(0xE0E0E0), 1),
            BorderFactory.createEmptyBorder(40, 50, 40, 50)
        ));
        formPanel.setMaximumSize(new Dimension(400, 350));
        formPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        // Title - DITENGAH
        JLabel lblTitle = new JLabel("HOSPITAL MANAGEMENT SYSTEM", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblTitle.setForeground(new Color(0x1B4332));
        lblTitle.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        JLabel lblSubTitle = new JLabel("Form Login", SwingConstants.CENTER);
        lblSubTitle.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblSubTitle.setForeground(new Color(0x666666));
        lblSubTitle.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        // Username Label - DITENGAH
        JLabel lblUsername = new JLabel("Username");
        lblUsername.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        lblUsername.setForeground(new Color(0x1B4332));
        lblUsername.setAlignmentX(Component.CENTER_ALIGNMENT);  // <-- CENTER
        
        txtUsername = new JTextField();
        txtUsername.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtUsername.setPreferredSize(new Dimension(280, 35));
        txtUsername.setMaximumSize(new Dimension(280, 35));
        txtUsername.setHorizontalAlignment(JTextField.CENTER);  // <-- CENTER
        
        // Password Label - DITENGAH
        JLabel lblPassword = new JLabel("Password");
        lblPassword.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        lblPassword.setForeground(new Color(0x1B4332));
        lblPassword.setAlignmentX(Component.CENTER_ALIGNMENT);  // <-- CENTER
        
        txtPassword = new JPasswordField();
        txtPassword.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtPassword.setPreferredSize(new Dimension(280, 35));
        txtPassword.setMaximumSize(new Dimension(280, 35));
        txtPassword.setHorizontalAlignment(JTextField.CENTER);  // <-- CENTER
        
        // Login Button - DITENGAH
        btnLogin = new JButton("LOGIN");
        btnLogin.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnLogin.setBackground(new Color(0x1B4332));
        btnLogin.setForeground(Color.WHITE);
        btnLogin.setFocusPainted(false);
        btnLogin.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnLogin.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnLogin.setMaximumSize(new Dimension(280, 40));
        btnLogin.addActionListener(e -> doLogin());
        
        // Enter key untuk login
        txtPassword.addActionListener(e -> doLogin());
        
        // Susun komponen (semua sudah center alignment)
        formPanel.add(Box.createVerticalStrut(10));
        formPanel.add(lblTitle);
        formPanel.add(Box.createVerticalStrut(5));
        formPanel.add(lblSubTitle);
        formPanel.add(Box.createVerticalStrut(30));
        formPanel.add(lblUsername);
        formPanel.add(Box.createVerticalStrut(5));
        formPanel.add(txtUsername);
        formPanel.add(Box.createVerticalStrut(15));
        formPanel.add(lblPassword);
        formPanel.add(Box.createVerticalStrut(5));
        formPanel.add(txtPassword);
        formPanel.add(Box.createVerticalStrut(25));
        formPanel.add(btnLogin);
        formPanel.add(Box.createVerticalStrut(10));
        
        // Tambahkan ke panel utama (center)
        gbc.gridx = 0;
        gbc.gridy = 0;
        add(formPanel, gbc);
    }
    
    private void doLogin() {
        String username = txtUsername.getText().trim();
        String password = new String(txtPassword.getPassword()).trim();
        
        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "Username dan Password harus diisi!", 
                "Peringatan", 
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        if (conn == null) {
            JOptionPane.showMessageDialog(this, 
                "Koneksi database gagal!\nPastikan MySQL berjalan dan database 'rumahsakit' sudah dibuat.", 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        try {
            String sql = "SELECT * FROM administrator WHERE id_admin = ? AND password = ?";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, username);
            pst.setString(2, password);
            
            ResultSet rs = pst.executeQuery();
            
            if (rs.next()) {
                JOptionPane.showMessageDialog(this, 
                    "Login berhasil! Selamat datang, " + username, 
                    "Sukses", 
                    JOptionPane.INFORMATION_MESSAGE);
                
                // Buka menu utama
                menuutama menu = new menuutama();
                menu.setVisible(true);
                
                // Tutup window login
                Window window = SwingUtilities.getWindowAncestor(this);
                if (window != null) {
                    window.dispose();
                }
            } else {
                JOptionPane.showMessageDialog(this, 
                    "Login gagal! Username atau password salah.\n\nGunakan:\nUsername: admin\nPassword: admin123", 
                    "Login Gagal", 
                    JOptionPane.ERROR_MESSAGE);
                txtPassword.setText("");
                txtUsername.requestFocus();
            }
            
            rs.close();
            pst.close();
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, 
                "Error database: " + e.getMessage(), 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }
    
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        JFrame frame = new JFrame("Login - Hospital Management System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(550, 520);
        frame.setLocationRelativeTo(null);
        frame.setContentPane(new form_login());
        frame.setVisible(true);
    }
}