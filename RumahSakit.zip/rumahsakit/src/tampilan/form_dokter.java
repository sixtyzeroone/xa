/*
 * Form Data Dokter - Dengan Nama Dokter, Spesialis, Alamat, No Telp, Jadwal Praktek
 */
package tampilan;

import javax.swing.*;
import javax.swing.table.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.ArrayList;

public class form_dokter extends JPanel {
    private Connection conn;
    private DefaultTableModel tableModel;
    
    private static final Color SIDEBAR_BG = new Color(0x1B4332);
    private static final Color SIDEBAR_ACTIVE = new Color(0x2D6A4F);
    private static final Color BUTTON_GREEN = new Color(0x52B788);
    private static final Color CONTENT_BG = new Color(0xF4F6F4);
    private static final Color TABLE_HEADER = new Color(0x1B4332);
    
    private JTextField txtFilterNama, txtFilterSpesialis;
    private JButton btnFilter, btnTambah, btnCetak, btnRefresh;
    private JTable tableDokter;
    private JLabel lblTotalDokter;
    
    private JDialog inputDialog;
    private JTextField txtKdDokter, txtNamaDokter, txtSpesialis, txtAlamat, txtNoTelp, txtJadwal;
    private JRadioButton rbLaki, rbPerempuan;
    private ButtonGroup bgJk;
    
    public form_dokter() {
        koneksi.koneksi k = new koneksi.koneksi();
        conn = k.Connect();
        
        if (conn == null) {
            JOptionPane.showMessageDialog(this, "Gagal koneksi ke database!");
            return;
        }
        
        initComponents();
        loadData();
        createInputDialog();
    }
    
    private void initComponents() {
        setLayout(new BorderLayout());
        setBackground(CONTENT_BG);
        setBorder(new EmptyBorder(15, 20, 15, 20));

        JLabel headerTitle = new JLabel("Data Dokter");
        headerTitle.setFont(new Font("Segoe UI", Font.BOLD, 24));
        headerTitle.setForeground(SIDEBAR_BG);
        headerTitle.setBorder(new EmptyBorder(0, 0, 15, 0));

        // Filter Panel
        JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 8));
        filterPanel.setBackground(CONTENT_BG);
        filterPanel.setBorder(new EmptyBorder(0, 0, 15, 0));

        int fieldHeight = 36;

        // Filter Nama
        JPanel namaPanel = createFilterField("Nama Dokter", txtFilterNama = new JTextField(18));
        filterPanel.add(namaPanel);

        // Filter Spesialis
        JPanel spesialisPanel = createFilterField("Spesialis", txtFilterSpesialis = new JTextField(18));
        filterPanel.add(spesialisPanel);

        // Tombol Filter
        JPanel btnFilterWrapper = new JPanel(new BorderLayout());
        btnFilterWrapper.setBackground(CONTENT_BG);
        btnFilterWrapper.setBorder(new EmptyBorder(22, 0, 0, 0));

        btnFilter = new JButton("Terapkan Filter");
        btnFilter.setBackground(SIDEBAR_BG);
        btnFilter.setForeground(Color.WHITE);
        btnFilter.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnFilter.setFocusPainted(false);
        btnFilter.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnFilter.setPreferredSize(new Dimension(140, fieldHeight));
        btnFilter.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { btnFilter.setBackground(SIDEBAR_ACTIVE); }
            public void mouseExited(MouseEvent e) { btnFilter.setBackground(SIDEBAR_BG); }
        });
        btnFilterWrapper.add(btnFilter, BorderLayout.NORTH);
        filterPanel.add(btnFilterWrapper);

        // Button Panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 8));
        buttonPanel.setBackground(CONTENT_BG);
        buttonPanel.setBorder(new EmptyBorder(0, 0, 15, 0));

        btnTambah = new JButton("+ Tambah Data Dokter Baru");
        btnTambah.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnTambah.setBackground(SIDEBAR_BG);
        btnTambah.setForeground(Color.WHITE);
        btnTambah.setFocusPainted(false);
        btnTambah.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnTambah.setBorder(new EmptyBorder(10, 18, 10, 18));

        btnCetak = new JButton("🖨️ Cetak");
        btnCetak.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnCetak.setBackground(new Color(0x6C757D));
        btnCetak.setForeground(Color.WHITE);
        btnCetak.setFocusPainted(false);
        btnCetak.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnCetak.setBorder(new EmptyBorder(10, 25, 10, 25));

        btnRefresh = new JButton("⟳ Refresh");
        btnRefresh.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnRefresh.setBackground(SIDEBAR_ACTIVE);
        btnRefresh.setForeground(Color.WHITE);
        btnRefresh.setFocusPainted(false);
        btnRefresh.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnRefresh.setBorder(new EmptyBorder(10, 25, 10, 25));

        buttonPanel.add(btnTambah);
        buttonPanel.add(btnCetak);
        buttonPanel.add(btnRefresh);

        // Table
        String[] columns = {"Kd Dokter", "Nama Dokter", "Spesialis", "JK", "Alamat", "No Telp", "Jadwal"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override public boolean isCellEditable(int row, int column) { return false; }
        };

        tableDokter = new JTable(tableModel);
        tableDokter.setRowHeight(50);
        tableDokter.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        tableDokter.setSelectionBackground(new Color(0xD8F3DC));
        tableDokter.setSelectionForeground(SIDEBAR_BG);
        tableDokter.setGridColor(new Color(0xE0E0E0));
        tableDokter.setShowVerticalLines(true);
        tableDokter.setShowHorizontalLines(true);
        tableDokter.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);

        tableDokter.getColumnModel().getColumn(0).setPreferredWidth(100);
        tableDokter.getColumnModel().getColumn(1).setPreferredWidth(180);
        tableDokter.getColumnModel().getColumn(2).setPreferredWidth(150);
        tableDokter.getColumnModel().getColumn(3).setPreferredWidth(60);
        tableDokter.getColumnModel().getColumn(4).setPreferredWidth(200);
        tableDokter.getColumnModel().getColumn(5).setPreferredWidth(120);
        tableDokter.getColumnModel().getColumn(6).setPreferredWidth(120);

        JTableHeader header = tableDokter.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 13));
        header.setBackground(TABLE_HEADER);
        header.setForeground(Color.BLACK);
        header.setPreferredSize(new Dimension(0, 35));

        JScrollPane scrollPane = new JScrollPane(tableDokter);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(0xE0E0E0)));
        scrollPane.getViewport().setBackground(Color.WHITE);

        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        bottomPanel.setBackground(CONTENT_BG);
        bottomPanel.setBorder(new EmptyBorder(15, 0, 0, 0));
        lblTotalDokter = new JLabel("Total Dokter: 0");
        lblTotalDokter.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblTotalDokter.setForeground(SIDEBAR_BG);
        bottomPanel.add(lblTotalDokter);

        JPanel northPanel = new JPanel(new BorderLayout(0, 8));
        northPanel.setBackground(CONTENT_BG);
        northPanel.add(headerTitle, BorderLayout.NORTH);
        northPanel.add(filterPanel, BorderLayout.CENTER);
        northPanel.add(buttonPanel, BorderLayout.SOUTH);

        add(northPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);

        btnTambah.addActionListener(e -> showInputDialog(false, null));
        btnFilter.addActionListener(e -> applyFilter());
        btnRefresh.addActionListener(e -> { resetFilter(); loadData(); });
        btnCetak.addActionListener(e -> cetakData());

        tableDokter.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    int row = tableDokter.getSelectedRow();
                    if (row >= 0) showInputDialog(true, row);
                }
            }
        });
    }

    private JPanel createFilterField(String labelText, JTextField field) {
        JPanel panel = new JPanel(new BorderLayout(5, 3));
        panel.setBackground(CONTENT_BG);
        JLabel lbl = new JLabel(labelText);
        lbl.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lbl.setForeground(SIDEBAR_BG);
        field.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        field.setPreferredSize(new Dimension(180, 36));
        field.addActionListener(e -> applyFilter());
        panel.add(lbl, BorderLayout.NORTH);
        panel.add(field, BorderLayout.CENTER);
        return panel;
    }

    private void createInputDialog() {
        inputDialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(this), "Input Data Dokter", true);
        inputDialog.setSize(600, 580);
        inputDialog.setLocationRelativeTo(this);
        inputDialog.setResizable(true);

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(new EmptyBorder(25, 30, 25, 30));
        formPanel.setBackground(Color.WHITE);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 15, 10, 15);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Kd Dokter
        gbc.gridy = 0;
        gbc.gridx = 0; gbc.weightx = 0;
        JLabel lblKd = new JLabel("Kd Dokter");
        lblKd.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblKd.setForeground(SIDEBAR_BG);
        formPanel.add(lblKd, gbc);
        gbc.gridx = 1; gbc.weightx = 1.0;
        txtKdDokter = new JTextField(20);
        txtKdDokter.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        txtKdDokter.setEditable(false);
        txtKdDokter.setBackground(new Color(0xF5F5F5));
        formPanel.add(txtKdDokter, gbc);

        // Nama Dokter
        gbc.gridy = 1;
        gbc.gridx = 0; gbc.weightx = 0;
        JLabel lblNama = new JLabel("Nama Dokter");
        lblNama.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblNama.setForeground(SIDEBAR_BG);
        formPanel.add(lblNama, gbc);
        gbc.gridx = 1; gbc.weightx = 1.0;
        txtNamaDokter = new JTextField(20);
        txtNamaDokter.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        formPanel.add(txtNamaDokter, gbc);

        // Spesialis
        gbc.gridy = 2;
        gbc.gridx = 0; gbc.weightx = 0;
        JLabel lblSpesialis = new JLabel("Spesialis");
        lblSpesialis.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblSpesialis.setForeground(SIDEBAR_BG);
        formPanel.add(lblSpesialis, gbc);
        gbc.gridx = 1; gbc.weightx = 1.0;
        txtSpesialis = new JTextField(20);
        txtSpesialis.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        formPanel.add(txtSpesialis, gbc);

        // Jenis Kelamin
        gbc.gridy = 3;
        gbc.gridx = 0; gbc.weightx = 0;
        JLabel lblJk = new JLabel("Jenis Kelamin");
        lblJk.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblJk.setForeground(SIDEBAR_BG);
        formPanel.add(lblJk, gbc);
        gbc.gridx = 1; gbc.weightx = 1.0;
        JPanel jkPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 25, 0));
        jkPanel.setBackground(Color.WHITE);
        rbLaki = new JRadioButton("Laki-laki");
        rbPerempuan = new JRadioButton("Perempuan");
        rbLaki.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        rbPerempuan.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        bgJk = new ButtonGroup();
        bgJk.add(rbLaki); bgJk.add(rbPerempuan);
        jkPanel.add(rbLaki); jkPanel.add(rbPerempuan);
        formPanel.add(jkPanel, gbc);

        // Alamat
        gbc.gridy = 4;
        gbc.gridx = 0; gbc.weightx = 0;
        JLabel lblAlamat = new JLabel("Alamat");
        lblAlamat.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblAlamat.setForeground(SIDEBAR_BG);
        formPanel.add(lblAlamat, gbc);
        gbc.gridx = 1; gbc.weightx = 1.0;
        txtAlamat = new JTextField(20);
        txtAlamat.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        formPanel.add(txtAlamat, gbc);

        // No Telp
        gbc.gridy = 5;
        gbc.gridx = 0; gbc.weightx = 0;
        JLabel lblTelp = new JLabel("No. Telp");
        lblTelp.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblTelp.setForeground(SIDEBAR_BG);
        formPanel.add(lblTelp, gbc);
        gbc.gridx = 1; gbc.weightx = 1.0;
        txtNoTelp = new JTextField(20);
        txtNoTelp.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        formPanel.add(txtNoTelp, gbc);

        // Jadwal Praktek
        gbc.gridy = 6;
        gbc.gridx = 0; gbc.weightx = 0;
        JLabel lblJadwal = new JLabel("Jadwal Praktek");
        lblJadwal.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblJadwal.setForeground(SIDEBAR_BG);
        formPanel.add(lblJadwal, gbc);
        gbc.gridx = 1; gbc.weightx = 1.0;
        txtJadwal = new JTextField(20);
        txtJadwal.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        txtJadwal.setToolTipText("Contoh: Senin-Kamis 08:00-12:00");
        formPanel.add(txtJadwal, gbc);

        // Buttons
        gbc.gridy = 7; gbc.gridx = 0; gbc.gridwidth = 2; gbc.anchor = GridBagConstraints.CENTER;
        gbc.fill = GridBagConstraints.NONE;

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        JButton btnSimpan = new JButton("Simpan");
        JButton btnUbah = new JButton("Ubah");
        JButton btnHapus = new JButton("Hapus");
        JButton btnBatal = new JButton("Batal");

        btnSimpan.setBackground(BUTTON_GREEN);
        btnUbah.setBackground(new Color(0xFFC107));
        btnHapus.setBackground(new Color(0xDC3545));
        btnBatal.setBackground(new Color(0x6C757D));
        btnSimpan.setForeground(Color.WHITE);
        btnUbah.setForeground(Color.WHITE);
        btnHapus.setForeground(Color.WHITE);
        btnBatal.setForeground(Color.WHITE);
        btnSimpan.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnUbah.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnHapus.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnBatal.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnSimpan.setFocusPainted(false);
        btnUbah.setFocusPainted(false);
        btnHapus.setFocusPainted(false);
        btnBatal.setFocusPainted(false);
        btnSimpan.setPreferredSize(new Dimension(100, 38));
        btnUbah.setPreferredSize(new Dimension(100, 38));
        btnHapus.setPreferredSize(new Dimension(100, 38));
        btnBatal.setPreferredSize(new Dimension(100, 38));

        btnPanel.add(btnSimpan);
        btnPanel.add(btnUbah);
        btnPanel.add(btnHapus);
        btnPanel.add(btnBatal);
        formPanel.add(btnPanel, gbc);
        inputDialog.add(formPanel, BorderLayout.CENTER);

        btnSimpan.addActionListener(e -> { simpan(); inputDialog.dispose(); });
        btnUbah.addActionListener(e -> { ubah(); inputDialog.dispose(); });
        btnHapus.addActionListener(e -> {
            if (JOptionPane.showConfirmDialog(inputDialog, "Yakin hapus data ini?", "Konfirmasi", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
                hapus(); inputDialog.dispose();
            }
        });
        btnBatal.addActionListener(e -> inputDialog.dispose());
    }

    private void showInputDialog(boolean isEdit, Integer row) {
        clearDialogForm();
        if (isEdit && row != null) {
            txtKdDokter.setText(tableModel.getValueAt(row, 0).toString());
            txtNamaDokter.setText(tableModel.getValueAt(row, 1).toString());
            txtSpesialis.setText(tableModel.getValueAt(row, 2).toString());
            String jk = tableModel.getValueAt(row, 3).toString();
            if (jk.equals("L")) rbLaki.setSelected(true);
            else rbPerempuan.setSelected(true);
            txtAlamat.setText(tableModel.getValueAt(row, 4).toString());
            txtNoTelp.setText(tableModel.getValueAt(row, 5).toString());
            txtJadwal.setText(tableModel.getValueAt(row, 6).toString());
            inputDialog.setTitle("Edit Data Dokter");
        } else {
            generateKdDokter();
            inputDialog.setTitle("Tambah Data Dokter");
        }
        inputDialog.setVisible(true);
    }

    private void loadData() { loadDataWithFilter("", ""); }

    private void applyFilter() {
        String nama = txtFilterNama.getText().trim();
        String spesialis = txtFilterSpesialis.getText().trim();
        loadDataWithFilter(nama, spesialis);
    }

    private void resetFilter() {
        txtFilterNama.setText("");
        txtFilterSpesialis.setText("");
        loadData();
    }

    private void loadDataWithFilter(String nama, String spesialis) {
        tableModel.setRowCount(0);
        if (conn == null) return;

        StringBuilder sql = new StringBuilder("SELECT * FROM dokter WHERE 1=1");
        ArrayList<Object> params = new ArrayList<>();

        if (!nama.isEmpty()) { sql.append(" AND nama LIKE ?"); params.add("%" + nama + "%"); }
        if (!spesialis.isEmpty()) { sql.append(" AND spesialis LIKE ?"); params.add("%" + spesialis + "%"); }
        sql.append(" ORDER BY kd_dokter");

        try (PreparedStatement pst = conn.prepareStatement(sql.toString())) {
            for (int i = 0; i < params.size(); i++) pst.setObject(i + 1, params.get(i));
            ResultSet rs = pst.executeQuery();
            int count = 0;
            while (rs.next()) {
                tableModel.addRow(new Object[]{
                    rs.getString("kd_dokter"),
                    rs.getString("nama"),
                    rs.getString("spesialis"),
                    rs.getString("jk"),
                    rs.getString("alamat") != null ? rs.getString("alamat") : "",
                    rs.getString("no_telp") != null ? rs.getString("no_telp") : "",
                    rs.getString("jadwal") != null ? rs.getString("jadwal") : ""
                });
                count++;
            }
            lblTotalDokter.setText("Total Dokter: " + count);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error load data: " + e.getMessage());
        }
    }

    private void generateKdDokter() {
        try {
            String sql = "SELECT kd_dokter FROM dokter ORDER BY kd_dokter DESC LIMIT 1";
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            int newNumber = 1;
            if (rs.next()) {
                String last = rs.getString("kd_dokter");
                if (last != null && last.length() > 2) {
                    newNumber = Integer.parseInt(last.substring(2)) + 1;
                }
            }
            txtKdDokter.setText(String.format("DR%03d", newNumber));
        } catch (Exception e) {
            txtKdDokter.setText("DR001");
        }
    }

    private void simpan() {
        String kd = txtKdDokter.getText().trim();
        String nama = txtNamaDokter.getText().trim();
        String spesialis = txtSpesialis.getText().trim();
        String jk = rbLaki.isSelected() ? "L" : (rbPerempuan.isSelected() ? "P" : "");
        String alamat = txtAlamat.getText().trim();
        String noTelp = txtNoTelp.getText().trim();
        String jadwal = txtJadwal.getText().trim();

        if (kd.isEmpty() || nama.isEmpty() || spesialis.isEmpty() || jk.isEmpty()) {
            JOptionPane.showMessageDialog(inputDialog, "Kd Dokter, Nama, Spesialis, dan Jenis Kelamin harus diisi!");
            return;
        }

        try {
            String cekSql = "SELECT COUNT(*) FROM dokter WHERE kd_dokter = ?";
            PreparedStatement cekPst = conn.prepareStatement(cekSql);
            cekPst.setString(1, kd);
            ResultSet rs = cekPst.executeQuery();
            rs.next();
            if (rs.getInt(1) > 0) {
                JOptionPane.showMessageDialog(inputDialog, "Kode Dokter sudah ada!");
                rs.close(); cekPst.close(); return;
            }
            rs.close(); cekPst.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(inputDialog, "Error: " + e.getMessage()); return;
        }

        try {
            String sql = "INSERT INTO dokter (kd_dokter, nama, spesialis, jk, alamat, no_telp, jadwal) VALUES (?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, kd); pst.setString(2, nama); pst.setString(3, spesialis);
            pst.setString(4, jk); pst.setString(5, alamat); pst.setString(6, noTelp); pst.setString(7, jadwal);
            pst.executeUpdate(); pst.close();
            JOptionPane.showMessageDialog(inputDialog, "Data berhasil disimpan!");
            loadData(); clearDialogForm();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(inputDialog, "Error: " + e.getMessage());
        }
    }

    private void ubah() {
        String kd = txtKdDokter.getText().trim();
        if (kd.isEmpty()) return;
        try {
            String sql = "UPDATE dokter SET nama=?, spesialis=?, jk=?, alamat=?, no_telp=?, jadwal=? WHERE kd_dokter=?";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, txtNamaDokter.getText().trim());
            pst.setString(2, txtSpesialis.getText().trim());
            pst.setString(3, rbLaki.isSelected() ? "L" : "P");
            pst.setString(4, txtAlamat.getText().trim());
            pst.setString(5, txtNoTelp.getText().trim());
            pst.setString(6, txtJadwal.getText().trim());
            pst.setString(7, kd);
            pst.executeUpdate(); pst.close();
            JOptionPane.showMessageDialog(inputDialog, "Data berhasil diubah!");
            loadData(); clearDialogForm();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(inputDialog, "Error: " + e.getMessage());
        }
    }

    private void hapus() {
        String kd = txtKdDokter.getText().trim();
        if (kd.isEmpty()) return;
        try {
            String sql = "DELETE FROM dokter WHERE kd_dokter=?";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, kd);
            pst.executeUpdate(); pst.close();
            JOptionPane.showMessageDialog(inputDialog, "Data berhasil dihapus!");
            loadData(); clearDialogForm();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(inputDialog, "Error: " + e.getMessage());
        }
    }

    private void cetakData() {
        int rowCount = tableDokter.getRowCount();
        if (rowCount == 0) {
            JOptionPane.showMessageDialog(this, "Tidak ada data untuk dicetak!");
            return;
        }
        
        StringBuilder sb = new StringBuilder();
        sb.append("=== DATA DOKTER ===\n");
        sb.append("========================================\n\n");
        
        for (int i = 0; i < rowCount; i++) {
            sb.append((i+1) + ". ");
            sb.append("Kd Dokter: ").append(tableDokter.getValueAt(i, 0)).append("\n");
            sb.append("   Nama: ").append(tableDokter.getValueAt(i, 1)).append("\n");
            sb.append("   Spesialis: ").append(tableDokter.getValueAt(i, 2)).append("\n");
            sb.append("   JK: ").append(tableDokter.getValueAt(i, 3)).append("\n");
            sb.append("   Alamat: ").append(tableDokter.getValueAt(i, 4)).append("\n");
            sb.append("   No Telp: ").append(tableDokter.getValueAt(i, 5)).append("\n");
            sb.append("   Jadwal: ").append(tableDokter.getValueAt(i, 6)).append("\n");
            sb.append("----------------------------------------\n");
        }
        sb.append("\nTotal Dokter: ").append(rowCount);
        
        JTextArea textArea = new JTextArea(sb.toString());
        textArea.setEditable(false);
        textArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(500, 400));
        JOptionPane.showMessageDialog(this, scrollPane, "Preview Cetak Data Dokter", JOptionPane.INFORMATION_MESSAGE);
    }

    private void clearDialogForm() {
        txtKdDokter.setText(""); txtNamaDokter.setText("");
        txtSpesialis.setText(""); txtAlamat.setText("");
        txtNoTelp.setText(""); txtJadwal.setText("");
        bgJk.clearSelection();
    }
}